/* api.js — 知彼 Vantage 数据契约层（U1）
 * 用途：前端所有数据入口。MOCK=1 时读本地 mock JSON（后端未就绪时的临时数据源），
 *       MOCK=0 时打真实后端接口。
 * 纪律：任何组件不得直接硬编码品牌名/价格/来源——一律走本层（三底线之一"可溯源"的工程侧强制）。
 * 契约对齐：《UI落地评估与技术方案》§4（Material schema）与架构 v3 §8（verdict 模型）。
 */
(function (global) {
  'use strict';

  const MOCK = (new URLSearchParams(location.search)).get('MOCK') !== '0'; // 默认 MOCK=1

  function getToken() {
    try { return localStorage.getItem('zhibi_token') || localStorage.getItem('ci_token') || ''; }
    catch (e) { return ''; }
  }

  async function getJSON(url, opts) {
    const headers = Object.assign({ Accept: 'application/json' }, (opts && opts.headers) || {});
    const t = getToken();
    if (t) headers['Authorization'] = 'Bearer ' + t;
    const res = await fetch(url, Object.assign({ headers }, opts || {}));
    if (!res.ok) {
      const err = new Error('HTTP ' + res.status + ' @ ' + url);
      err.status = res.status;
      throw err;
    }
    return res.json();
  }

  async function mockJSON(name) {
    const res = await fetch('mock/' + name + '.json');
    if (!res.ok) throw new Error('mock ' + name + ' 读取失败');
    return res.json();
  }

  // ---------- 对外 API ----------
  global.ZB_API = {
    MOCK,

    /** 材料流：{ status?: 'pending'|'kept'|'later'|'dropped'|'all', type?: string } */
    materials: async (q) => {
      if (MOCK) {
        const all = await mockJSON('materials');
        const status = (q && q.status) || 'all';
        if (status === 'all') return all;
        return all.filter(m => m.status === status);
      }
      const qs = new URLSearchParams(q || {}).toString();
      return getJSON('/api/materials' + (qs ? '?' + qs : ''));
    },

    /** 竞品雷达页：对手卡 + 闸门名单 */
    rivals: async () => {
      if (MOCK) return mockJSON('rivals');
      return getJSON('/api/rivals');
    },

    /** 情报库档案（六字段折叠） */
    rivalProfile: async (id) => {
      if (MOCK) return mockJSON('rivals').then(r => r.find(x => x.id === id) || null);
      return getJSON('/api/rivals/' + encodeURIComponent(id));
    },

    /** 机会视图 */
    opportunities: async () => {
      if (MOCK) return mockJSON('opportunities');
      return getJSON('/api/opportunities');
    },

    /** 赛道档案四宫格 */
    sector: async () => {
      if (MOCK) return mockJSON('sector');
      return getJSON('/api/sector');
    },

    /** 三动作（后端就绪后启用；当前前端先落 localStorage，见 store.js） */
    action: async (matId, action) => {
      if (MOCK) return { ok: true, id: matId, action };
      return getJSON('/api/materials/' + encodeURIComponent(matId) + '/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
    },

    /** 纠错（证据来源必填，进待复核队列） */
    correction: async (payload) => {
      if (MOCK) return { ok: true, queued: true, payload };
      return getJSON('/api/corrections', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
    },
  };
})(window);
