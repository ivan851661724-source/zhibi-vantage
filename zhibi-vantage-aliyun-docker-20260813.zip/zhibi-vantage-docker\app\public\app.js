'use strict';
// 知彼 Vantage —— 前端（渐进渲染 + 点卡展开详情 + 时间线深度检索 + 直接检索品牌）
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));

const LABELS = {
  channels: { tiktokShop: 'TikTok Shop', amazon: 'Amazon', shopifyDTC: 'Shopify 独立站', xiaohongshu: '小红书', instagramShop: 'Instagram Shop', etsy: 'Etsy', offlineRetail: '线下零售', tmallJD: '天猫/京东' },
  audiences: {}, // 全赛道自由文本：AI 按赛道抽取目标人群，渲染层兜底显示原值
  regions: { us: '美国', uk: '英国', eu: '欧洲', cn: '中国', jp: '日本', sea: '东南亚' },
  priceBands: { mass: '大众档', mid: '中端', premium: '高端', ultra: '超高端' },
  contentForms: { shortVideo: '短视频', livestream: '直播', ugc: '用户自发', tutorial: '教程', unboxing: '开箱', meme: '梗图' },
  collabTypes: { ipCollab: 'IP 联名', artistCollab: '艺术家联名', brandCollab: '品牌联名', celebrity: '明星联名' },
  fulfillment: { dropship: '一件代发', madeToOrder: '按需定制', printOnDemand: 'POD 打印', localWarehouse: '本地仓', selfFactory: '自有工厂' },
  categories: {}, // 全赛道自由文本：AI 按赛道抽取品类，渲染层兜底显示原值
  gapType: { absence: '行业缺席', executionWeak: '执行偏弱', adjacency: '邻接空位', priceGap: '价位空档', claimGap: '卖点无人认领', tacticGap: '策略无人使用', demandGap: '需求未被满足' }
};
// 来源类型小图标（evidence kind → 展示）
const SRC_ICON = { official: '🏪官网', shopify: '💲实抓价格', etsy: '🧵Etsy', tiktokShop: '🎵TK', amazon: '📦Amazon', reputation: '💬口碑', moves: '📰动态', 'neg-check': '✅核查' };
const TIER_LABEL = { large: '头部大牌', mid: '腰部品牌', small: '独立小众', emerging: '新兴品牌', unknown: '体量未明' };
// 调研平台分组（与后端 OVERSEAS_PLATFORMS / CN_PLATFORMS / GLOBAL_PLATFORMS 对齐）
const OVERSEAS_PLATFORMS = ['amazon', 'shopifyDTC', 'tiktokShop', 'instagramShop', 'etsy'];
const CN_PLATFORMS = ['tmallJD', 'xiaohongshu'];
const GLOBAL_PLATFORMS = ['offlineRetail'];
const ALL_PLATFORMS = OVERSEAS_PLATFORMS.concat(CN_PLATFORMS, GLOBAL_PLATFORMS);
// 由地域推导默认平台集（前端镜像后端 platformsFromRegions）：无地域或含任一海外地域⇒海外平台；含 cn⇒加国内平台；线下零售始终在。
function platformsFromRegions(regions) {
  const set = new Set(GLOBAL_PLATFORMS);
  const hasOverseas = (regions || []).some(r => ['us', 'uk', 'eu', 'jp', 'sea'].includes(r));
  if (!regions || !regions.length || hasOverseas) OVERSEAS_PLATFORMS.forEach(p => set.add(p));
  if ((regions || []).includes('cn')) CN_PLATFORMS.forEach(p => set.add(p));
  return Array.from(set).filter(p => ALL_PLATFORMS.includes(p));
}
const lbl = (group, k) => (LABELS[group] && LABELS[group][k]) || k;
// 未知受控词（AI / 用户自由补的卖点等）的兜底展示：camelCase → 标题化（veganFormula → "Vegan Formula"）
const prettyKey = (k) => {
  if (!k) return k;
  const s = String(k);
  if (/[一-龥]/.test(s)) return s; // 已是中文，原样
  return s.replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/^./, c => c.toUpperCase()).trim();
};
// ▶ P1-2：消费后端 L1 门禁产出（gateLevel/credible/gateReason，server 已挂在字段上，前端此前未用），
// 不重复计算置信。语义收敛：仅当不可信（single/weak）才显一个胶囊；high 不显（值本身即可信），
// 把"8 个彩色胶囊"压到 ≤1。state/值始终可见（忠实助理红线），胶囊只负责"这值可不可信"。
function gateBadge(f) {
  // ▶ 呈现层反转：内部门禁/置信评分永不显示为标签（"待补查/待复核"均移除）——信任来自交付物本身（值+溯源），故此处恒返回空。
  return '';
}
// 竞争级门禁汇总：聚合该品牌关键字段（价格/渠道/口碑）的门禁等级，供头部/对比表显示单一信任信号
function competitorGate(c) {
  const lv = [];
  if (c.priceField) lv.push(c.priceField.gateLevel || 'high');
  if (c.channelFields) Object.values(c.channelFields).forEach(f => lv.push(f.gateLevel || 'high'));
  if (c.reviewField) {
    if (c.reviewField.rating) lv.push(c.reviewField.rating.gateLevel || 'high');
    if (c.reviewField.trend) lv.push(c.reviewField.trend.gateLevel || 'high');
  }
  if (!lv.length) return c.confidence || 'medium';
  if (lv.every(x => x === 'high')) return 'high';
  if (lv.some(x => x === 'weak')) return 'weak';
  return 'single';
}
// ▶ 呈现层反转：内部置信/门禁评分永不显示为标签（"已核实/待补查/部分待复核"均移除）——信任来自交付物本身（值+溯源），故此处恒返回空。
function competitorGateChip(c) { return ''; }
const REL_LABEL = { direct: '直接对手', indirect: '间接对手', unrelated: '暂不直接相关', undetermined: '关系待定' };
const relClsOf = code => (code === 'direct' ? 'hot' : code === 'indirect' ? 'warm' : code === 'unrelated' ? 'cool' : 'tbd');
const TC_ZH = { discount: '折扣促销', bundle: '捆绑销售', subscription: '订阅制', ugcCampaign: 'UGC征集', livestreamSelling: '直播带货', membership: '会员制', influencerSeeding: '达人种草', giveaway: '抽奖赠品', preorder: '预售', loyaltyProgram: '积分忠诚', seasonalDrop: '季节限定上新', communityBuilding: '社群运营' };

// ---------- L1 六大类档案：固定顺序 + 智能折叠 + 三态空字段 ----------
// 分层判据（唯一标准 = 用户此刻在做什么决定）：L0 卡面决定"值不值得点开"，L1 决定"怎么打的、抄什么躲什么"。
const L1_ORDER = ['pricing', 'positioning', 'products', 'channels', 'reviews', 'marketing'];
const L1_META = {
  pricing:     { title: '价格体系',  fields: ['price', 'shopify'] },
  positioning: { title: '定位战略',  fields: ['positioning', 'sellingPoints'] },
  products:    { title: '产品体系',  fields: ['products', 'audiences'] },
  channels:    { title: '渠道布局',  fields: ['channels', 'regions'] },
  reviews:     { title: '用户口碑',  fields: ['reviews', 'painPoints'] },
  marketing:   { title: '营销推广',  fields: ['tactics', 'contentForms', 'collabTypes', 'fulfillment', 'recentMoves', 'estSize', 'techStack', 'inferred'] },
};
// 三态空字段：哪些「受采集层 attempt 日志覆盖」的字段，在无数据时走三态而非直接消失
const L1_EMPTY_FIELDS = {
  pricing:     [{ fieldKey: 'price', label: '价格体系' }],
  positioning: [{ fieldKey: 'sellingPoints', label: '主打卖点' }, { fieldKey: 'positioning', label: '定位战略' }],
  products:    [{ fieldKey: 'products', label: '产品矩阵' }, { fieldKey: 'audiences', label: '目标人群' }],
  channels:    [{ fieldKey: 'channels', label: '渠道版图' }],
  reviews:     [{ fieldKey: 'reviews', label: '口碑走势' }, { fieldKey: 'painPoints', label: '用户抱怨点' }],
  marketing:   [{ fieldKey: 'tactics', label: '销售打法' }, { fieldKey: 'contentForms', label: '内容形态' }, { fieldKey: 'collabTypes', label: '联名方式' }, { fieldKey: 'fulfillment', label: '履约方式' }, { fieldKey: 'recentMoves', label: '近期动作' }, { fieldKey: 'estSize', label: '估算规模' }, { fieldKey: 'techStack', label: '技术栈' }],
};
const l1Expanded = new Map(); // 会话内折叠记忆：key = `${compId}:${catKey}` -> bool

// 三态判定：从 attempt 日志区分 未探测 / 已查未得 / 有数据（绝不把"没查"和"查了没找到"混为一谈）
function attemptState(c, fieldKey) {
  const a = (c.attempts || []).filter(x => x.field === fieldKey);
  if (!a.length) return fieldHasData(c, fieldKey) ? { state: 'has' } : { state: 'unprobed' };
  if (a.some(x => x.hit) || fieldHasData(c, fieldKey)) return { state: 'has' };
  const sources = Array.from(new Set(a.map(x => x.source).filter(Boolean)));
  const dates = a.map(x => x.time).filter(Boolean).sort();
  const queries = a.map(x => x.query).filter(Boolean);
  return { state: 'attempted_empty', sources, latest: dates.length ? dates[dates.length - 1] : null, queries };
}
// 字段当前是否已有数据（用于避免"已填充却显示未探测"的双渲染）
function fieldHasData(c, fieldKey) {
  switch (fieldKey) {
    case 'price': return !!(c.pricePoints && c.pricePoints.length) || !!c.priceBand;
    case 'sellingPoints': return (c.sellingPoints || []).length > 0;
    case 'positioning': return !!c.positioning;
    case 'products': return (c.products || []).length > 0 || !!(c.productMatrix && (c.productMatrix.skuCount || (c.productMatrix.heroSku || []).length || (c.productMatrix.productLines || []).length || c.productMatrix.priceBandDist));
    case 'audiences': return (c.audiences || []).length > 0;
    case 'channels': return Object.keys(c.channels || {}).some(k => c.channels[k].present);
    case 'reviews': return !!(c.reviews && (c.reviews.rating != null || (c.reviews.posThemes || []).length || (c.reviews.negThemes || []).length));
    case 'painPoints': return (c.painPoints || []).length > 0;
    case 'tactics': return (c.tactics || []).length > 0;
    case 'contentForms': return (c.contentForms || []).length > 0;
    case 'collabTypes': return (c.collabTypes || []).length > 0;
    case 'fulfillment': return (c.fulfillment || []).length > 0;
    case 'recentMoves': return (c.recentMoves || []).length > 0;
    case 'estSize': return !!c.estSize;
    case 'techStack': return !!c.techStack;
    default: return false;
  }
}
function renderEmptyField(c, fieldKey, label) {
  const a = attemptState(c, fieldKey);
  if (a.state === 'unprobed')
    return `<div class="field empty"><div class="field-t">${label}</div><div class="field-v"><button class="st-empty unprobed" data-l2field="${escAttr(fieldKey)}" data-cid="${escAttr(c.id)}">还没查 · 点此补查</button></div></div>`;
  if (a.state === 'attempted_empty') {
    const d = a.latest ? new Date(a.latest).toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' }) : '';
    const title = `查过没找到${d ? (' · ' + d + '查过') : ''}${a.sources && a.sources.length ? (' · 源：' + a.sources.join(' / ')) : ''}${a.queries && a.queries.length ? (' · 查询：' + a.queries.slice(0, 2).join(' / ')) : ''}`;
    return `<div class="field empty attempted"><div class="field-t">${label}</div><div class="field-v"><span class="st-empty attempted" title="${escAttr(title)}">查过没找到${d ? (' · ' + d) : ''}${a.sources && a.sources.length ? (' · ' + a.sources.length + '源') : ''}</span></div></div>`;
  }
  return '';
}
// 品牌价位区间（结构化 pricePoints，原币种）
function compPriceRange(c) {
  const p = (c.pricePoints || []).filter(n => typeof n === 'number' && !isNaN(n));
  if (p.length) return { min: Math.min(...p), max: Math.max(...p), currency: c.currency };
  return null;
}
// 价格是否重叠或相邻（跨币种不比，返回 null 表示不可判定）
function priceOverlapOrAdjacent(c, prof) {
  if (!prof || !prof.priceBand) return null;
  const pr = compPriceRange(c); if (!pr) return null;
  const pb = prof.priceBand;
  if (pb.currency && pr.currency && pb.currency !== pr.currency) return null;
  if (!(pr.max < pb.min || pr.min > pb.max)) return true; // 重叠
  const span = Math.max(pb.max - pb.min, 1);
  const close = (Math.abs(pr.max - pb.min) <= span * 0.4) || (Math.abs(pr.min - pb.max) <= span * 0.4);
  return close; // 相邻
}
// 智能折叠默认展开判据（代码判定，非 LLM 感觉）
const L1_TRIGGER = {
  pricing: (c, prof) => { const r = priceOverlapOrAdjacent(c, prof); return r == null ? false : r; },
  positioning: (c, prof) => !!(prof && prof.sellingPoints && c.sellingPoints && c.sellingPoints.some(x => prof.sellingPoints.includes(x))),
  channels: (c, prof) => { if (!prof || !prof.regions || !prof.regions.length) return false; const ch = c.channels || {}; return Object.keys(ch).filter(k => ch[k].present).some(k => prof.regions.includes(k)); },
  reviews: (c) => !!(c.reviews && c.reviews.negThemes && c.reviews.negThemes.length),
  products: () => false,
  marketing: () => false,
};
function l1ShouldExpand(catKey, c, prof) {
  const hasData = L1_ITEMS[catKey](c).length > 0;
  if (!hasData) return false; // 无数据不展开（且整体会被跳过渲染）
  if (!prof) return true;     // 无定位 → relevance 未知，有数据就展开
  const trig = L1_TRIGGER[catKey] ? L1_TRIGGER[catKey](c, prof) : false;
  return trig;                // 有定位 → 仅命中触发项的展开，其余折叠（头部已标"内含 N 项"）
}
// 币种：只显示原币种，永不换算；未探测到站点币种时如实标注"按市场假定"
// 必须与 lib/relationship.js curSym 保持同步（#309 ¥CNY / ¥JPY 歧义修复，显示须显式带币种代码）
const CURRENCY_SYMBOL = { USD: '$', GBP: '£', EUR: '€', JPY: '¥', CNY: '¥', AUD: 'A$', CAD: 'C$', SGD: 'S$', HKD: 'HK$' };
const curSym = cur => { if (cur === 'CNY') return '¥CNY'; if (cur === 'JPY') return '¥JPY'; return CURRENCY_SYMBOL[cur] || (cur ? cur + ' ' : '$'); };
const curNote = c => (c && c.currencyBasis === 'assumed' && ((c.pricePoints || []).length || c.priceBand)
  ? ` <span class="tag assumed" title="未从该品牌站点探测到结算币种，按目标市场默认显示，未做任何汇率换算">${c.currency || 'USD'}·按市场假定</span>`
  : (c && c.currency ? ` <span class="tag">${c.currency}</span>` : ''));

// 受控卖点词表（跨品类通用 · 与 server.js SELLING_POINTS 对应）；SP_ZH 同时供入口多选与详情渲染。
// 仅保留真正跨赛道复用的通用卖点；潮玩专属词已移除。AI / 用户可补充受控词之外的自由词，渲染层兜底展示。
const SP_ZH = {
  affordablePrice: '平价 / 高性价比', premiumMaterial: '高端材质 / 溢价', customization: '可定制 / 个性化',
  fastShipping: '快发货 / 即时交付', ecoFriendly: '环保可持续', limitedEdition: '限量 / 稀缺',
  handmade: '手作 / 匠心', personalGift: '礼品属性', localCulture: '在地 / 本地文化',
  innovation: '科技创新', designAesthetic: '设计感', serviceWarranty: '服务 / 质保',
  healthSafe: '健康安全', convenience: '便捷省心', naturalOrganic: '天然有机', exclusive: '独家 / 会员专属'
};
const SP_MAX = 3;        // 核心卖点最多 3 条
const SP_CUSTOM_MAX = 2; // 其中自定义最多 2 条

// 市场 → 币种（与 server.js 对齐；前端只在入口展示价位输入币种，永不换算）
const CURRENCY_BY_REGION = { us: 'USD', uk: 'GBP', eu: 'EUR', jp: 'JPY', cn: 'CNY', sea: 'USD' };
function marketCurrency(regions) {
  if (!regions || !regions.length) return 'USD';
  for (const rg of regions) if (CURRENCY_BY_REGION[rg]) return CURRENCY_BY_REGION[rg];
  return 'USD';
}

let state = null;
// ---------- 演示模式（URL 带 ?demo=1）：用 public/mock 演示数据构造 state，便于 1:1 验收 ----------
// location 守卫：Node 测试环境无 location（l1.test.js 曾因此失败挂账，现一行修复）
const DEMO_MODE = typeof location !== 'undefined' && /[?&]demo=1/.test(location.search);
async function mockDemoState() {
  const [mats, rivals, opps] = await Promise.all([
    fetch('mock/materials.json').then(r => r.json()).catch(() => []),
    fetch('mock/rivals.json').then(r => r.json()).catch(() => []),
    fetch('mock/opportunities.json').then(r => r.json()).catch(() => []),
  ]);
  const REL_CODE = { direct: 'direct', ref: 'indirect', cheap: 'unrelated' };
  const SYM = { GBP: '£', USD: '$', JPY: '¥', EUR: '€' };
  const competitors = rivals.map((r, i) => {
    const ch = {};
    (r.channels || []).forEach(c => { ch['ch_' + i + '_' + (c.label || i)] = { present: c.tier === 'ok', state: c.tier === 'ok' ? 'present' : 'undetected', label: c.label }; });
    const dom = String(r.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    return {
      id: r.id, name: r.name, status: 'done', rankScore: 92 - i * 6,
      category: '潮流玩具', tier: i === 0 ? 'large' : (i < 3 ? 'mid' : 'small'),
      url: 'https://' + (dom || 'brand') + '.com',
      relationship: { code: REL_CODE[r.relation] || 'undetermined', label: r.relationLabel || '直接对手' },
      priceBand: { band: 'mid', range: (r.price && r.price.band) || '', currency: (r.price && r.price.currency) || 'USD', basis: 'verified' },
      pricePoints: r.price && r.price.from != null ? [r.price.from] : [],
      priceField: r.price ? { display: (SYM[r.price.currency] || '$') + r.price.from, basis: 'verified' } : null,
      channels: ch,
      currency: (r.price && r.price.currency) || 'USD',
      reviews: { rating: +(4.2 + (i % 3) * 0.2).toFixed(1), basis: 'verified' },
      launchCadence: { value: i % 2 ? '季度系列制' : '月更', basis: 'verified' },
      recentActions: r.latestAction ? { hasAction: true, action: { label: r.latestAction.text, desc: r.latestAction.detail, when: r.latestAction.when } } : { hasAction: false },
      heroProduct: { heroProducts: [{ name: (r.latestAction && r.latestAction.detail) || '主推款' }] },
      evidenceCount: 3,
    };
  });
  // 材料直接复用（mock 格式与 wbMaterialHTML 视图模型一致）
  const materials = (Array.isArray(mats) ? mats : []).map(m => ({ ...m, id: 'demo_' + m.id }));
  // 机会 themes
  const themes = (Array.isArray(opps) ? opps : []).map(o => ({
    id: o.id, label: o.title, note: o.desc, opportunity: o.score,
    denominatorText: o.breadth, zone: (o.confidence === 'low' || o.confidenceLabel.includes('低')) ? 'served' : 'underserved',
    method: '机会引擎', oid: o.methodKey,
  }));
  // 信号条：按材料聚合
  const groups = {};
  materials.forEach(m => {
    const t = (m.type || '').toLowerCase(); const s = m.signal || '';
    let g = '上新';
    if (t.includes('down') || t.includes('price') && s === 'down' || s === 'down') g = '降价';
    else if (t.includes('crisis') || s === 'crisis') g = '差评暴涨';
    else if (t.includes('channel')) g = '开新店';
    else if (t.includes('up') || s === 'up') g = '涨价';
    const nm = (m.brand && m.brand.name) || '品牌';
    if (!groups[g]) groups[g] = [];
    groups[g].push(nm);
  });
  const gs = Object.entries(groups).slice(0, 5).map(([label, cs]) => ({ label, note: '', competitors: cs }));
  return {
    projectId: 'demo', track: '定制手办 · 潮流玩具',
    intent: { goals: ['pricing', 'newlaunch'], regions: ['us', 'uk'], profile: { priceBand: { min: 199, max: 329, currency: 'CNY' }, sellingPoints: ['customization'] }, platforms: ['amazon', 'etsy', 'shopifyDTC'] },
    competitors, materials, excluded: [],
    opportunity: { hidden: false, doneBrands: 6, brandsWithVoice: 4, preliminaryThemes: themes, themes },
    radar: { groupSignals: gs },
    whiteSpace: null, excludedReasons: {}, addedCompetitors: [],
    marketCurrency: 'USD',
  };
}
let pollTimer = null;
let intent = { goals: [], regions: [], platforms: [] };
let ZB_OWN_BRANDS = []; // 自有品牌（设置页注入），用于品类扫描对标表焦距
let platformsTouched = false; // 用户一旦手动改平台，就不随地域自动变
// 收集当前勾选的调研平台（始终带当前勾选态；后端 resolvePlatforms 会校验合法性）
function collectPlatforms() {
  const sel = $$('#platformGroups .chip.on').map(ch => ch.dataset.platform).filter(p => ALL_PLATFORMS.includes(p));
  return sel.length ? sel : platformsFromRegions(intent.regions); // 全清空则回退地域推导
}
let selectedSP = new Set();  // 受控卖点 key
let customSP = [];           // 自定义卖点字符串（≤2）
let profileCur = 'USD';      // 随地域联动的价位币种
let expandedIds = new Set();   // 当前展开详情的卡片
let userNotes = {};             // 私有备注缓存：competitorId -> text（undefined=未拉取；''=空/已清除）
let timelineCache = new Map(); // competitorId -> 时间线结果（避免重复检索）

// ---------- 多租户鉴权（前端） ----------
const TOKEN_KEY = 'ci_auth_token';
const USER_KEY = 'ci_auth_user';
function getToken() { return localStorage.getItem(TOKEN_KEY) || ''; }
function setAuth(token, user) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  if (user != null) localStorage.setItem(USER_KEY, JSON.stringify(user));
}
function clearAuth() { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(USER_KEY); }
function getStoredUser() { try { return JSON.parse(localStorage.getItem(USER_KEY) || 'null'); } catch { return null; } }

// ---------- API ----------
async function api(path, opts) {
  opts = opts || {};
  const token = getToken();
  if (token) opts.headers = Object.assign({}, opts.headers, { 'Authorization': 'Bearer ' + token });
  const r = await fetch(path, opts);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.message || j.error || ('HTTP ' + r.status));
  return j;
}

// ---------- 平台超管（前端） ----------
const ADMIN_TOKEN_KEY = 'ci_admin_token';
const ADMIN_USER_KEY = 'ci_admin_user';
function getAdminToken() { return localStorage.getItem(ADMIN_TOKEN_KEY) || ''; }
function setAdminToken(t) { if (t) localStorage.setItem(ADMIN_TOKEN_KEY, t); }
function clearAdminToken() { localStorage.removeItem(ADMIN_TOKEN_KEY); localStorage.removeItem(ADMIN_USER_KEY); }
async function apiAdmin(path, opts) {
  opts = opts || {};
  const t = getAdminToken();
  if (t) opts.headers = Object.assign({}, opts.headers, { 'Authorization': 'Bearer ' + t });
  const r = await fetch(path, opts);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || j.message || ('HTTP ' + r.status));
  return j;
}

// ---------- 入口 / 鉴权门 ----------
async function boot() {
  // 防浏览器自动填充残留（如邮箱串进「指定品牌」输入框）：强制清空 + 锁定 readonly，聚焦才解锁
  const _li = document.getElementById('lookupInput');
  if (_li) {
    _li.value = '';
    _li.setAttribute('readonly', '');
    _li.addEventListener('focus', () => _li.removeAttribute('readonly'));
  }
  bindAuth();
  // 演示模式（?demo=1）：直接进入应用并加载 mock 数据，便于 1:1 验收
  if (DEMO_MODE) {
    const me = { user: { email: 'demo@brand.com', brand: 'Demo 品牌主理人' }, tenant: { plan: '演示' } };
    setAuth('demo-token', me.user);
    return enterApp(me);
  }
  // 优先：平台超管会话
  const at = getAdminToken();
  if (at) {
    try { const ov = await apiAdmin('/api/admin/overview'); return showAdminPanel(ov); }
    catch (e) { clearAdminToken(); }
  }
  // 其次：租户会话
  const token = getToken();
  if (token) {
    try {
      const me = await api('/api/me');
      if (me && me.user) { setAuth(token, me.user); return enterApp(me); }
    } catch (e) { /* token 失效，回落到登录屏 */ }
    clearAuth();
  }
  showAuth();
}

// 登录 / 注册成功后进入应用（原 boot 初始化逻辑迁移至此）
async function enterApp(me) {
  document.body.classList.remove('logged-out');
  document.body.classList.remove('admin-mode');
  $('#authScreen').classList.add('hidden');
  $('#adminPanel').classList.add('hidden');
  updateUserMenu(me);
  bindOnboarding();
  bindReportModal();
  bindFieldCorrect();
  bindFeedbackReport();
  bindSettings();
  bindHistory();
  bindWbFilters(); // U5：工作台筛选 chips
  try {
    if (DEMO_MODE) {
      state = await mockDemoState();
      enterReport(); // 演示模式：不启动后端轮询
      // 演示模式支持 URL hash 定位到指定面板（#radar / #intel / #opportunity / #sector）
      const hash = (location.hash || '').replace(/^#/, '');
      if (hash && hash !== 'workbench') switchTab(hash);
      return;
    }
    const s = await api('/api/state');
    if (s && s.track) { state = s; enterReport(); startPolling(); }
    else showOnboarding();
  } catch { showOnboarding(); }
}

// ---- 鉴权门 UI ----
let authMode = 'login';
function bindAuth() {
  $('#authTabLogin').onclick = () => setAuthMode('login');
  $('#authTabRegister').onclick = () => setAuthMode('register');
  const lg = $('#btnLogout'); if (lg) lg.onclick = () => doLogout(); // 顶栏用户菜单已移除，保留侧栏退出（btnLogoutSide）
  $('#authForm').onsubmit = async (e) => {
    e.preventDefault();
    const email = $('#authEmail').value.trim();
    const password = $('#authPassword').value;
    const brand = $('#authBrand').value.trim();
    $('#authError').textContent = '';
    if (!email || !password) { $('#authError').textContent = '请填写邮箱和密码'; return; }
    if (authMode === 'register') {
      if (!brand) { $('#authError').textContent = '注册需要填写品牌 / 工作区名称'; return; }
      if (password.length < 8) { $('#authError').textContent = '密码至少 8 位'; return; }
      await doRegister(email, password, brand);
    } else {
      await doLogin(email, password);
    }
  };
  $('#authAdminLink').onclick = () => setAdminMode(true);
  $('#authBackLink').onclick = () => setAdminMode(false);
  $('#adminForm').onsubmit = async (e) => {
    e.preventDefault();
    const username = $('#adminUser').value.trim();
    const password = $('#adminPassword').value;
    $('#adminError').textContent = '';
    if (!username || !password) { $('#adminError').textContent = '请输入管理员账号和密码'; return; }
    await doAdminLogin(username, password);
  };
  $('#btnAdminLogout').onclick = () => adminLogout();
}
function setAuthMode(m) {
  authMode = m;
  $('#authTabLogin').classList.toggle('active', m === 'login');
  $('#authTabRegister').classList.toggle('active', m === 'register');
  $('#authBrandField').classList.toggle('hidden', m !== 'register');
  $('#authSubmit').textContent = m === 'login' ? '登录' : '创建工作区';
  $('#authError').textContent = '';
}
function showAuth() {
  document.body.classList.remove('admin-mode');
  document.body.classList.add('logged-out');
  $('#authScreen').classList.remove('hidden');
  setAdminMode(false);
  $('#authError').textContent = '';
  $('#authEmail').value = '';
  $('#authPassword').value = '';
  $('#authBrand').value = '';
  setAuthMode('login');
  updateUserMenu(null);
}
async function doLogin(email, password) {
  $('#authSubmit').disabled = true;
  try {
    if (DEMO_MODE) { // 演示模式：任意邮箱密码直接进入，加载 mock 数据
      const me = { user: { email: email || 'demo@brand.com', brand: 'Demo 品牌主理人' }, tenant: { plan: '演示' } };
      setAuth('demo-token', me.user);
      return enterApp(me);
    }
    const j = await api('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }) });
    setAuth(j.token, j.user);
    const me = await api('/api/me');
    enterApp(me);
  } catch (e) {
    $('#authError').textContent = (e && e.message) || '登录失败';
  } finally { $('#authSubmit').disabled = false; }
}
async function doRegister(email, password, brand) {
  $('#authSubmit').disabled = true;
  try {
    const j = await api('/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, brand }) });
    setAuth(j.token, j.user);
    const me = await api('/api/me');
    enterApp(me);
  } catch (e) {
    $('#authError').textContent = (e && e.message) || '注册失败';
  } finally { $('#authSubmit').disabled = false; }
}
function doLogout() {
  clearAuth();
  stopPolling();
  showAuth();
}
function updateUserMenu(me) {
  const um = $('#userMenu'); // 顶栏用户菜单已移除（P2-2026-08-11），此处兼容旧调用
  if (um) { if (!me || !me.user) { um.classList.add('hidden'); return; } um.classList.remove('hidden'); }
  const e1 = $('#userEmail'); if (e1) e1.textContent = (me && me.user && me.user.email) || '';
  const p = $('#userPlan');
  if (p) p.textContent = me && me.tenant ? ('· ' + (me.tenant.plan || '')) : '';
  // U3：侧栏用户区填充
  const n2 = $('#userName'); if (n2) n2.textContent = (me.user.brand || me.user.email || '');
  const e2 = $('#userEmail2'); if (e2) e2.textContent = me.user.email || '';
  const av = $('#userAvatar'); if (av) av.textContent = ((me.user.brand || me.user.email || '?')[0] || '?').toUpperCase();
}

// ---------- 平台超管 UI ----------
function setAdminMode(m) {
  $('#authForm').classList.toggle('hidden', m);
  $('#adminForm').classList.toggle('hidden', !m);
  $('#authTabs').classList.toggle('hidden', m);
  $('#authAdminLink').classList.toggle('hidden', m);
  $('#authBackLink').classList.toggle('hidden', !m);
  $('#authError').textContent = '';
  $('#adminError').textContent = '';
}
function showAdminPanel(ov) {
  document.body.classList.remove('logged-out');
  document.body.classList.add('admin-mode');
  $('#authScreen').classList.add('hidden');
  $('#adminPanel').classList.remove('hidden');
  $('#onboarding').classList.add('hidden');
  $('#report').classList.add('hidden');
  const u = localStorage.getItem(ADMIN_USER_KEY) || '';
  $('#adminUserLabel').textContent = u ? (u + ' · 平台管理员') : '平台管理员';
  renderAdmin(ov);
}
async function renderAdmin(ov) {
  const el = $('#adminContent');
  if (!ov) {
    try { ov = await apiAdmin('/api/admin/overview'); }
    catch (e) { clearAdminToken(); return showAuth(); }
  }
  const g = ov.global || {};
  const rows = ov.tenants || [];
  let html = '<div class="admin-stats">'
    + stat('租户总数', g.tenantCount)
    + stat('已封禁', g.suspended)
    + stat('累计计费搜索', g.totalBilledSearchCalls)
    + '</div>';
  html += '<h3 class="admin-sec">租户一览</h3>';
  if (!rows.length) html += '<p class="admin-empty">暂无租户。</p>';
  else {
    html += '<table class="admin-table"><thead><tr>'
      + '<th>品牌/工作区</th><th>邮箱</th><th>套餐</th><th>状态</th><th>成员</th><th>项目</th><th>计费搜索</th><th>创建时间</th>'
      + '</tr></thead><tbody>';
    for (const r of rows) {
      html += '<tr>'
        + '<td>' + htmlEsc(r.name) + '</td>'
        + '<td>' + htmlEsc(r.email) + '</td>'
        + '<td>' + htmlEsc(r.plan || '-') + '</td>'
        + '<td><span class="badge-' + (r.status === 'suspended' ? 'danger' : 'ok') + '">' + htmlEsc(r.status) + '</span></td>'
        + '<td>' + (r.members || 0) + '</td>'
        + '<td>' + (r.projects || 0) + '</td>'
        + '<td>' + ((r.billed && r.billed.search_calls) || 0) + '</td>'
        + '<td>' + htmlEsc((r.createdAt || '').slice(0, 10)) + '</td>'
        + '</tr>';
    }
    html += '</tbody></table>';
  }
  el.innerHTML = html;
}
function stat(label, val) {
  return '<div class="admin-stat"><div class="admin-stat-val">' + (val == null ? 0 : val) + '</div><div class="admin-stat-label">' + label + '</div></div>';
}
function htmlEsc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
async function doAdminLogin(username, password) {
  $('#adminSubmit').disabled = true;
  try {
    const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || '登录失败');
    setAdminToken(j.token);
    if (j.username) localStorage.setItem(ADMIN_USER_KEY, j.username);
    const ov = await apiAdmin('/api/admin/overview');
    showAdminPanel(ov);
  } catch (e) {
    $('#adminError').textContent = (e && e.message) || '管理员登录失败';
  } finally { $('#adminSubmit').disabled = false; }
}
function adminLogout() {
  clearAdminToken();
  showAuth();
}

// 换赛道：重置当前项目，回到「调研赛道」首页（顶栏"换赛道"与新按钮共用）
async function resetToOnboarding() {
  stopPolling();
  expandedIds.clear(); timelineCache.clear();
  try { await api('/api/reset', { method: 'POST' }); } catch {}
  state = null; showOnboarding();
}

function showOnboarding() {
  $('#onboarding').classList.remove('hidden');
  $('#report').classList.add('hidden');
  // 顶栏：入口阶段无赛道，只显示产品名，crumb 与赛道 pill 隐藏
  const tbN = $('#tbName'); if (tbN) tbN.textContent = '知彼 Vantage';
  const tbC = $('#tbCrumb'); if (tbC) tbC.classList.add('hidden');
  const tbT = $('#tbTrackWrap'); if (tbT) tbT.classList.add('hidden');
  $('#trackPill').classList.add('hidden');
  $('#btnChangeTrack').classList.add('hidden');
  // 回到入口：重置意图与平台选择，平台按地域默认勾选
  intent = { goals: [], regions: [], platforms: [] };
  platformsTouched = false;
  $$('#goalChips .chip').forEach(c => c.classList.remove('on'));
  $$('#regionChips .chip').forEach(c => c.classList.remove('on'));
  syncPlatformDefaults();
  $('#trackInput').value = '';
  $('#lookupInput').value = '';
  selectedSP.clear(); customSP = [];
  $('#pbMin').value = ''; $('#pbMax').value = '';
}

function enterReport() {
  $('#onboarding').classList.add('hidden');
  $('#report').classList.remove('hidden');
  // 顶栏（设计稿 §2）：tbName=面板标题（默认工作台），crumb 分隔符，tb-track 赛道 pill
  const tbN0 = $('#tbName'); if (tbN0) tbN0.textContent = '工作台';
  const tbC = $('#tbCrumb'); if (tbC) { tbC.classList.remove('hidden'); tbC.textContent = '/'; }
  const tbT = $('#tbTrackWrap'); if (tbT) tbT.classList.remove('hidden');
  $('#trackPill').textContent = state.track;
  $('#trackPill').classList.remove('hidden');
  $('#btnChangeTrack').classList.remove('hidden');
  $('#reportTrack').textContent = state.track;
  const g = (state.intent && state.intent.goals) || [];
  let intentTxt = g.length ? ('关注：' + g.map(x => lbl('goals', x)).join('、')) : '全景模式';
  const prof = state.intent && state.intent.profile;
  if (prof) {
    const parts = [];
    if (prof.sellingPoints && prof.sellingPoints.length)
      parts.push('卖点：' + prof.sellingPoints.map(x => SP_ZH[x] || prettyKey(x)).join('、'));
    if (prof.priceBand && (prof.priceBand.min != null || prof.priceBand.max != null)) {
      const sym = curSym(prof.priceBand.currency);
      const lo = prof.priceBand.min != null ? sym + prof.priceBand.min : '—';
      const hi = prof.priceBand.max != null ? sym + prof.priceBand.max : '—';
      parts.push('价位：' + lo + '–' + hi);
    }
    if (parts.length) intentTxt += ' · ' + parts.join(' · ');
  }
  $('#reportIntent').textContent = intentTxt;
  renderAll();
}

// ---------- 轮询（渐进补全） ----------
// ▶ P1-1 局部重渲染：仅当数据真正变化才整页重画；用户正在看卡/开模态时跳过本 tick，避免滚动丢失。
function anyModalOpen() { return !!document.querySelector('.modal:not(.hidden)'); }
// 廉价签名：对手状态 + 关键字段版本（priceField/渠道/口碑/维度覆盖/空白视图版本），用于判断「这次轮询是否值得重画」
function stateSig(s) {
  try {
    const cs = (s.competitors || []).map(c => [
      c.id, c.status,
      c.priceField && c.priceField.display,
      c.priceField && c.priceField.basis,
      c.priceField && c.priceField.confidence,
      (c.channelFields && Object.keys(c.channelFields).length) || 0,
      c.reviewField ? (c.reviewField.rating && c.reviewField.rating.value) : '',
      (c.pendingCorrections || []).length
    ].join('|')).join('~');
    const ws = s.whiteSpace ? (s.whiteSpace.version || JSON.stringify(s.whiteSpace.gaps && s.whiteSpace.gaps.length) || '') : '';
    return cs + '#' + (s.fieldCorrections ? s.fieldCorrections.length : 0) + '#' + ws + '#' + (s.whiteSpace ? s.whiteSpace.coverage : '');
  } catch { return '' + Date.now(); }
}
let _stateSig = '';
let sseConn = null;
let fallbackTimer = null;
// 渐进式发现：发现阶段标记（SSE typed 事件驱动增量渲染；此期间屏蔽整页重渲染与冗余拉取）
let discovering = false;
let discoverProjectId = null;
let discoverErrored = false;   // ▶ 加固（发现链路）：报错已处理标记，SSE 回放事件幂等
// F12：变化检测推送——服务端经 /api/stream 广播变更，前端仅在签名为新时重渲染
async function onPush() {
  try {
    const s = await api('/api/state');
    // 用户在看卡 / 开模态 / 有卡展开 → 本 tick 不重画，等其收起后再画（P1-1：滚动不丢）
    if (anyModalOpen() || l1Expanded.size > 0) { state = s; return; }
    const sig = stateSig(s);
    if (sig === _stateSig) { state = s; return; } // 数据未变，跳过整页重渲染
    state = s;
    _stateSig = sig;
    renderAll();
  } catch {}
}
function startPolling() {
  stopPolling();
  if (typeof EventSource !== 'undefined') {
    try {
      sseConn = new EventSource('/api/stream');
      sseConn.onmessage = (ev) => {
        let evt = null;
        try { evt = ev.data ? JSON.parse(ev.data) : null; } catch {}
        // 渐进式发现：typed 事件按类型分发（品牌卡增量 / 阶段进度 / 收尾 / 错误）
        if (evt && evt.type && evt.type !== 'change') { onSSEEvent(evt); return; }
        // 发现阶段：忽略通用 change 事件（增量事件已驱动渲染），避免冲突/冗余拉取
        if (discovering) return;
        onPush();
      };
      sseConn.onerror = () => {
        if (discovering) {
          // SSE 断开 + 正在发现 → 2s 轮询兜底，保证进度仍可见
          if (!fallbackTimer) fallbackTimer = setInterval(discoverPoll, 2000);
        } else if (!fallbackTimer) {
          fallbackTimer = setInterval(onPush, 15000);
        }
      };
      return;
    } catch { /* fall through to interval */ }
  }
  if (discovering) fallbackTimer = setInterval(discoverPoll, 2000);
  else fallbackTimer = setInterval(onPush, 15000);
}
function stopPolling() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
  if (fallbackTimer) { clearInterval(fallbackTimer); fallbackTimer = null; }
  if (sseConn) { try { sseConn.close(); } catch {} sseConn = null; }
}

// ---------- 渐进式发现：SSE typed 事件处理（增量追加品牌卡） ----------
// 用户决策：发现期间采用「增量追加」而非整页重渲染——边搜边出卡，过程可见。
function onSSEEvent(evt) {
  switch (evt.type) {
    case 'discover_stage': onStage(evt); break;
    case 'brand_found': onBrandFound(evt); break;
    case 'brand_removed': onBrandRemoved(evt); break;
    case 'discover_complete': onDiscoverComplete(evt); break;
    case 'discover_error': onDiscoverError(evt); break;
    default: break; // 其他 typed 事件（如深研阶段的 change 已走 onPush）暂不处理
  }
}
function onStage(evt) {
  const pw = $('#progressWrap'); if (pw) pw.classList.remove('hidden');
  const pb = $('#progressBar'); if (pb) pb.style.width = (evt.pct != null ? evt.pct : 10) + '%';
  const pt = $('#progressText');
  if (pt) pt.textContent = (evt.label || '正在搜索对手…') + (evt.found ? '（已发现 ' + evt.found + ' 个）' : '');
}
function buildBrandCard(card, tier) {
  const el = document.createElement('article');
  // 复用 skeleton 视觉（避免新增 CSS）；brand-live 仅作语义标记
  el.className = 'card status-skeleton brand-live';
  el.dataset.cid = card.id;
  const tierLabel = TIER_LABEL[card.tier] || '体量未明';
  let html = '<div class="card-head">'
    + '<div class="card-title"><h3>' + esc(card.name) + '</h3>'
    + (card.url ? '<a class="ext" href="' + escAttr(card.url) + '" target="_blank" rel="noopener" onclick="event.stopPropagation()">↗</a>' : '')
    + '</div>'
    + '<div class="badges">'
    + '<span class="pill tier ' + (card.tier || 'unknown') + '">' + tierLabel + '</span>'
    + (card.matchScore ? '<span class="pill match">匹配 ' + card.matchScore + '</span>' : '')
    + (tier === 'lead' ? '<span class="pill st researching">检索中…</span>' : '<span class="pill st">待调研</span>')
    + '</div></div>';
  if (card.why) html += '<p class="why">' + esc(card.why) + '</p>';
  html += (tier === 'lead') ? '<p class="hint">正在确认是否为对手…</p>' : '<p class="hint">已识别，等待 AI 逐家深研…</p>';
  el.innerHTML = html;
  return el;
}
function onBrandFound(evt) {
  const card = evt.card; if (!card || !card.id) return;
  let grid = document.querySelector('.pano-cards');
  if (!grid) {
    const wrap = $('#competitorList'); if (!wrap) return;
    grid = document.createElement('div'); grid.className = 'pano-cards'; wrap.appendChild(grid);
  }
  const existing = grid.querySelector('.card[data-cid="' + cssEscape(card.id) + '"]');
  const node = buildBrandCard(card, evt.tier);
  if (existing) grid.replaceChild(node, existing); // lead→skeleton 升级（同 id 时）
  else grid.appendChild(node); // 增量追加
}
function onBrandRemoved(evt) {
  if (!evt || !evt.id) return;
  const grid = document.querySelector('.pano-cards'); if (!grid) return;
  const el = grid.querySelector('.card[data-cid="' + cssEscape(ev.id) + '"]');
  if (el) el.remove();
}
async function onDiscoverComplete(evt) {
  discovering = false; discoverErrored = false;   // ▶ 加固：收尾后清除报错标记，允许后续新发现
  const pw = $('#progressWrap'); if (pw) pw.classList.add('hidden');
  // 全量拉取权威状态（含 skeleton + 深研进度），交给既有 renderAll 渲染（移除 lead 临时卡、就位 skeleton）
  try {
    const s = await api('/api/state');
    state = s;
    if (s.track) state.track = s.track;
    enterReport();   // 全量重渲染，与后端权威状态对齐
    startPolling();  // 续接深研增量（SSE/轮询）
  } catch (e) { /* 忽略：后续轮询会自愈 */ }
}
function onDiscoverError(evt) {
  // ▶ 加固（发现链路 F2）：回放事件已处理过则跳过——连点/SSE 重连不重复弹
  if (discoverErrored && !discovering) return;
  discovering = false; discoverErrored = true;
  const code = evt && evt.code;
  const msg = (evt && evt.message)
    || (code === 'NO_KEYS' ? '未配置 API 密钥，请在设置中填入搜索源与 DeepSeek 密钥。'
       : code === 'quota' ? '研究额度已用尽，请升级套餐或稍后再试。'
       : '识别失败，请稍后重试。');
  // ▶ 加固（发现链路 F3）：原地显示失败原因 + 重试/返回入口，不弹回 onboarding——避免"以为工具坏了"直接走人
  const pw = $('#progressWrap');
  if (pw) {
    pw.classList.remove('hidden');
    const pb = $('#progressBar'); if (pb) pb.style.width = '100%';
    const pt = $('#progressText');
    if (pt) pt.textContent = '⚠ 研究未完成：' + msg;
    showDiscoverErrorActions(code); // 失败原因 + 重试/返回入口
  }
  stopPolling();
  // 注意：不再调用 showOnboarding()——避免"弹走=以为工具坏了"
}
// ▶ 加固（发现链路 F3）：失败原因面板 + 操作入口（挂载在 #progressWrap 内）
function showDiscoverErrorActions(code) {
  const wrap = $('#progressWrap'); if (!wrap) return;
  let box = document.getElementById('discoverErrorBox');
  if (!box) {
    box = document.createElement('div');
    box.id = 'discoverErrorBox';
    box.className = 'discover-error-box';
    wrap.appendChild(box);
  }
  box.innerHTML = ''
    + '<p class="hint">可能是 API 密钥失效或网络不可达。请到「设置」核对搜索源与 DeepSeek 密钥后重试。</p>'
    + '<div class="row">'
    +   '<button id="btnRetryDiscover" class="btn primary">重试</button>'
    +   '<button id="btnGotoOnboarding" class="btn ghost">返回入口</button>'
    + '</div>';
  const retryBtn = document.getElementById('btnRetryDiscover');
  if (retryBtn) retryBtn.onclick = () => {
    box.remove();
    const ti = document.getElementById('trackInput');
    if (ti && typeof state === 'object' && state.track) ti.value = state.track;
    discover(); // 复用 discover() 重新发起
  };
  const backBtn = document.getElementById('btnGotoOnboarding');
  if (backBtn) backBtn.onclick = () => { box.remove(); showOnboarding(); };
}
// SSE 断开时的发现阶段兜底：直接读状态增量渲染骨架卡，检测到 discoverDone 即收尾
async function discoverPoll() {
  try {
    const s = await api('/api/state');
    if (s.discoverDone) { onDiscoverComplete({}); return; }
    const cs = (s.competitors || []);
    cs.forEach(c => onBrandFound({ tier: 'skeleton', card: c }));
    const pw = $('#progressWrap'); if (pw) pw.classList.remove('hidden');
    const pb = $('#progressBar'); if (pb) pb.style.width = '80%';
    const pt = $('#progressText'); if (pt) pt.textContent = '已发现 ' + cs.length + ' 个对手，正在汇总…';
  } catch {}
}
// renderAll 后刷新签名，避免用户主动操作触发的重渲染被下一 tick 误判为「未变」
function markStateSig() { _stateSig = stateSig(state); }

// ---------- 渲染 ----------
// ============ 全景汇报 · 可视化增强（P1–P3） ============
// 价格中点：优先 pricePoints（数值数组，无需解析），否则复用 lib 统一解析器 window.parsePriceRange
// （由 server 注入 index.html，见《实测反馈·全量技术整改架构》P0 价格解析统一——删除前端镜像，千分位不再错位）
function priceMidOf(c) {
  if (c.pricePoints && c.pricePoints.length) {
    const v = c.pricePoints.map(Number).filter(n => !isNaN(n));
    if (v.length) return (Math.min(...v) + Math.max(...v)) / 2;
  }
  if (c.priceBand && c.priceBand.range) {
    const pp = (typeof window !== 'undefined' && window.parsePriceRange) || null;
    if (pp) {
      const pr = pp(c.priceBand.range);
      if (pr && pr.length === 2 && !isNaN(pr[0]) && !isNaN(pr[1])) return (pr[0] + pr[1]) / 2;
    }
  }
  return null;
}
const TIER_Y = { large: 85, mid: 60, small: 40, emerging: 25, unknown: 35 };
const TIER_COLOR = { large: '#2b6cb0', mid: '#3182ce', small: '#63b3ed', emerging: '#a0aec0', unknown: '#cbd5e0' };

// 把对手投到「价格 × 定制化程度」坐标（0–100 空间）。价格跨对手归一化；Y=定制化程度(score)，
// 缺失时回退体量梯队分并标 hasCust=false（前端空心点提示"按体量占位，未采集定制化程度"）。
function custY(c) {
  if (c.customization && typeof c.customization.score === 'number')
    return { y: Math.max(0, Math.min(100, c.customization.score)), hasCust: true };
  return { y: TIER_Y[c.tier] || 35, hasCust: false };
}
function quadData(cs) {
  const priced = cs.filter(c => c.status === 'done' && priceMidOf(c) != null);
  const vals = priced.map(c => priceMidOf(c));
  const mn = vals.length ? Math.min(...vals) : 0, mx = vals.length ? Math.max(...vals) : 1;
  const pts = priced.map(c => {
    const m = priceMidOf(c);
    const yv = custY(c);
    return { id: c.id, name: c.name, tier: c.tier, x: mx > mn ? (m - mn) / (mx - mn) * 100 : 50, y: yv.y, hasPrice: true, hasCust: yv.hasCust };
  });
  // 无价数据的已调研对手放在中线（X=50），不假装知道其价位
  cs.filter(c => c.status === 'done' && priceMidOf(c) == null).forEach(c => {
    const yv = custY(c);
    pts.push({ id: c.id, name: c.name, tier: c.tier, x: 50, y: yv.y, hasPrice: false, hasCust: yv.hasCust });
  });
  return { pts, mn, mx };
}
// 你的目标价带 → 象限 X 坐标（与对手同归一化基准）
function youQuadX(price, mn, mx) {
  if (!price || price.min == null || price.max == null) return null;
  const m = (+price.min + +price.max) / 2;
  if (mx <= mn) return 50;
  return (m - mn) / (mx - mn) * 100;
}
// SVG 象限图；opts.youX=你的价格坐标；opts.highlightEmpty=高亮无对手格子（空白地图）
function quadSvg(cs, opts) {
  opts = opts || {};
  const { pts, mn, mx } = quadData(cs);
  const W = 320, H = 220, padL = 38, padB = 28, padT = 14, padR = 14;
  const ix = v => padL + (v / 100) * (W - padL - padR);
  const iy = v => padT + ((100 - v) / 100) * (H - padT - padB);
  let g = '';
  // 网格
  for (let i = 0; i <= 4; i++) {
    const gx = padL + i * (W - padL - padR) / 4, gy = padT + i * (H - padT - padB) / 4;
    g += `<line x1="${gx}" y1="${padT}" x2="${gx}" y2="${H - padB}" stroke="#eef0f4"/>`;
    g += `<line x1="${padL}" y1="${gy}" x2="${W - padR}" y2="${gy}" stroke="#eef0f4"/>`;
  }
  // 三态网格高亮（4×4）：真空位 / 未知 / 死区（颜色口径来自后端 computeWhiteSpaceGrid，前后端一致）
  if (opts.highlightEmpty) {
    if (opts.grid && opts.grid.cells) {
      opts.grid.cells.forEach(cell => {
        if (cell.state === 'occupied') return;
        const x0 = cell.i * 25, x1 = x0 + 25, yTop = 100 - cell.j * 25, yBot = yTop - 25;
        const px = ix(x0), py = iy(yTop), pw = ix(x1) - ix(x0), ph = iy(yBot) - iy(yTop);
        let fill, stroke, label;
        if (cell.state === 'vacant') { fill = '#f3f0ff'; stroke = '#e3dcff'; label = '真空位（确认缺失·在竞争前沿内·可下注）'; }
        else if (cell.state === 'dead') { fill = '#fff4ec'; stroke = '#f0d9c4'; label = '死区（空白但偏离竞争前沿·结构性无机会·勿下注）'; }
        else { fill = '#eef0f2'; stroke = '#d8dde3'; label = '未知·覆盖不足·不可下注'; }
        const cov = (cell.state === 'unknown' && cell.eligibleTotal != null) ? ` · 可定位对手 ${cell.eligibleTotal}` : '';
        g += `<rect x="${px}" y="${py}" width="${pw}" height="${ph}" fill="${fill}" stroke="${stroke}" stroke-dasharray="3 2"><title>${label}${cov}</title></rect>`;
      });
    } else {
      // 兜底：无 grid 时退回旧逻辑（纯空位高亮）
      for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
        const x0 = i * 25, x1 = x0 + 25, yTop = 100 - j * 25, yBot = yTop - 25;
        const cnt = pts.filter(p => p.x >= x0 && p.x < x1 && (100 - p.y) >= yBot && (100 - p.y) < yTop).length;
        if (cnt === 0) {
          const px = ix(x0), py = iy(yTop), pw = ix(x1) - ix(x0), ph = iy(yBot) - iy(yTop);
          g += `<rect x="${px}" y="${py}" width="${pw}" height="${ph}" fill="#f3f0ff" stroke="#e3dcff" stroke-dasharray="3 2"/>`;
        }
      }
    }
  }
  // 坐标轴
  g += `<line x1="${padL}" y1="${H - padB}" x2="${W - padR}" y2="${H - padB}" stroke="#c2c8d2"/>`;
  g += `<line x1="${padL}" y1="${padT}" x2="${padL}" y2="${H - padB}" stroke="#c2c8d2"/>`;
  g += `<text x="${W - padR}" y="${H - padB + 18}" text-anchor="end" class="qax">高价</text>`;
  g += `<text x="${padL}" y="${H - padB + 18}" text-anchor="start" class="qax">低价</text>`;
  g += `<text x="${padL - 6}" y="${padT + 4}" text-anchor="end" class="qax">深定制</text>`;
  g += `<text x="${padL - 6}" y="${H - padB}" text-anchor="end" class="qax">标品/低定制</text>`;
  // 你的目标价带
  if (opts.youX != null) {
    const lx = ix(Math.max(0, Math.min(100, opts.youX)));
    g += `<line x1="${lx}" y1="${padT}" x2="${lx}" y2="${H - padB}" stroke="#6a5acd" stroke-width="1.5" stroke-dasharray="4 3"/>`;
    g += `<text x="${lx}" y="${padT - 2}" text-anchor="middle" class="qyou">你</text>`;
  }
  // 对手点：实心=已采集定制化程度；空心=未采集（按体量占位，不假装知道）
  pts.forEach(p => {
    const cx = ix(p.x), cy = iy(p.y);
    const fill = p.hasCust ? (TIER_COLOR[p.tier] || '#cbd5e0') : '#fff';
    const stroke = p.hasCust ? '#fff' : (TIER_COLOR[p.tier] || '#cbd5e0');
    const tip = `${esc(p.name)}（${p.hasPrice ? '有价数据' : '无价数据'} · ${p.hasCust ? '定制化程度 ' + Math.round(p.y) : '定制化程度未采集·按体量占位'}）`;
    g += `<circle cx="${cx}" cy="${cy}" r="5.5" fill="${fill}" stroke="${stroke}" stroke-width="${p.hasCust ? 1 : 1.6}"><title>${tip}</title></circle>`;
  });
  return `<svg class="quad-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet">${g}</svg>`;
}
// KPI 条
function renderKpiStrip(cs, ws) {
  const done = cs.filter(c => c.status === 'done').length;
  const oppN = ws && ws.gaps ? ws.gaps.filter(g => g.level === 'opportunity').length : 0;
  const pos = ws && ws.positioning;
  const anchor = (pos && pos.hasProfile && pos.price) ? `${pos.price.band.currency} ${pos.price.band.min}–${pos.price.band.max}` : '未填定位';
  return `<div class="pano-kpi">
    <div class="kpi"><div class="kpi-v">${done}</div><div class="kpi-k">已就绪对手</div></div>
    <div class="kpi"><div class="kpi-v">${oppN}</div><div class="kpi-k">可行动空白</div></div>
    <div class="kpi"><div class="kpi-v kpi-anchor">${esc(anchor)}</div><div class="kpi-k">你的定位锚点</div></div>
    <div class="kpi"><div class="kpi-v">${ws ? ws.coverage + '%' : '—'}</div><div class="kpi-k">维度覆盖</div></div>
  </div>`;
}
// 定制化程度单元格（横向对比表用）：带 basis 标签，未采集显示 —
function custCell(c) {
  if (c.customization && typeof c.customization.score === 'number') {
    return c.customization.basis === 'inferred' ? `${c.customization.score}/100 <span class="tag inferred">推算</span>` : `${c.customization.score}/100`;
  }
  return '<span class="muted">—</span>';
}
// 横向对比表（P2）
function renderPanoramaTable(cs) {
  const done = cs.filter(c => c.status === 'done');
  if (!done.length) return '';
  const rows = done.map(c => {
    const tierLabel = TIER_LABEL[c.tier] || '—';
    // #309：明确区分「价格带」(priceBand 区间) 与「单品价」(pricePoints 具体 SKU)，避免单品低价被误读为品牌锚点；币种代码由 curSym 显式带出
    const priceTxt = c.priceBand ? `价格带 ${esc(c.priceBand.range || '')}` : ((c.pricePoints && c.pricePoints.length) ? `单品价 ${curSym(c.currency)}${Math.min(...c.pricePoints)} 起（${c.pricePoints.length} 款在售标价）` : '—');
    const ch = c.channels || {};
    const mainCh = Object.keys(ch).filter(k => ch[k].present).slice(0, 2).map(k => lbl('channels', k)).join('、') || '—';
    const rv = c.reviews;
    const rvTxt = rv && rv.rating != null ? `${rv.rating}${rv.trend === 'down' ? ' ↓' : rv.trend === 'up' ? ' ↑' : ''}` : '—';
    const rel = c.relationship || { code: 'undetermined' };
    const relCls = relClsOf(rel.code);
    return `<tr class="pano-tr" data-rowcid="${escAttr(c.id)}">
      <td class="pano-brand">${esc(c.name)}</td>
      <td>${tierLabel}</td>
      <td>${custCell(c)}</td>
      <td>${priceTxt}</td>
      <td>${esc(mainCh)}</td>
      <td>${esc(rvTxt)}</td>
      <td><span class="rel-${relCls}">${esc(rel.label || REL_LABEL[rel.code] || '—')}</span></td>
    </tr>`;
  }).join('');
  return `<div class="pano-table-wrap">
    <div class="pano-sec-title">横向对比 · 一表看清</div>
    <div class="pano-table-scroll"><table class="pano-table"><thead><tr><th>品牌</th><th>体量</th><th>定制化程度</th><th>价格带</th><th>主力渠道</th><th>口碑</th><th>关系</th></tr></thead>
    <tbody>${rows}</tbody></table></div>
    <p class="pano-tip">点任意行可展开该品牌完整字段。</p>
  </div>`;
}
// 象限区（P3）
function quadSectionHTML(cs, ws) {
  const youX = (ws && ws.positioning && ws.positioning.price && ws.positioning.price.band) ? youQuadX(ws.positioning.price.band, quadData(cs).mn, quadData(cs).mx) : null;
  const svg = quadSvg(cs, { youX });
  const legend = Object.keys(TIER_COLOR).map(t => `<span class="qleg"><i style="background:${TIER_COLOR[t]}"></i>${TIER_LABEL[t] || t}</span>`).join('');
  return `<div class="pano-quad-wrap">
    <div class="pano-sec-title">定位象限 · 价格 × 定制化程度</div>
    <div class="pano-quad-flex">
      ${svg}
      <div class="pano-quad-legend">
        <div class="qleg-title">对手体量（点色）</div>${legend}
        <div class="qleg"><i style="background:#fff;border:1.6px solid #a0aec0"></i>空心点=定制化程度未采集（按体量占位）</div>
      </div>
    </div>
    <p class="pano-tip">X 轴=价格（左低右高），Y 轴=定制化程度（下低上高，0–100）。每个点是已调研对手；实心点=已采集定制化程度，空心点=未采集（按体量占位）。空白格子=暂无对手占据的价格×定制化程度组合（潜在空位）。${youX != null ? ' 紫虚线=你的目标价带。' : ''}</p>
  </div>`;
}
// 空白地图（P4）：同象限，三态网格高亮（真空位 / 未知 / 死区）
function renderWhiteSpaceMapSection(ws, cs) {
  const youX = (ws && ws.positioning && ws.positioning.price && ws.positioning.price.band) ? youQuadX(ws.positioning.price.band, quadData(cs).mn, quadData(cs).mx) : null;
  const svg = quadSvg(cs, { youX, highlightEmpty: true, grid: ws && ws.grid });
  const grid = ws && ws.grid;
  const elig = grid && grid.eligibleTotal != null ? grid.eligibleTotal : 0;
  return `<div class="pano-quad-wrap ws-map">
    <div class="pano-sec-title">空白地图 · 三态网格（真空位 / 未知 / 死区）</div>
    <div class="pano-quad-flex">
      ${svg}
      <div class="pano-quad-legend">
        <div class="qleg-title">图例</div>
        <div class="qleg"><i style="background:#e3dcff"></i>真空位（确认缺失·在竞争前沿内·可下注）</div>
        <div class="qleg"><i style="background:#fff4ec"></i>死区（空白但偏离竞争前沿·结构性无机会）</div>
        <div class="qleg"><i style="background:#eef0f2"></i>未知·覆盖不足·不可下注</div>
        <div class="qleg"><i style="background:#6a5acd"></i>你的目标价带</div>
        ${Object.keys(TIER_COLOR).map(t => `<span class="qleg"><i style="background:${TIER_COLOR[t]}"></i>${TIER_LABEL[t] || t}</span>`).join('')}
        <div class="qleg"><i style="background:#fff;border:1.6px solid #a0aec0"></i>空心点=定制化程度未采集（按体量占位）</div>
      </div>
    </div>
    <p class="pano-tip">三态着色把「空」拆开：紫色=真空位（有对手在相邻价位/定制带、只是这格没人，可下注）；琥珀=死区（价位带与定制带都无人，偏离竞争前沿，别人不在这玩有原因，勿下注）；灰色=未知（可定位对手仅 ${elig} 家，覆盖不足，不可下注）。下方按维度列出的空白卡片才是可行动结论，请勿仅凭此图下注。${elig < 3 ? ' 提示：补齐各对手的「价格带 + 定制化程度」后，网格才能区分真空位与死区。' : ''}</p>
  </div>`;
}
// ============================================================
// 蓝海要素曲线（③）：一维，表达「全行业趋同处」vs「无人区」
// 横轴＝某要素维度的各个桶；纵轴＝落在该桶的对手「绝对计数」。
// 红/蓝着色＝相对当前数据的分布判断（≥半数对手同桶＝红海，零对手＝蓝海空位），非绝对门槛。
// 与机会地图同纪律：绝对数照常展示 + 明确「相对当前数据」标注。
// ============================================================
let blueOceanDim = 'channels';
const BO_STATE = {
  red_ocean: { color: '#e5484d', label: '红海' },
  moderate:  { color: '#c9a227', label: '适中' },
  blue_gap:  { color: '#1f6fb2', label: '蓝海空位' },
  unknown:   { color: '#9aa0aa', label: '覆盖不足' }
};
function blueOceanLabel(group, key) {
  if (group === 'channels') return (LABELS.channels && LABELS.channels[key]) || key;
  if (group === 'sellingPoints') return SP_ZH[key] || prettyKey(key);
  if (group === 'tier') return TIER_LABEL[key] || key;
  if (group === 'priceBand') return (LABELS.priceBands && LABELS.priceBands[key]) || key;
  return key;
}
function blueOceanCurveSvg(dim) {
  const buckets = dim.buckets;
  const W = 780, H = 330, ml = 40, mr = 16, mt = 26, mb = 78;
  const pw = W - ml - mr, ph = H - mt - mb;
  const maxC = Math.max(1, ...buckets.map(b => b.count));
  const n = buckets.length;
  const step = n > 1 ? pw / (n - 1) : 0;
  const xOf = i => ml + (n > 1 ? i * step : pw / 2);
  const yOf = c => mt + ph - (c / maxC) * ph;
  let grid = '', bars = '', pts = '', line = '', labels = '', xlabels = '';
  const ticks = 4;
  for (let t = 0; t <= ticks; t++) {
    const v = Math.round((maxC * t) / ticks);
    const y = yOf(v);
    grid += `<line x1="${ml}" y1="${y}" x2="${W - mr}" y2="${y}" stroke="#eceef2" stroke-width="1"/>`;
    grid += `<text x="${ml - 6}" y="${y + 3}" text-anchor="end" class="bo-axis">${v}</text>`;
  }
  buckets.forEach((b, i) => {
    const x = xOf(i), y = yOf(b.count);
    const st = BO_STATE[b.state] || BO_STATE.unknown;
    const bw = Math.min(30, step * 0.46);
    bars += `<rect x="${x - bw / 2}" y="${y}" width="${bw}" height="${mt + ph - y}" fill="${st.color}" opacity="0.15" rx="3"/>`;
    const tip = `${blueOceanLabel(dim.group, b.key)}｜对手 ${b.count} 家（${b.share}%）`
      + (b.state === 'blue_gap' ? ' · 蓝海空位（当前无人）' : b.state === 'red_ocean' ? ' · 红海（≥半数对手同桶）' : '');
    pts += `<circle cx="${x}" cy="${y}" r="5" fill="${st.color}"><title>${esc(tip)}</title></circle>`;
    line += (i === 0 ? `M${x},${y}` : ` L${x},${y}`);
    labels += `<text x="${x}" y="${y - 10}" text-anchor="middle" class="bo-val">${b.count}</text>`;
    const lab = blueOceanLabel(dim.group, b.key);
    const rot = lab.length > 4 ? -35 : 0;
    xlabels += `<text x="${x}" y="${mt + ph + 16}" text-anchor="end" transform="rotate(${rot} ${x} ${mt + ph + 16})" class="bo-xlab" fill="${st.color}">${esc(lab)}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}" class="bo-svg" preserveAspectRatio="xMidYMid meet">${grid}${bars}<path d="${line}" fill="none" stroke="#b9c0cc" stroke-width="1.5"/>${pts}${labels}${xlabels}<text x="12" y="${mt + 4}" class="bo-axis">对手数</text></svg>`;
}
function renderBlueOceanSection(bo, cs) {
  if (!bo || !bo.dimensions) return '';
  const dimKeys = Object.keys(bo.dimensions);
  const dim = bo.dimensions[blueOceanDim] || bo.dimensions[dimKeys[0]];
  const chips = dimKeys.map(k => {
    const d = bo.dimensions[k];
    const t = d.insufficient ? ' · 覆盖不足' : '';
    return `<button class="bo-chip ${k === blueOceanDim ? 'active' : ''}" data-dim="${k}">${esc(d.label)}${t}</button>`;
  }).join('');
  const relTag = '<span class="tag rel">相对当前数据</span>';
  let denom, body;
  if (dim.insufficient) {
    denom = `<div class="bo-denom warn">可定位对手仅 <b>${dim.eligible}</b> 家（门槛 ${dim.minCoverage}），本维度覆盖不足，不画结论。</div>`;
    body = `<div class="bo-insuf">该维度当前可定位对手不足，无法判断红海 / 蓝海。补齐更多对手的「${esc(dim.label)}」字段后再看。</div>`;
  } else {
    denom = `<div class="bo-denom">可定位对手 <b>${dim.eligible}</b> 家 · 趋同度（最高桶占比）<b>${dim.convergenceIndex}%</b> · 红海桶 ${dim.redOceanBuckets} · 蓝海空位 ${dim.blueGapBuckets}</div>`;
    body = blueOceanCurveSvg(dim);
  }
  return `<div class="ws-section bo-section">
    <h4>蓝海要素曲线 · 全行业趋同处 vs 无人区 ${relTag}</h4>
    <p class="ws-desc">横轴＝某要素维度的各个桶；纵轴＝落在该桶的对手<b>绝对计数</b>。高点＝红海（大家都挤），零＝蓝海空位（无人，但「没人做」≠「该做」，需结合品类判断）。本视图展示的是各桶的对手绝对计数与占比（不是机会分 O/I/S）；与机会地图一致：绝对数照常展示，红/蓝着色为相对当前数据的分布判断。</p>
    <div class="bo-chips">${chips}</div>
    ${denom}
    ${body}
    <div class="bo-legend">
      <span class="bo-lg"><i style="background:#e5484d"></i>红海（≥半数对手同桶）</span>
      <span class="bo-lg"><i style="background:#c9a227"></i>适中</span>
      <span class="bo-lg"><i style="background:#1f6fb2"></i>蓝海空位（零对手）</span>
    </div>
    <div class="ws-method"><span class="muted">推理：</span>${esc(bo.method)}</div>
    <div class="ws-disclaimer">⚠️ ${esc(bo.relativeNote)}</div>
  </div>`;
}
// ============================================================
// 机会地图（Ulwick ODI 改良）：X=满意度、Y=重要性、机会分=I+max(I−S,0)
// 铁律：分母常驻可见、每条可溯源、置信度封顶「中」、覆盖率不足不作排序结论。
// ============================================================
const OPP_ZONE = {
  underserved: { label: '重点机会 · 蓝海', color: '#5DCAA5', fill: 'rgba(29,158,117,0.14)', stroke: '#1D9E75' },
  moderate: { label: '值得关注', color: '#FAC775', fill: 'rgba(186,117,23,0.10)', stroke: '#BA7517' },
  served: { label: '已被满足', color: '#8b95a3', fill: 'rgba(107,118,132,0.08)', stroke: '#3a4452' }
};
function oppScatterSvg(op) {
  const W = 620, H = 380, padL = 54, padR = 22, padT = 22, padB = 48;
  const sx = s => padL + ((s - 1) / 9) * (W - padL - padR);
  const sy = i => padT + ((10 - i) / 9) * (H - padT - padB);
  let g = '';
  // 分区底色：机会分等值线 opp=I+max(I−S,0) → 边界 I=(opp+S)/2（S≤I 区）
  g += `<polygon points="${sx(1)},${sy(8)} ${sx(5)},${sy(10)} ${sx(1)},${sy(10)}" fill="${OPP_ZONE.underserved.fill}" stroke="${OPP_ZONE.underserved.stroke}"/>`;
  g += `<polygon points="${sx(1)},${sy(5.5)} ${sx(10)},${sy(10)} ${sx(5)},${sy(10)} ${sx(1)},${sy(8)}" fill="${OPP_ZONE.moderate.fill}" stroke="${OPP_ZONE.moderate.stroke}"/>`;
  // 网格
  for (let v = 1; v <= 10; v += 1.5) {
    g += `<line x1="${sx(v)}" y1="${padT}" x2="${sx(v)}" y2="${H - padB}" stroke="#2a313c"/>`;
    g += `<line x1="${padL}" y1="${sy(v)}" x2="${W - padR}" y2="${sy(v)}" stroke="#2a313c"/>`;
  }
  // 坐标轴
  g += `<line x1="${padL}" y1="${H - padB}" x2="${W - padR}" y2="${H - padB}" stroke="#3a4452"/>`;
  g += `<line x1="${padL}" y1="${padT}" x2="${padL}" y2="${H - padB}" stroke="#3a4452"/>`;
  g += `<text x="${padL}" y="${H - padB + 18}" text-anchor="start" class="qax">满意度低（多被抱怨）</text>`;
  g += `<text x="${W - padR}" y="${H - padB + 18}" text-anchor="end" class="qax">满意度高（多被夸）</text>`;
  g += `<text x="${padL}" y="${H - padB + 34}" text-anchor="start" class="qax muted">← 满意度（正负提及比代理，1–10）→</text>`;
  g += `<text transform="translate(${padL - 38},${padT + 8}) rotate(-90)" text-anchor="end" class="qax">重要性低</text>`;
  g += `<text transform="translate(${padL - 38},${(H - padB + padT) / 2}) rotate(-90)" text-anchor="middle" class="qax">重要性（提及广度代理）</text>`;
  g += `<text x="${padL + 8}" y="${padT + 16}" class="qzone" fill="${OPP_ZONE.underserved.color}">蓝海 · 重点机会（机会分≥15）</text>`;
  g += `<text x="${sx(6.6)}" y="${sy(9.4)}" class="qzone" fill="${OPP_ZONE.moderate.color}">值得关注 · 10–15</text>`;
  g += `<text x="${sx(7.6)}" y="${sy(3)}" class="qzone" fill="${OPP_ZONE.served.color}">已被满足 / 不够重要</text>`;
  // 点（同坐标去重叠：确定性螺旋偏移，不改变数值，只避免遮挡）
  const used = {};
  let best = null;
  (op.themes || []).forEach((t, idx) => {
    const bx = sx(t.satisfaction), by = sy(t.importance);
    const key = Math.round(bx) + ',' + Math.round(by);
    const k = used[key] = (used[key] == null ? 0 : used[key] + 1);
    const ang = k * 1.0472, rad = k ? 8 + 3 * Math.floor(k / 6) : 0;
    const cx = bx + Math.cos(ang) * rad, cy = by + Math.sin(ang) * rad;
    const z = OPP_ZONE[t.zone] || OPP_ZONE.served;
    const r = 4 + 5 * Math.min(1, t.brandsMentioned / Math.max(1, t.brandsWithVoice));
    const solid = !t.coverageInsufficient;
    const tip = `${esc(t.label)}｜机会分 ${t.opportunity}（重要性 ${t.importance} · 满意度 ${t.satisfaction}）｜${esc(t.denominatorText)}`;
    g += `<circle class="opp-dot" data-oid="${escAttr(t.oid)}" cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${r.toFixed(1)}" fill="${solid ? z.color : '#1b2129'}" fill-opacity="${solid ? 0.82 : 1}" stroke="${z.color}" stroke-width="${solid ? 1 : 1.6}"><title>${tip}</title></circle>`;
    if (!best || t.opportunity > best.opportunity) best = { x: cx, y: cy, r, t };
    if (idx < 5) {
      const lx = cx + r + 4;
      const txt = t.label.length > 9 ? t.label.slice(0, 9) + '…' : t.label;
      g += `<text x="${(lx > W - padR - 60 ? cx - r - 4 : lx).toFixed(1)}" y="${(cy + 3.5).toFixed(1)}" text-anchor="${lx > W - padR - 60 ? 'end' : 'start'}" class="opp-lbl">${esc(txt)}</text>`;
    }
  });
  // ★ 最佳机会标记（机会分最高者）
  if (best) {
    const lx = best.x + best.r + 6;
    const anchor = lx > W - padR - 70 ? 'end' : 'start';
    const tx = anchor === 'end' ? best.x - best.r - 6 : lx;
    g += `<text x="${tx.toFixed(1)}" y="${(best.y - best.r - 6).toFixed(1)}" text-anchor="${anchor}" class="opp-best" fill="#FAC775">★ 最佳机会 · ${esc(best.t.label.length > 10 ? best.t.label.slice(0, 10) + '…' : best.t.label)}</text>`;
  }
  return `<svg class="opp-svg" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid meet">${g}</svg>`;
}
function oppSourceTags(sources) {
  if (!sources || !sources.length) return '';
  const FIELD_ZH = { 'reviews.negThemes': '口碑负面主题', 'reviews.posThemes': '口碑正面主题', 'painPoints': '抱怨点' };
  return '<div class="opp-src">' + sources.slice(0, 8).map(s =>
    `<span class="src-tag ${s.polarity === 'pos' ? 'pos' : 'neg'}" title="${escAttr(s.detail || '')}">${esc(s.name)} · ${esc(FIELD_ZH[s.field] || s.field)}${s.basis === 'verified' ? ' ✓' : ''}</span>`
  ).join('') + (sources.length > 8 ? `<span class="src-more">+${sources.length - 8}</span>` : '') + '</div>';
}
// ▶ #307：机会地图统一视图 —— 卖点空缺（市场空缺，来自空白视图）作默认主层；口碑机会作补充层
function oppMarketGapSection() {
  const ws = (state && state.whiteSpace) || {};
  const gaps = (ws && !ws.hidden && Array.isArray(ws.gaps)) ? ws.gaps : [];
  const market = gaps.filter(g => !g.copyGap && (g.level === 'opportunity' || g.gapKind === 'silent_demand'));
  if (!market.length) return '';
  let h = `<div class="ws-section opp-section opp-market"><h4><span class="opp-zone-dot" style="background:#1f6fb2"></span>卖点空缺 / 市场空缺（对手没占的空位 · 来自空白视图）</h4>
    <p class="ws-desc">下列空位来自「空白视图」：供给侧无人占据、且（需求侧有证据，或薄样本下不定为无需求）。这是最该盯的切入线索；口碑驱动的补充机会见下方「口碑机会」层。</p><div class="opp-list">`;
  market.forEach(g => {
    const gid = g.gid || '';
    const silent = g.gapKind === 'silent_demand';
    const tag = silent ? '<span class="tag warn">沉默需求·待验证</span>' : '';
    const conf = g.confidence || 'low';
    h += `<div class="opp-item" data-gid="${escAttr(gid)}" data-itemtype="marketgap">
      <div class="opp-score" style="border-color:#1f6fb2"><div class="opp-score-v" style="color:#1f6fb2">空位</div><div class="opp-score-k">${esc(g.dim || '')}</div></div>
      <div class="opp-body">
        <div class="opp-title"><span class="gid">${esc(gid)}</span> ${esc(g.value || '')} ${tag}</div>
        <div class="opp-metrics"><span>置信度 <b>${esc(conf)}</b></span>${g.speculative ? '<span class="tag warn">推测</span>' : ''}</div>
        <div class="ws-method"><span class="muted">推理：</span>${esc(g.note || '')}</div>
      </div></div>`;
  });
  h += `</div></div>`;
  return h;
}
function renderOpportunity() {
  const wrap = $('#opportunityContainer');
  if (!wrap) return;
  const op = state.opportunity;
  if (!op) { wrap.innerHTML = '<div class="ws-empty"><h3>机会地图</h3><p>暂无数据。</p></div>'; return; }
  if (op.hidden) {
    // ▶ P1b：薄样本优雅降级——不再塌成空屏，展示已算出的初步主题 + 显著「初步·样本不足」横幅
    const pt = op.preliminaryThemes || [];
    const reasonLine = op.reason === 'need_more_voice'
      ? `需要至少 <b>3</b> 家对手采到评论主题或抱怨点。当前 <b>${op.brandsWithVoice}</b> / ${op.doneBrands} 家有声音（${op.coveragePct}%）。`
      : `需要至少 <b>3</b> 家已就绪对手，当前 <b>${op.doneBrands}</b> 家。`;
    let h = `<div class="ws-head"><h3>机会地图 · 初步（样本不足）</h3>
      <p class="ws-prelim-banner">⚠️ <b>初步信号 · 样本不足</b>：以下不是正式机会图，仅列出目前已识别的用户声音主题，<b>不作排序结论、不标重点机会</b>。${reasonLine}</p>
      <p class="hint">补齐办法：在全景汇报里点开某个品牌卡 → 「补充口碑这块数据」，只补这一块，不用重跑全研。</p>`;
    h += oppMarketGapSection();
    if (pt.length) {
      h += `<div class="opp-denom"><div class="opp-denom-row"><b>分母</b>：${op.brandsWithVoice} / ${op.doneBrands} 家已就绪对手采到了用户声音（覆盖率 ${op.coveragePct}%），共 ${op.mentionsTotal} 条提及。</div>
        <div class="opp-denom-row"><b>推理</b>：${esc(op.method || METHOD_LABEL)}</div></div>
        <div class="ws-section opp-section"><h4><span class="opp-zone-dot" style="background:#b9b9b9"></span>已识别主题（${pt.length}）· 初步</h4>
          <p class="ws-desc">下列主题来自现有用户声音，因样本不足未做分区排名；每条仍带分母与来源，可逐条核验。</p><div class="opp-list">`;
      pt.forEach(t => {
        h += `<div class="opp-item" data-oid="${escAttr(t.oid)}" data-itemtype="opportunity">
          <div class="opp-score" style="border-color:#b9b9b9"><div class="opp-score-v" style="color:#8a8a8a">${t.opportunity}</div><div class="opp-score-k">机会分*</div></div>
          <div class="opp-body">
            <div class="opp-title"><span class="gid">${esc(t.oid)}</span> ${esc(t.label)} <span class="tag warn">初步·样本不足</span></div>
            <div class="opp-metrics"><span>重要性 <b>${t.importance}</b></span><span>满意度 <b>${t.satisfaction}</b></span><span class="opp-denom-inline">${esc(t.denominatorText)}</span></div>
            <div class="ws-disclaimer">⚠️ ${esc(t.note)}</div>
            <div class="ws-method"><span class="muted">推理：</span>${esc(t.method)}</div>
            ${oppSourceTags(t.sources)}
          </div></div>`;
      });
      h += `</div></div>`;
    } else {
      h += `<p class="hint">当前还没有对手留出可识别的用户声音（评论主题 / 抱怨点），暂无可展示的初步信号。继续补齐对手或补采口碑后即可生成正式机会图。</p>`;
    }
    h += `<div class="opp-caveats">${(op.caveats || []).map(c => `<div class="opp-cav">· ${esc(c)}</div>`).join('')}</div></div>`;
    wrap.innerHTML = h;
    return;
  }
  const z = op.zones || {};
  let html = `<div class="ws-head">
    <h3>口碑机会 · 重要但没人做好的地方（补充层）</h3>
    <p>机会分 = 重要性 + max(重要性 − 满意度, 0)。共聚类出 <b>${op.total}</b> 个用户声音主题，其中 <b>${z.underserved || 0}</b> 个落在「重点机会」区。${op.ranked ? '' : '<b class="warn-txt">覆盖率不足，排序仅供参考。</b>'}${op.relativeBands ? ' <b class="warn-txt">分区按「相对当前数据」着色（top 15% 重点机会 / 再 35% 中等），下方 O/I/S 为绝对代理值。</b>' : ''}</p>
  </div>`;
  html += oppMarketGapSection();
  html += `<div class="opp-denom">
    <div class="opp-denom-row"><b>分母</b>：${op.brandsWithVoice} / ${op.doneBrands} 家已就绪对手采到了用户声音（覆盖率 ${op.coveragePct}%），共 ${op.mentionsTotal} 条提及。</div>
    <div class="opp-denom-row"><b>推理</b>：${esc(op.method)}</div>
    <div class="opp-caveats">${(op.caveats || []).map(c => `<div class="opp-cav">· ${esc(c)}</div>`).join('')}</div>
  </div>`;
  html += `<div class="pano-quad-wrap opp-chart">
    <div class="pano-sec-title">机会分布 · 满意度 × 重要性</div>
    ${oppScatterSvg(op)}
    <p class="pano-tip">点的大小＝提及广度（多少家对手的用户声音提到）。空心点＝覆盖率不足、仅供参考。左上角＝很多人在乎、但普遍被抱怨，是最值得下注的位置；右侧＝已经被做好了，硬挤是红海。</p>
  </div>`;
  const ZONE_ORDER = ['underserved', 'moderate', 'served'];
  const ZONE_DESC = {
    underserved: '重要性高、满意度低：多家对手的用户都在抱怨同一件事，且无人被夸做得好。',
    moderate: '有一定普遍性、满意度中等：值得盯，但先确认它是否是你的目标人群真正在乎的。',
    served: '要么已经被做好，要么只有零星提及——不建议作为切入点。'
  };
  ZONE_ORDER.forEach(zk => {
    const list = (op.themes || []).filter(t => t.zone === zk);
    if (!list.length) return;
    const relTag = op.relativeBands ? ' <span class="tag rel">相对当前数据</span>' : '';
    html += `<div class="ws-section opp-section"><h4><span class="opp-zone-dot" style="background:${OPP_ZONE[zk].color}"></span>${OPP_ZONE[zk].label}（${list.length}）${relTag}</h4>
      <p class="ws-desc">${ZONE_DESC[zk]}</p><div class="opp-list">`;
    list.forEach(t => {
      html += `<div class="opp-item" data-oid="${escAttr(t.oid)}" data-itemtype="opportunity">
        <div class="opp-score" style="border-color:${OPP_ZONE[t.zone].color}">
          <div class="opp-score-v" style="color:${OPP_ZONE[t.zone].color}">${t.opportunity}</div>
          <div class="opp-score-k">机会分</div>
        </div>
        <div class="opp-body">
          <div class="opp-title"><span class="gid">${esc(t.oid)}</span> ${esc(t.label)}
            ${t.coverageInsufficient ? '<span class="tag warn">覆盖率不足</span>' : ''}
          </div>
          <div class="opp-metrics">
            <span>重要性 <b>${t.importance}</b></span><span>满意度 <b>${t.satisfaction}</b></span>
            <span class="opp-denom-inline">${esc(t.denominatorText)}</span>
          </div>
          ${t.mergedFrom > 1 ? `<div class="opp-merged"><span class="muted">合并自：</span>${t.members.map(m => `<span class="tag">${esc(m)}</span>`).join('')}</div>` : ''}
          ${t.note ? `<div class="ws-disclaimer">⚠️ ${esc(t.note)}</div>` : ''}
          <div class="ws-method"><span class="muted">推理：</span>${esc(t.method)}</div>
          ${oppSourceTags(t.sources)}
        </div>
      </div>`;
    });
    html += `</div></div>`;
  });
  wrap.innerHTML = html;
  // 点图上的点 → 高亮下方对应卡片
  wrap.querySelectorAll('.opp-dot').forEach(d => {
    d.addEventListener('click', () => {
      const el = wrap.querySelector(`.opp-item[data-oid="${d.dataset.oid}"]`);
      if (!el) return;
      wrap.querySelectorAll('.opp-item.hl').forEach(x => x.classList.remove('hl'));
      el.classList.add('hl');
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  });
}
// ===================== P2：算法资产总览 + 沉默需求 / 趋势推断 =====================

// 收集蓝海维度里指定 gapKind 的桶（沉默需求 / 推测性空白等）
function collectGapBuckets(blueOcean, kind) {
  const out = [];
  const dims = (blueOcean && blueOcean.dimensions) || {};
  Object.keys(dims).forEach(dk => {
    (dims[dk].buckets || []).forEach(b => {
      if (b.gapKind === kind) out.push({ dim: dk, key: b.key, demandEvidence: b.demandEvidence, gapNote: b.gapNote, crossAxis: b.crossAxis });
    });
  });
  return out;
}

// 单条资产行：名称 / 状态 / 一句话发现 / 覆盖
function assetRow(name, status, cls, finding, coverage) {
  return `<tr><td><b>${esc(name)}</b></td><td><span class="asset-st asset-${cls}">${status}</span></td><td>${esc(finding)}</td><td class="muted">${esc(coverage)}</td></tr>`;
}

// 算法资产总览：一眼看全本赛道引擎算出的每份派生数据（是否算出 + 一句话发现 + 覆盖状态）
function renderAssetIndex(r) {
  if (!state) return '<p class="hint">无数据。</p>';
  const sec = (r && r.sector) || {};
  const conc = sec.concentration || {};
  const excluded = new Set(state.excluded || []);
  const cs = (state.competitors || []).filter(c => !excluded.has(c.id) && c.status === 'done');
  const bo = state.blueOcean || {};
  const ws = state.whiteSpace || {};
  const radar = state.radar || {};
  const tv = state.trendView || {};
  const opp = state.opportunity || {};

  const secPriceBands = sec.priceBands || [];
  const gapsEmpty = secPriceBands.filter(g => (g.count || 0) <= 1).length;
  const wsGaps = (r && r.whitespace && (r.whitespace.whitespace || r.whitespace.gaps)) || [];
  const trendItems = (r && r.trend && Array.isArray(r.trend) ? r.trend : (r && r.trend && (r.trend.items || []))) || [];
  const silentBuckets = collectGapBuckets(bo, 'silent_demand');
  const heroCount = cs.filter(c => c.heroProduct && c.heroProduct.heroProducts && c.heroProduct.heroProducts.length).length;

  const rows = [];
  rows.push(assetRow('赛道集中度', conc.HHI != null ? '已算出' : '未算出', conc.HHI != null ? 'ok' : 'idle',
    conc.HHI != null ? `HHI ${conc.HHI}（${esc(conc.hhiInterpretation || '')}）· CR3 ${fmtPct(conc.CR3)} · CR5 ${fmtPct(conc.CR5)}` : '尚未聚合', `${r ? (r.brandCount || 0) : 0} 家参与`));
  rows.push(assetRow('品牌横向对比', cs.length > 0 ? '已算出' : '未算出', cs.length > 0 ? 'ok' : 'idle', `${cs.length} 家已就绪（主推 / 价格带 / 体量）`, `${cs.length} 家`));
  rows.push(assetRow('价格带空档', secPriceBands.length > 0 ? '已算出' : '未算出', secPriceBands.length > 0 ? 'ok' : 'idle', secPriceBands.length ? `共 ${secPriceBands.length} 档，其中 ${gapsEmpty} 档仅 ≤1 家（★ 空档）` : '无价格带数据', `${secPriceBands.length} 档`));
  const painOpp = renderPainOpportunityTable(cs);
  rows.push(assetRow('痛点机会表', painOpp ? '已算出' : '未触发', painOpp ? 'ok' : 'idle', painOpp ? '已聚合对手抱怨点，标「未解决 = 机会」' : '暂无对手抱怨点', painOpp ? '已算出' : '未触发'));
  const chRows = (sec.channelMatrix && sec.channelMatrix.rows) || [];
  rows.push(assetRow('渠道矩阵', chRows.length > 0 ? '已算出' : '未算出', chRows.length > 0 ? 'ok' : 'idle', chRows.length ? `${chRows.length} 个渠道 × ${chRows[0].brands ? chRows[0].brands.length : 0} 家` : '无渠道数据', `${chRows.length} 渠道`));
  rows.push(assetRow('赛道空白（对手留的空位）', wsGaps.length > 0 ? '已算出' : '未触发', wsGaps.length > 0 ? 'ok' : 'idle', wsGaps.length ? `共 ${wsGaps.length} 条候选空位` : '暂无', `${wsGaps.length} 条`));
  rows.push(assetRow('赛道趋势', trendItems.length > 0 ? '已算出' : '未触发', trendItems.length > 0 ? 'ok' : 'idle', trendItems.length ? `${trendItems.length} 条趋势推断` : '暂无', `${trendItems.length} 条`));
  const wsComputed = !!(ws && !ws.hidden);
  const wsLevelCounts = (ws && ws.gaps) ? ws.gaps.reduce((a, g) => { const k = g.level || 'unknown'; a[k] = (a[k] || 0) + 1; return a; }, {}) : {};
  rows.push(assetRow('三态网格（真空位/未知/死区）', wsComputed ? '已算出' : (ws.hidden ? '样本不足·初步' : '未触发'), wsComputed ? 'ok' : (ws.hidden ? 'warn' : 'idle'),
    wsComputed ? `真空位 ${wsLevelCounts.vacuum || 0} · 未知 ${wsLevelCounts.unknown || 0} · 死区 ${wsLevelCounts.dead || 0}` : '样本不足或采集覆盖有限', wsComputed ? '已算出' : (ws.hidden ? '样本不足' : '未触发')));
  const boDims = bo.dimensions ? Object.keys(bo.dimensions).length : 0;
  rows.push(assetRow('蓝海要素曲线', boDims > 0 ? '已算出' : '未触发', boDims > 0 ? 'ok' : 'idle', boDims ? `${boDims} 个维度 · 已施加推理纪律 v2（供需交叉 / 边界 / 降级）` : '无', boDims ? `${boDims} 维` : '未触发'));
  rows.push(assetRow('定位象限（强度 × 机会）', '按需触发', 'idle', '点击「品类扫描」下的象限视图实时计算', '按需'));
  const gs = radar.groupSignals || [];
  rows.push(assetRow('雷达群体异动', '已算出', 'ok', gs.length ? `${gs.length} 条跨对手集体异动信号` : '近阶段暂无集体异动', `${gs.length} 条`));
  rows.push(assetRow('主推产品推理', cs.length > 0 ? '已算出' : '未算出', cs.length > 0 ? 'ok' : 'idle', cs.length ? `${heroCount}/${cs.length} 家识别到主推（推算）` : '无', `${heroCount} 家`));
  rows.push(assetRow('对手时间线', '按需触发', 'idle', '点击品牌卡展开时间线', '按需'));
  const oppComputed = !!(opp && !opp.hidden);
  rows.push(assetRow('机会地图（旗舰·空白视图）', oppComputed ? '已算出' : (opp.hidden ? '样本不足·初步' : '未触发'), oppComputed ? 'ok' : (opp.hidden ? 'warn' : 'idle'),
    oppComputed ? `共 ${opp.total != null ? opp.total : '—'} 个用户声音主题，${opp.zones ? (opp.zones.underserved != null ? opp.zones.underserved : '—') : 0} 个落在重点机会区` : (opp.reason === 'need_more_voice' ? `样本不足：仅 ${opp.brandsWithVoice != null ? opp.brandsWithVoice : '—'}/${opp.doneBrands != null ? opp.doneBrands : '—'} 家有声音` : `样本不足：仅 ${opp.doneBrands != null ? opp.doneBrands : '—'} 家已就绪`), oppComputed ? '已算出' : (opp.hidden ? '样本不足·初步' : '未触发')));
  rows.push(assetRow('沉默需求盲区（零提及≠无需求）', bo.silentDemandHint ? '已识别' : (bo.dimensions ? '已排除' : '未触发'), bo.silentDemandHint ? 'warn' : (bo.dimensions ? 'ok' : 'idle'),
    bo.silentDemandHint ? `${silentBuckets.length} 个空白桶可能为未被供给激活的沉默需求` : '需求样本充足，无沉默盲区', bo.silentDemandHint ? `${silentBuckets.length} 桶` : (bo.dimensions ? '已排除' : '未触发')));
  rows.push(assetRow('赛道冷热推断', tv.label ? (tv.failSafe ? '趋势未知·诚实' : '已算出') : '未触发', tv.label ? (tv.failSafe ? 'warn' : 'ok') : 'idle',
    tv.label ? `${tv.label}${tv.failSafe ? '（信号不足，未臆造）' : ''}` : '未计算', tv.label ? (tv.failSafe ? '诚实披露' : '已算出') : '未触发'));

  let html = `<div class="cat-head"><div><h3>算法资产总览</h3><span class="muted">本赛道引擎算出的每份派生数据——是否算出、一句话发现、覆盖状态。点「品类扫描 / 雷达」看明细。</span></div></div>`;
  html += `<table class="cat-table asset-index"><thead><tr><th>派生资产</th><th>状态</th><th>一句话发现</th><th>覆盖</th></tr></thead><tbody>${rows.join('')}</tbody></table>`;
  return html;
}

// 沉默需求视图：把「零提及≠无需求」盲区显式画出来（忠实助理核心纪律之一）
function renderSilentDemand() {
  const bo = state.blueOcean || {};
  const buckets = collectGapBuckets(bo, 'silent_demand');
  const specBuckets = collectGapBuckets(bo, 'speculative_gap');
  let html = `<div class="cat-sec silent-demand-sec"><h4>沉默需求盲区 · 零提及 ≠ 无需求</h4>`;
  if (bo.silentDemandNote) html += `<p class="ws-prelim-banner">⚠️ ${esc(bo.silentDemandNote)}</p>`;
  if (!buckets.length && !specBuckets.length) {
    html += `<p class="hint">当前需求样本充足（≥3 家有用户声音），空白桶的「无需求」结论可信，未识别到沉默需求盲区。${bo.dimensions ? '' : '（蓝海视图未计算）'}</p></div>`;
    return html;
  }
  const renderBucket = b => `<div class="opp-item" data-itemtype="silent">
      <div class="opp-body">
        <div class="opp-title"><span class="gid">${esc(b.dim)} · ${esc(b.key)}</span> <span class="tag warn">推算</span></div>
        <div class="opp-metrics"><span>需求侧证据：<b>${esc(b.demandEvidence || '无')}</b></span><span>供给轴：<b>${esc(b.crossAxis || 'supply-only')}</b></span></div>
        <div class="ws-disclaimer">⚠️ ${esc(b.gapNote || '')}</div>
        <div class="ws-method"><span class="muted">推理：</span>供给侧空且需求侧无证据，但需求样本薄——可能为未被供给激活的沉默需求，不得断言「无需求」，须人工验证。</div>
      </div></div>`;
  if (buckets.length) {
    html += `<p class="ws-desc">下列空白桶：供给侧无人占据、需求侧也无证据，但需求样本薄（&lt;3 家有用户声音）——可能是「未被供给激活的沉默需求」，而非真无需求。均按推算处理，置信锁 low，须人工验证。</p><div class="opp-list">`;
    html += buckets.map(renderBucket).join('');
    html += `</div>`;
  }
  if (specBuckets.length) {
    html += `<p class="ws-desc">另有推测性空白（需求侧无法判定）：</p><div class="opp-list">`;
    html += specBuckets.map(renderBucket).join('');
    html += `</div>`;
  }
  html += `</div>`;
  return html;
}

// 趋势推断视图：赛道冷热 + 每条趋势结论必带可证伪检验点
function renderTrendInference(r) {
  const tv = state.trendView || {};
  const inferences = (r && r.trend && Array.isArray(r.trend)) ? r.trend : [];
  let html = `<div class="cat-sec trend-sec"><h4>趋势推断 · 赛道冷热与可证伪检验点</h4>`;
  if (tv.label) {
    html += `<div class="opp-denom"><div class="opp-denom-row"><b>赛道冷热</b>：${esc(tv.label)}${tv.hotScore != null ? `（hotScore ${tv.hotScore}）` : ''}</div>`;
    if (tv.distribution) html += `<div class="opp-denom-row"><b>分布</b>：上升 ${tv.distribution.rising} · 平稳 ${tv.distribution.stable} · 下滑 ${tv.distribution.declining} · 未知 ${tv.distribution.unknown}（样本 ${tv.total} 家，有效信号 ${tv.withSignal}）</div>`;
    html += `</div>`;
    if (tv.note) html += `<p class="ws-desc">${esc(tv.note)}</p>`;
  } else {
    html += `<p class="hint">趋势视图未计算。</p>`;
  }
  if (tv.checkpoint && tv.checkpoint.falsifiable) {
    html += `<div class="ws-method"><span class="muted">检验点（可证伪）：</span>${esc(tv.checkpoint.test || '')}${tv.checkpoint.horizonDays ? `（窗口 ${tv.checkpoint.horizonDays} 天）` : ''}</div>`;
  }
  if (inferences.length) {
    html += `<div class="opp-list">`;
    inferences.forEach(i => {
      const basisTag = i.basis === 'analogy' ? '<span class="tag warn">类比外推·低置信</span>' : (i.confidence === 'unknown' ? '<span class="tag">不可推断</span>' : '<span class="tag">结构派生</span>');
      html += `<div class="opp-item" data-itemtype="trend">
        <div class="opp-body">
          <div class="opp-title">${esc(i.claim || '')} ${basisTag}</div>
          ${i.note ? `<div class="ws-desc">${esc(i.note)}</div>` : ''}
          ${i.checkpoint && i.checkpoint.test ? `<div class="ws-method"><span class="muted">检验点：</span>${esc(i.checkpoint.test)}${i.checkpoint.horizonDays ? `（窗口 ${i.checkpoint.horizonDays} 天）` : ''}</div>` : ''}
        </div></div>`;
    });
    html += `</div>`;
  }
  html += `</div>`;
  return html;
}

async function renderAssetsTab() {
  const wrap = $('#assetsWrap');
  if (!wrap || !state) return;
  wrap.innerHTML = '<p class="hint">正在汇总本赛道的算法产出…</p>';
  let r = null;
  try {
    r = await api('/api/sector', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sectorName: state.track || 'sector' }) });
  } catch (e) { r = null; }
  // P1-4 修复：任何渲染异常都不允许留下空白面板——统一兜底为空态提示
  try {
    wrap.innerHTML = renderAssetIndex(r) + renderSilentDemand() + renderTrendInference(r);
  } catch (e) {
    wrap.innerHTML = `<div class="empty"><div class="big">算法资产汇总失败</div><div class="sub">${esc((e && e.message) || String(e))}。可返回工作台重试。</div></div>`;
  }
}

// ---------- Phase B：决策工作台（L4）----------
// 待批材料：收 / 忽略 / 稍后。裁决本地记录（localStorage），绝不替用户决定，不收集用户私有数据。
// U4：材料卡按《UI设计规范》§4.1 渲染（信号色条/证据徽章/来源chips/推算影响面/未探测标注），数据驱动，消灭硬编码。
const WB_KEY = 'ci_workbench_decisions';
const WB_ACTIONS = { keep: '收了', ignore: '忽略', later: '稍后' };
function wbLoad() { try { return JSON.parse(localStorage.getItem(WB_KEY) || '{}'); } catch { return {}; } }
function wbSave(d) { localStorage.setItem(WB_KEY, JSON.stringify(d)); }
function wbDecision(matId) { return (wbLoad())[matId] || null; }
function wbSet(matId, action) {
  const d = wbLoad();
  if (d[matId] === action) delete d[matId]; else d[matId] = action; // 再点取消
  wbSave(d);
  renderWorkbench(); // 重渲染列表（含已批状态）
  updateWbBadges();
}
// ---- U5：工作台筛选（设计稿 §4 filters：状态 × 类型 双组单选） ----
const wbFilter = { st: 'all', tp: null }; // st: all/pending/kept/dropped；tp: down/new/channel/crisis/null=不限
function wbTypeGroup(m) {
  const t = (m.type || '').toLowerCase();
  const s = m.signal || '';
  if (t.includes('down') || t.includes('up') || t.includes('price') || s === 'down' || s === 'up') return 'down'; // 跟价
  if (t.includes('channel')) return 'channel'; // 新渠道
  if (t.includes('crisis') || t.includes('review')) return 'crisis'; // 口碑
  return 'new'; // 上新 / 其他（launch/new）
}
function wbPass(m) {
  const d = wbLoad()[m.id];
  if (wbFilter.st === 'pending' && d && d !== 'later') return false;
  if (wbFilter.st === 'kept' && d !== 'keep') return false;
  if (wbFilter.st === 'dropped' && d !== 'ignore') return false;
  if (wbFilter.tp && wbTypeGroup(m) !== wbFilter.tp) return false;
  return true;
}
function bindWbFilters() {
  const box = $('#wbFilters');
  if (!box) return;
  const STATE_F = ['all', 'pending', 'kept', 'dropped'];
  box.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const f = chip.dataset.f;
      if (STATE_F.includes(f)) {
        if (wbFilter.st === f) return; // 已选中不重复
        wbFilter.st = f;
        box.querySelectorAll('.chip[data-f^="all"],.chip[data-f^="pending"],.chip[data-f^="kept"],.chip[data-f^="dropped"]').forEach(c => c.classList.toggle('on', c.dataset.f === f));
      } else {
        wbFilter.tp = (wbFilter.tp === f) ? null : f; // 再点取消 → 不限类型
        box.querySelectorAll('.chip[data-f="down"],.chip[data-f="new"],.chip[data-f="channel"],.chip[data-f="crisis"]').forEach(c => c.classList.toggle('on', c.dataset.f === wbFilter.tp));
      }
      renderWorkbench();
    });
  });
}
// ---- U4 归一化：把后端材料 / mock 材料映射为原型卡片视图模型 ----
function wbSignalOf(m) {
  const t = (m.type || '').toLowerCase();
  if (t.includes('down') || m.signal === 'down') return 'down';
  if (t.includes('up') || m.signal === 'up') return 'up';
  if (t.includes('crisis') || m.signal === 'crisis') return 'crisis';
  if (t.includes('launch') || t.includes('new') || m.signal === 'new') return 'new';
  // P1-5 修复：跟价 = 价格信号，独立专色（灰蓝中性），不再借用「上新」蓝——避免用户把跟价误读成上新
  if (t.includes('price') || m.signal === 'price') return 'price';
  return 'new';
}
function wbTypeLabel(m) {
  const t = (m.type || '').toLowerCase();
  if (t.includes('down')) return '跟价 · 降价';
  if (t.includes('up')) return '跟价 · 涨价';
  if (t.includes('launch')) return '上新';
  if (t.includes('channel')) return '新渠道';
  if (t.includes('crisis')) return '口碑 · 差评暴涨';
  if (t.includes('price')) return '跟价';
  return m.typeLabel || m.type || '信号';
}
function wbEvidence(m) {
  const tier = m.evidenceTier || (m.basis === 'verified' ? 'verified' : m.basis === 'inferred' ? 'inferred' : 'unknown');
  return {
    cls: tier === 'verified' ? 'ev-ok' : tier === 'inferred' ? 'ev-warn' : 'ev-unk',
    txt: tier === 'verified' ? '已核实' : tier === 'inferred' ? '推算' : '未探测',
  };
}
function wbPriceHTML(m) {
  const p = m.price;
  if (!p || (p.old == null && p.new == null)) return '';
  const cur = p.currency || 'USD';
  const up = (p.deltaPct || 0) > 0;
  return `<div class="mat-price">
    ${p.old != null ? `<span class="mp-old num">${wbMoney(p.old, cur)}</span>` : ''}
    <span class="mp-new num${up ? ' up' : ''}">${wbMoney(p.new, cur)}</span>
    ${p.deltaPct != null ? `<span class="mp-delta num${up ? ' up' : ''}">${up ? '▲' : '▼'} ${Math.abs(p.deltaPct)}%</span>` : ''}
    ${p.range ? `<span class="mp-range">市场区间 ${wbMoney(p.range.min, cur)} – ${wbMoney(p.range.max, cur)}</span>` : ''}
  </div>`;
}
function wbMoney(v, cur) {
  const sym = { GBP: '£', USD: '$', CNY: '¥', EUR: '€' }[cur] || (cur + ' ');
  return sym + Number(v).toLocaleString('en-US', { maximumFractionDigits: 0 });
}
function wbSourcesHTML(m) {
  const ss = m.sources || [];
  if (!ss.length) return '';
  return `<div class="mat-facts">${ss.map(s =>
    `<a class="src" href="${s.url || '#'}" target="_blank" rel="noopener">${esc(s.label || s)} <span class="t">tier-${s.tier || 3}</span></a>`).join('')}</div>`;
}
function wbInferHTML(m) {
  const inf = m.inference;
  if (!inf || (!inf.text && !inf.why)) return '';
  return `<div class="mat-risk">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l10 18H2z" stroke-linejoin="round"/><path d="M12 10v4M12 17h.01" stroke-linecap="round"/></svg>
    <div>${esc(inf.text || '')}<span class="rwhy">为什么这么推：${esc(inf.why || '')} —— 推算项，请自行判断</span></div>
  </div>`;
}
function wbMissingHTML(m) {
  const miss = m.missingFields || [];
  if (!miss.length) return '';
  return `<div class="mat-facts"><span class="ev ev-unk">未探测：${miss.map(x => x === 'history:60d' ? '历史价 60 天' : x === 'priceRange' ? '价格未探测' : x).join(' / ')}（≠ 确认没有）</span></div>`;
}
function wbBrandName(m) {
  if (m.brand && m.brand.name) return m.brand.name;
  const sid = String(m.subjectId || '');
  if (sid.startsWith('brand:')) return sid.slice(6); // 后端 Material@1：subjectId='brand:makielab'
  return m.brandUrl || sid || '未知品牌';
}
function wbBrandUrl(m) { return (m.brand && m.brand.url) || (m.brandUrl || ''); }
function wbWhen(m) {
  const t = m.capturedAt || m.at;
  if (!t) return '';
  try {
    const mins = Math.max(1, Math.round((Date.now() - new Date(t).getTime()) / 60000));
    if (mins < 60) return mins + ' 分钟前';
    const h = Math.round(mins / 60); if (h < 24) return h + ' 小时前';
    return Math.round(h / 24) + ' 天前';
  } catch { return ''; }
}
function wbMaterialHTML(mat) {
  const d = wbDecision(mat.id);
  const ev = wbEvidence(mat);
  const done = !!d;
  return `<div class="mat ${wbSignalOf(mat)}${done ? ' done' : ''}" data-id="${escAttr(mat.id)}">
    <div class="mat-body" data-wbdrawer="${escAttr(mat.id)}">
      <div class="mat-top">
        <span class="mtype mt-${wbSignalOf(mat)}">${esc(wbTypeLabel(mat))}</span>
        <span class="mat-brand">${esc(wbBrandName(mat))}${wbBrandUrl(mat) ? `<span class="burl">${esc(wbBrandUrl(mat))}</span>` : ''}</span>
        <span class="ev ${ev.cls}">${ev.txt}</span>
        <span class="mat-when">${wbWhen(mat)}</span>
      </div>
      <div class="mat-title">${esc(mat.summary || mat.title || mat.body || '')}</div>
      ${wbPriceHTML(mat)}
      ${wbSourcesHTML(mat)}
      ${wbInferHTML(mat)}
      ${wbMissingHTML(mat)}
    </div>
    <div class="mat-acts">
      <button class="btn-act act-keep" data-wbset="${escAttr(mat.id)}" data-act="keep">✓ 收了</button>
      <button class="btn-act act-later" data-wbset="${escAttr(mat.id)}" data-act="later">先放着</button>
      <button class="btn-act act-drop" data-wbset="${escAttr(mat.id)}" data-act="ignore">忽略</button>
    </div>
    <div class="mat-donebar">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4 10-10" stroke-linecap="round"/></svg>
      <span class="db-text">${WB_ACTIONS[d] || ''}</span>
      <span class="undo" data-wbset="${escAttr(mat.id)}" data-act="">撤销</span>
    </div>
  </div>`;
}
function wbMatById(id) {
  const ms = (state && state.materials) || [];
  return ms.find(x => x.id === id) || null;
}
function renderWorkbench() {
  const wrap = $('#workbenchWrap');
  renderProgress(); // 已就绪进度条（report 顶部挪入工作台：调研就绪度可视化）
  if (!wrap) return;
  const msAll = (state && state.materials) || [];
  if (!msAll.length) {
    wrap.innerHTML = '<div class="empty"><div class="big">暂无材料</div><div class="sub">完成一次调研后，Agent 会在这里推送跟价 / 上新 / 新渠道 / 口碑材料。</div></div>';
    return;
  }
  // 应用筛选（U5：状态 × 类型）
  const ms = msAll.filter(wbPass);
  if (!ms.length) {
    wrap.innerHTML = '<div class="empty"><div class="big">没有符合条件的材料</div><div class="sub">试试切换筛选，或先处理几份材料。</div></div>';
    return;
  }
  // 按捕获时间倒序 + 按天分组（今天 / 昨天 / 更早）
  const sorted = ms.slice().sort((a, b) => new Date(b.capturedAt || b.at || 0) - new Date(a.capturedAt || a.at || 0));
  const groups = { 'TODAY · 今天': [], 'YESTERDAY · 昨天': [], 'EARLIER · 更早': [] };
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0);
  for (const m of sorted) {
    const t = new Date(m.capturedAt || m.at || 0).getTime();
    if (!t) { groups['EARLIER · 更早'].push(m); continue; }
    if (t >= dayStart.getTime()) groups['TODAY · 今天'].push(m);
    else if (t >= dayStart.getTime() - 86400000) groups['YESTERDAY · 昨天'].push(m);
    else groups['EARLIER · 更早'].push(m);
  }
  const d = wbLoad();
  const counts = { keep: 0, ignore: 0, later: 0 };
  ms.forEach(m => { if (d[m.id]) counts[d[m.id]]++; });
  wrap.innerHTML = Object.entries(groups)
    .filter(([, list]) => list.length)
    .map(([label, list]) => `<div class="day-group"><div class="day-label">${label}</div>${list.map(wbMaterialHTML).join('')}</div>`)
    .join('') + `<p class="hint wb-summary">共 ${ms.length} 条 · 已收 ${counts.keep} · 稍后 ${counts.later} · 忽略 ${counts.ignore}</p>`;
}
// 左侧导航待批 badge（U3）
function updateWbBadges() {
  const el = $('#navPending');
  if (!el) return;
  const d = wbLoad();
  const pending = (state && state.materials || []).filter(m => !d[m.id]).length;
  el.textContent = pending;
  el.classList.toggle('gray', pending === 0);
  const rv = $('#navRivals');
  if (rv && state) rv.textContent = (state.competitors || []).length;
}
// ---- U4：材料详情抽屉（五段式） ----
function openWbDrawer(id) {
  const m = wbMatById(id);
  if (!m) return;
  const ev = wbEvidence(m);
  const priceSec = m.price && (m.price.old != null || m.price.new != null) ? `
    <div class="sec"><div class="sec-h"><span class="n">1</span>发生了什么</div>
      <div class="sec-b">
        <div style="font-size:13px;color:var(--ink2);line-height:1.7">${esc(m.summary || m.title || m.body || '')}</div>
        ${m.price && (m.price.old != null || m.price.new != null) ? `<div class="price-cmp" style="margin-top:14px">
          ${m.price.old != null ? `<div class="pc-old"><div class="k">调整前</div><div class="v num">${wbMoney(m.price.old, m.price.currency)}</div></div>` : ''}
          <div class="pc-arrow">→</div>
          <div class="pc-new"><div class="k">调整后</div><div class="v num">${wbMoney(m.price.new, m.price.currency)} ${m.price.deltaPct != null ? `<span style="font-size:12px">${m.price.deltaPct > 0 ? '▲' : '▼'}${Math.abs(m.price.deltaPct)}%</span>` : ''}</div></div>
        </div>` : ''}
      </div></div>` : `
    <div class="sec"><div class="sec-h"><span class="n">1</span>发生了什么</div>
      <div class="sec-b"><div style="font-size:13px;color:var(--ink2);line-height:1.7">${esc(m.summary || m.title || m.body || '')}</div></div></div>`;
  const histSec = `<div class="sec"><div class="sec-h"><span class="n">2</span>历史价格 · 近 12 周</div>
    <div class="sec-b"><p class="hint">历史价格序列待接入（data/events.json 或 gap_snapshots）。当前无 12 周连续数据，不编造曲线。</p></div></div>`;
  // P0-2 修复：五段式骨架固定渲染（发生了什么→历史价→市场区间→推算影响面→证据来源），
  // 无数据时显示统一空态占位（不再条件截断导致编号跳号 1,2,5）。
  const rangeSec = m.price && m.price.range ? `
    <div class="sec"><div class="sec-h"><span class="n">3</span>市场区间 · 同赛道在售价</div>
      <div class="sec-b"><p class="hint">市场区间 ${wbMoney(m.price.range.min, m.price.currency)} – ${wbMoney(m.price.range.max, m.price.currency)}（来源见下）</p></div></div>` : `
    <div class="sec"><div class="sec-h"><span class="n">3</span>市场区间 · 同赛道在售价</div>
      <div class="sec-b"><p class="hint">市场区间待 2 家以上实抓价（当前样本不足，不编造）。</p></div></div>`;
  const inferSec = m.inference && (m.inference.text || m.inference.why) ? `
    <div class="sec"><div class="sec-h"><span class="n">4</span>推算影响面 <span class="ev ev-warn" style="margin-left:auto">推算 · 非实抓</span></div>
      <div class="sec-b"><div class="infer-note">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l10 18H2z" stroke-linejoin="round"/></svg>
        <div>${esc(m.inference.text || '')}<span class="why">为什么这么推：${esc(m.inference.why || '')} —— 推理项，供你判断，非行动建议。</span></div>
      </div></div></div>` : `
    <div class="sec"><div class="sec-h"><span class="n">4</span>推算影响面</div>
      <div class="sec-b"><p class="hint">影响面推算待接入（需对手价格带 + 你的定位锚点），当前不臆测。</p></div></div>`;
  const srcSec = `<div class="sec"><div class="sec-h"><span class="n">5</span>证据来源 · 逐条可验</div>
    <div class="sec-b"><div class="src-list">
      ${(m.sources || []).map(s => `<div class="src-row"><span class="ev ${s.tier === 1 ? 'ev-ok' : 'ev-warn'}">${s.tier === 1 ? '实抓' : '媒体'}</span><div class="txt">${esc(s.label || s)}<br/><span class="u">${esc(s.url || '')}</span></div><span class="tier">tier-${s.tier || 3}</span></div>`).join('') || '<p class="hint">暂无来源记录。</p>'}
    </div></div></div>`;
  const miss = (m.missingFields || []).length ? `<div class="sec"><div class="sec-h"><span class="n">·</span>未探测</div><div class="sec-b"><p class="hint">未探测：${m.missingFields.join(' / ')}（≠ 确认没有）</p></div></div>` : '';
  $('#drTitle').innerHTML = `<span class="mtype mt-${wbSignalOf(m)}">${esc(wbTypeLabel(m))}</span> ${esc(wbBrandName(m))} <span class="ev ${ev.cls}">${ev.txt}</span>`;
  $('#drSub').textContent = '材料 #' + m.id + (m.capturedAt ? ' · 捕获于 ' + new Date(m.capturedAt).toLocaleString('zh-CN') : '') + ' · 来源 ' + (m.sources || []).length + ' 条';
  $('#drawerBody').innerHTML = priceSec + histSec + rangeSec + inferSec + srcSec + miss;
  $('#drawer').classList.add('on');
  $('#drawerMask').classList.add('on');
  $('#drawer').setAttribute('aria-hidden', 'false');
  // 抽屉底部三动作
  $$('#drawer .dr-foot .btn-act').forEach(b => {
    b.onclick = () => { wbSet(m.id, b.dataset.act); closeWbDrawer(); };
  });
  const cur = wbDecision(m.id);
  if (cur) $$('#drawer .dr-foot .btn-act').forEach(b => b.classList.toggle('active', b.dataset.act === cur));
}
function closeWbDrawer() {
  $('#drawer').classList.remove('on');
  $('#drawerMask').classList.remove('on');
  $('#drawer').setAttribute('aria-hidden', 'true');
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeWbDrawer(); });

function renderAll() {
  renderProgress();
  renderRadarTab();
  renderIntelTab();
  renderGate();
  updateWbBadges(); // U3：导航 badge（待批材料 / 对手数）
  markStateSig(); // ▶ P1-1：用户主动渲染后刷新签名，poll 不会误判「未变」而跳过
  // U3：工作台为默认首页，始终渲染
  if ($('#tab-workbench') && $('#tab-workbench').classList.contains('active')) { renderRadarStatus(); renderWorkbench(); }
  if ($('#tab-category') && $('#tab-category').classList.contains('active')) { renderCategoryScanTab(); renderQuadrantTab(); }
  if ($('#tab-assets') && $('#tab-assets').classList.contains('active')) { renderAssetsTab(); }
  if ($('#tab-opportunity') && $('#tab-opportunity').classList.contains('active')) { renderOpportunityTab(); }
  if ($('#tab-sector') && $('#tab-sector').classList.contains('active')) { renderSectorTab(); }
}

// U5：机会视图页（设计稿 §8：opp-intro + opp-card 清单）
function renderOpportunityTab() {
  const wrap = $('#oppWrap');
  if (!wrap) return;
  if (!state || !state.opportunity) {
    wrap.innerHTML = '<div class="empty"><div class="big">暂无机会数据</div><div class="sub">完成调研后，这里会列出带分母与来源的机会清单。</div></div>';
    return;
  }
  const op = state.opportunity;
  const themes = (op.themes || op.preliminaryThemes || []).slice().sort((a, b) => (b.opportunity || 0) - (a.opportunity || 0)).slice(0, 8);
  let html = `<div class="opp-intro">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 3"/></svg>
    <div><b>样本口径</b>：${op.doneBrands || 0} 家对手 · ${op.brandsWithVoice || 0} 家有用户声音（≥3 家才出图）· 提及广度按「N/M 家提到」显式呈现。口碑类机会一律标注为推测，不冒充可行动建议。</div>
  </div>`;
  if (!themes.length) {
    html += '<div class="empty"><div class="big">样本不足</div><div class="sub">需要至少 3 家对手采到评论主题或抱怨点，当前 ' + (op.brandsWithVoice || 0) + ' 家有声音。</div></div>';
  } else {
    // 设计稿 §8：quad-wrap = 竞争象限图（左）+ 机会清单（右）
    html += `<div class="quad-wrap">
      <div class="quad-card">
        <h4>竞争象限 · 强度 × 机会</h4>
        <div class="qsub">按「竞争强度」与「机会大小」两个轴排布，仅作观察参考</div>
        ${oppQuadSvg(themes)}
        <div class="quad-legend">
          <div class="ql-item"><i style="background:#33B98C"></i><div><b>优先区</b>——机会大、竞争弱：值得你优先看，但仍由你判断</div></div>
          <div class="ql-item"><i style="background:#D96862"></i><div><b>硬碰区</b>——机会大、竞争也大：已有强手盘踞</div></div>
          <div class="ql-item"><i style="background:#85959D"></i><div><b>回避区 / 观望区</b>——机会小：看看即可</div></div>
        </div>
      </div>
      <div>
        <h4 style="font-size:13px;font-weight:800;margin-bottom:12px">机会清单 <span style="color:var(--ink4);font-weight:500;font-size:11.5px">按机会分排序 · 置信封顶「中」</span></h4>
        <div class="opp-list">` + themes.map(t => {
      const conf = (t.zone === 'underserved') ? '<span class="ev ev-warn">推算 · 置信中（封顶）</span>'
        : (t.zone === 'served') ? '<span class="ev ev-unk">推测 · 置信低</span>'
        : '<span class="ev ev-warn">推算 · 置信中</span>';
      return `<div class="opp-card">
        <div class="opp-top"><span class="mtype mt-new"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l10 18H2z"/></svg>${t.zone === 'served' ? '痛点' : '机会'}</span><span class="opp-t">${esc(t.label || t.title || '')}</span></div>
        <p class="opp-d">${esc(t.note || t.desc || '')}</p>
        <div class="opp-foot"><span class="opp-metric">提及广度 <b class="num">${esc(t.denominatorText || t.breadth || '—')}</b></span>${conf}<span class="src">${esc(t.method || '机会引擎')} <span class="t">${esc(t.oid || '')}</span></span></div>
        <div class="opp-disc"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l10 18H2z"/></svg>此结论基于不足证据，仅供参考，不构成行动建议。</div>
      </div>`;
    }).join('') + `</div>
      </div>
    </div>`;
  }
  wrap.innerHTML = html;
}
// 机会象限图（设计稿 §8：强度×机会，散点按机会 theme 归置）
function oppQuadSvg(themes) {
  let pts = '';
  themes.slice(0, 8).forEach((t, i) => {
    const zone = t.zone || '';
    let cx, cy, col;
    if (zone === 'underserved') { cx = 70 + (i % 2) * 90; cy = 192 + Math.floor(i / 2) * 32; col = '#33B98C'; }        // 优先区（机会大·竞争弱）
    else if (zone === 'served') { cx = 235 + (i % 2) * 90; cy = 192 + Math.floor(i / 2) * 32; col = '#D96862'; }      // 硬碰区（机会大·竞争强）
    else { cx = 110 + ((i * 53) % 150); cy = 80 + ((i * 37) % 105); col = (i % 2) ? '#6FA8DC' : '#85959D'; }          // 观望/回避区
    const label = (t.label || t.title || '机会').slice(0, 18);
    pts += `<circle cx="${cx}" cy="${cy}" r="6" fill="${col}" opacity=".9"><title>${esc(label)}</title></circle>`;
  });
  return `<svg viewBox="0 0 400 300" width="100%" style="background:var(--bg1);border:1px solid var(--line1);border-radius:10px">
    <line x1="20" y1="150" x2="380" y2="150" stroke="#212B25"/><line x1="200" y1="20" x2="200" y2="280" stroke="#212B25"/>
    <text x="24" y="18" fill="#71847A" font-size="10">机会 ↑</text>
    <text x="206" y="18" fill="#71847A" font-size="10">强度 →</text>
    <rect x="20" y="150" width="180" height="130" fill="rgba(217,162,92,.045)"/><text x="36" y="166" fill="#D9A25C" font-size="10" font-weight="700">优先区 · 机会大竞争弱</text>
    <rect x="200" y="150" width="180" height="130" fill="rgba(217,104,98,.045)"/><text x="216" y="166" fill="#D96862" font-size="10" font-weight="700">硬碰区 · 机会大竞争强</text>
    <rect x="20" y="20" width="180" height="130" fill="rgba(111,168,220,.04)"/><text x="36" y="36" fill="#6FA8DC" font-size="10" font-weight="700">观望区 · 机会小竞争弱</text>
    <rect x="200" y="20" width="180" height="130" fill="rgba(90,100,95,.05)"/><text x="216" y="36" fill="#85959D" font-size="10" font-weight="700">回避区 · 机会小竞争强</text>
    ${pts}
  </svg>`;
}

// U5：赛道档案页（设计稿 §6：四宫格）
function renderSectorTab() {
  const wrap = $('#categoryWrap');
  if (!wrap) return;
  if (!state) { wrap.innerHTML = '<div class="empty"><div class="big">暂无赛道数据</div></div>'; return; }
  const cs = (state.competitors || []).filter(c => c.status === 'done');
  if (!cs.length) { wrap.innerHTML = '<div class="empty"><div class="big">暂无赛道数据</div><div class="sub">完成调研后，这里会展示品类分布 / 价格阶梯 / 渠道覆盖 / 头部格局。</div></div>'; return; }
  // 品类分布（粗粒度：按 category 聚合）
  const catCount = {};
  cs.forEach(c => { (c.categories && c.categories.length ? c.categories : [c.category || '未分类']).forEach(x => { catCount[x] = (catCount[x] || 0) + 1; }); });
  const catTop = Object.entries(catCount).sort((a, b) => b[1] - a[1]).slice(0, 3);
  // 渠道覆盖（按展示名 label 去重聚合，避免 ch_0_* 等 demo key 泄漏到 UI）
  const chanCount = {};
  cs.forEach(c => {
    const seen = new Set();
    Object.keys(c.channels || {}).forEach(k => {
      const v = c.channels[k];
      if (v && v.present) {
        const nm = v.label || k;
        if (!seen.has(nm)) { seen.add(nm); chanCount[nm] = (chanCount[nm] || 0) + 1; }
      }
    });
  });
  const chanTop = Object.entries(chanCount).sort((a, b) => b[1] - a[1]).slice(0, 3);
  // 价格阶梯
  const priceBands = {};
  cs.forEach(c => {
    const b = (c.priceField && c.priceField.priceBand) || (c.priceBand && c.priceBand.band);
    if (b) priceBands[lbl('priceBands', b)] = (priceBands[lbl('priceBands', b)] || 0) + 1;
  });
  const bandTop = Object.entries(priceBands).sort((a, b) => b[1] - a[1]).slice(0, 3);
  // 头部格局
  const ranked = cs.slice().sort((a, b) => (b.rankScore || 0) - (a.rankScore || 0)).slice(0, 3);
  const evCls = (n) => n >= Math.ceil(cs.length * 0.6) ? 'ev-ok' : (n >= 2 ? 'ev-warn' : 'ev-unk');
  const evLabel = (n) => n >= Math.ceil(cs.length * 0.6) ? '饱和' : (n >= 2 ? '分散' : '空白');
  const quad = (title, body) => `<div class="sec"><div class="sec-h"><span class="n">${'①②③④'[['品类分布','价格阶梯','渠道覆盖','头部格局'].indexOf(title)] || '·'}</span>${title}</div><div class="sec-b">${body}</div></div>`;
  const catHtml = catTop.length ? catTop.map(([k, n]) =>
    `<div class="fb-item" style="margin-bottom:7px"><span class="ev ${evCls(n)}">${evLabel(n)}</span><span class="nm">${esc(k)}</span><span class="val num">${n}/${cs.length} 家</span></div>`).join('') : '<p class="hint">暂无品类数据。</p>';
  const bandHtml = bandTop.length ? bandTop.map(([k, n]) =>
    `<div class="band-row"><span class="band-name">${esc(k)}</span><div class="band-bar"><div class="band-fill" style="left:0;width:${Math.min(100, n * 20)}%"></div></div><span class="band-price num">${n} 家</span></div>`).join('') : '<p class="hint">暂无价格带数据。</p>';
  const chanHtml = chanTop.length ? chanTop.map(([k, n]) =>
    `<div class="fb-item" style="margin-bottom:7px"><span class="ev ${evCls(n)}">${evLabel(n)}</span><span class="nm">${esc(k)}</span><span class="val num">${n}/${cs.length} 家</span></div>`).join('') : '<p class="hint">暂无渠道数据。</p>';
  const headHtml = ranked.map((c, i) =>
    `<div class="fb-item" style="margin-bottom:7px"><span class="ev ${i === 0 ? 'ev-ok' : i === 1 ? 'ev-warn' : 'ev-unk'}">${i === 0 ? '头部' : i === 1 ? '新兴' : '快时尚'}</span><span class="nm">${esc(c.name)}${c.heroProduct && c.heroProduct.heroProducts && c.heroProduct.heroProducts[0] ? ' · ' + esc(c.heroProduct.heroProducts[0].name) : ''}</span><span class="val">${esc(fmtPrice(c))} 起</span></div>`).join('');
  wrap.innerHTML = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    ${quad('品类分布 · 谁在做什么', catHtml)}
    ${quad('价格阶梯 · 市场带', bandHtml)}
    ${quad('渠道覆盖矩阵', chanHtml)}
    ${quad('头部格局 · 关系定位', headHtml)}
  </div>`;
}

function renderProgress() {
  const cs = state.competitors || [];
  const done = cs.filter(c => c.status === 'done').length;
  const researching = cs.filter(c => c.status === 'researching').length;
  const total = cs.length;
  const bar = $('#progressBar');
  const txt = $('#progressText');
  const wrap = bar && bar.parentNode ? bar.parentNode.parentNode : null;
  if (!total) { if (wrap) wrap.classList.add('hidden'); return; }
  if (wrap) wrap.classList.remove('hidden');
  const pct = Math.round((done / total) * 100);
  bar.style.width = pct + '%';
  if (researching > 0) txt.textContent = `调研中 ${done}/${total} · AI 正在逐家深研…`;
  else if (done < total) txt.textContent = `已就绪 ${done}/${total}`;
  else txt.textContent = `全部就绪 ${done}/${total}`;
}

function renderCompetitors() {
  const wrap = $('#competitorList');
  const excluded = new Set(state.excluded || []);
  const cs = (state.competitors || []).filter(c => !excluded.has(c.id)).slice().sort((a, b) => (b.rankScore || 0) - (a.rankScore || 0));
  wrap.innerHTML = '';
  // P1 KPI 条
  wrap.insertAdjacentHTML('beforeend', renderKpiStrip(cs, state.whiteSpace));
  // P1 品牌卡片网格（复用 competitorCard 原子卡）
  const grid = document.createElement('div');
  grid.className = 'pano-cards';
  cs.forEach((c, i) => grid.appendChild(competitorCard(c, i + 1)));
  wrap.appendChild(grid);
  // P2 横向对比表
  wrap.insertAdjacentHTML('beforeend', renderPanoramaTable(cs));
  // P3 定位象限
  wrap.insertAdjacentHTML('beforeend', quadSectionHTML(cs, state.whiteSpace));
  // 表格行 → 展开对应品牌卡
  wrap.querySelectorAll('.pano-tr').forEach(tr => {
    tr.onclick = () => { const id = tr.dataset.rowcid; if (id) toggleCard(id); };
  });
}

// ===================== S2：三页骨架（雷达 / 情报库 / 品类扫描） =====================

function fmtPrice(c) {
  const hp = c.heroProduct && c.heroProduct.corePriceBand;
  if (hp && (hp.min != null || hp.max != null)) {
    const cur = hp.currency || c.currency || '';
    const lo = hp.min != null ? hp.min : '?';
    const hi = hp.max != null ? hp.max : '?';
    return `${cur}${lo}–${hi}`;
  }
  if (c.priceBand && c.priceBand.range) return c.priceBand.range;
  if (c.priceField && c.priceField.display) return c.priceField.display;
  return '价位未明';
}
function fmtRating(c) {
  const r = (c.reviews && c.reviews.rating) || c.ratingField || null;
  if (!r) return '评分未明';
  const v = r.value != null ? r.value : r.rating;
  const n = r.count != null ? r.count : (r.reviews != null ? r.reviews : null);
  if (v == null) return '评分未明';
  return n != null ? `${v}（${n} 评）` : `${v}`;
}
function fmtChannels(c) {
  const ch = c.channels || {};
  const present = Object.keys(ch).filter(k => ch[k] && ch[k].present);
  if (!present.length) return '渠道未明';
  return present.slice(0, 4).map(k => lbl('channels', k)).join('、');
}
function fmtHero(c) {
  const hp = c.heroProduct;
  if (!hp || !hp.heroProducts || !hp.heroProducts.length) return '未识别主推';
  return hp.heroProducts[0].name;
}

// 雷达页：战略信号条（群体异动）+ 卡片墙（有动作置顶）
function renderRadarTab() {
  if (!state) return;
  const strip = $('#radarStrip');
  const wall = $('#radarWall');
  if (!wall) return;
  // 设计稿：signal-strip 信号条（按类型聚合）
  if (strip) {
    const gs = (state.radar && state.radar.groupSignals) || [];
    if (gs.length) {
      strip.innerHTML = gs.slice(0, 5).map(s => {
        const comp = (s.competitors && s.competitors.length) ? ` ｜ ${esc(s.competitors.join('、'))}` : '';
        const cls = chgClass(s.label || '') === 'up' ? 'sig-new' : chgClass(s.label || '') === 'down' ? 'sig-down' : 'sig-new';
        return `<div class="sig ${cls}"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 5v14M5 12h14"/></svg></div><div><b>${esc(s.label || '动作')}</b><span class="t">${esc(s.note || '')}${comp}</span></div></div>`;
      }).join('');
    } else {
      strip.innerHTML = `<div class="sig"><div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/></svg></div><div><b>近阶段暂无跨对手集体异动</b><span class="t">持续观测中</span></div></div>`;
    }
  }
  const excluded = new Set(state.excluded || []);
  const cs = (state.competitors || []).filter(c => !excluded.has(c.id) && c.status === 'done');
  cs.sort((a, b) => {
    const ra = a.recentActions || {}, rb = b.recentActions || {};
    const ka = ra.hasAction ? 1 : 0, kb = rb.hasAction ? 1 : 0;
    if (ka !== kb) return kb - ka;
    return (b.rankScore || 0) - (a.rankScore || 0);
  });
  // P2-2 修复：对手 <3 家（且非 0）时，加页面级「补录对手」引导（样本薄 → 信号与空白视图不可靠，引导用户补样本）
  const lead = cs.length > 0 && cs.length < 3;
  let banner = document.getElementById('radarLeadBanner');
  if (lead) {
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'radarLeadBanner';
      banner.className = 'radar-lead-banner';
      const layout = wall.parentNode; // .radar-layout
      layout.parentNode.insertBefore(banner, layout);
    }
    banner.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14" stroke-linecap="round"/></svg>
      <div class="rlb-main"><b>当前仅 ${cs.length} 家对手，样本偏薄</b><span>信号聚合与空白视图需要 ≥3 家对手数据才可靠。补录几个你真在盯的品牌，雷达与机会视图会自动重算。</span></div>
      <button class="btn-ghost" data-radaraddfocus="1">＋ 补录对手</button>`;
  } else if (banner) {
    banner.remove();
  }
  wall.innerHTML = '';
  if (!cs.length) { wall.innerHTML = '<div class="empty"><div class="big">暂无可展示的对手</div><div class="sub">完成一次调研后，这里会列出竞品卡墙。</div></div>'; return; }
  const grid = document.createElement('div');
  grid.className = 'rival-grid';
  cs.forEach((c, i) => grid.appendChild(radarCard(c, i + 1)));
  wall.appendChild(grid);
}

function chgClass(label) {
  const l = label || '';
  if (/降价|价格|跌|降|促销|折扣|调价/.test(l)) return 'down';
  if (/上新|新渠道|开通|开店|上架|新品|独立站|迁移|拓展|进|开/.test(l)) return 'up';
  if (/差评|暴涨|危机|负面/.test(l)) return 'crisis';
  return 'info';
}

function rivalRel(c) {
  // 与用户关系：直接对手 / 高价参考 / 低价走量
  const pf = c.priceField;
  const userBand = (state.intent && state.intent.profile && state.intent.profile.priceBand) || null;
  const rc = (c.relationship && c.relationship.code) || 'undetermined';
  // 优先级：自身关系标注 > 价格带比较
  if (rc === 'direct') return { cls: 'rrel-direct', zh: '直接对手' };
  if (rc === 'indirect') return { cls: 'rrel-ref', zh: '高价参考' };
  if (rc === 'unrelated') return { cls: 'rrel-cheap', zh: '低价走量' };
  if (!pf || !pf.display || !userBand || userBand.min == null) return { cls: 'rrel-direct', zh: '直接对手' };
  // 简化判定：有价格区间做带位比较
  return { cls: 'rrel-direct', zh: '直接对手' };
}

function radarCard(c, no) {
  const ra = c.recentActions || {};
  const hp = c.heroProduct || {};
  const el = document.createElement('article');
  el.className = 'rival';
  el.dataset.cid = c.id;
  const rel = rivalRel(c);
  const heroTxt = fmtHero(c);
  const osLine = [c.category, fmtChannels(c)].filter(Boolean).join(' · ') || '—';
  const priceTxt = fmtPrice(c);
  // 渠道 chips（去重：按渠道展示名）
  const ch = c.channels || {};
  const seen = new Set();
  const present = [];
  Object.keys(ch).forEach(k => {
    const v = ch[k];
    if (v && v.present) {
      const lbl = v.label || lbl('channels', k) || k;
      if (!seen.has(lbl)) { seen.add(lbl); present.push(lbl); }
    }
  });
  const chips = present.slice(0, 4).map(label => `<span class="rch ok">${esc(label)}</span>`).join('');
  const warnChips = present.length > 4 ? `<span class="rch warn">+${present.length - 4} 个</span>` : '';
  let actHtml = '';
  if (ra.hasAction && ra.action) {
    const lbl = ra.action.label || '动作';
    const cls = chgClass(lbl) === 'up' ? 'mt mt-new' : chgClass(lbl) === 'down' ? 'mt mt-down' : chgClass(lbl) === 'crisis' ? 'mt mt-crisis' : 'mt mt-new';
    const when = ra.action.when ? ' · ' + String(ra.action.when) : '';
    actHtml = `<div class="r-act"><span class="${cls}">${esc(lbl)}</span><b>${esc(ra.action.desc || '')}</b>${esc(when)}</div>`;
  } else {
    actHtml = `<div class="r-act">近阶段无显著动作</div>`;
  }
  el.innerHTML = `
    <div class="r-top">
      <div class="r-avatar">${esc((c.name || '?')[0])}</div>
      <div><div class="r-nm">${esc(c.name)}</div><div class="r-tag">${esc(osLine)}</div></div>
      <span class="r-rel ${rel.cls}">${rel.zh}</span>
    </div>
    <div class="r-price"><span class="num">${priceTxt}</span><span class="unit">起</span><span class="band">${hp && hp.heroProducts && hp.heroProducts[0] ? '主推 ' + esc(hp.heroProducts[0].name) : ''}</span></div>
    <div class="r-chips">${chips}${warnChips}</div>
    ${actHtml}
  `;
  el.onclick = () => switchTab('intel', c.id);
  return el;
}

// 设计稿：工作台顶部雷达状态条（4 格指标）
function renderRadarStatus() {
  const wrap = $('#radarStatusWrap');
  if (!wrap) return;
  const ms = (state && state.materials) || [];
  const d = wbLoad();
  const pending = ms.filter(m => !d[m.id]).length;
  const kept = ms.filter(m => d[m.id] === 'keep').length;
  const comps = (state && state.competitors) || [];
  wrap.innerHTML = `
    <div class="radar-scan">
      <svg viewBox="0 0 120 120" fill="none">
        <circle cx="60" cy="60" r="52" stroke="#212B25" stroke-width="1.5"/>
        <circle cx="60" cy="60" r="38" stroke="#212B25" stroke-width="1"/>
        <circle cx="60" cy="60" r="24" stroke="#212B25" stroke-width="1"/>
        <line x1="60" y1="2" x2="60" y2="16" stroke="#212B25"/><line x1="60" y1="104" x2="60" y2="118" stroke="#212B25"/>
        <line x1="2" y1="60" x2="16" y2="60" stroke="#212B25"/><line x1="104" y1="60" x2="118" y2="60" stroke="#212B25"/>
        <circle cx="88" cy="34" r="3" fill="#33B98C"/><circle cx="38" cy="82" r="2.5" fill="#D9A25C"/><circle cx="80" cy="80" r="2" fill="#6FA8DC"/><circle cx="30" cy="40" r="2.6" fill="#D96862"/>
      </svg>
      <div class="sweep"></div>
      <div class="core"></div>
      <div class="scan-txt">SCANNING · ${comps.length} 个对手在观测中</div>
    </div>
    <div class="rs-main">
      <div class="rs-cell"><div class="rs-k"><span class="pulse"></span>监测状态</div><div class="rs-v" style="font-size:16px;font-weight:700;margin-top:9px">正在运行</div><div class="rs-sub">持续扫描对手变化</div></div>
      <div class="rs-cell"><div class="rs-k">今日捕获信号</div><div class="rs-v down num">${ms.length}<small>条</small></div><div class="rs-sub">来自 ${comps.length} 家对手</div></div>
      <div class="rs-cell"><div class="rs-k"><span class="pulse warn"></span>待你处理</div><div class="rs-v warn num">${pending}<small>条</small></div><div class="rs-sub">收 / 忽略 / 先放着</div></div>
      <div class="rs-cell"><div class="rs-k">本周已收材料</div><div class="rs-v info num">${kept}<small>份</small></div><div class="rs-sub">收得越勤，材料越准</div></div>
    </div>`;
}

// ---------- 情报库：档案页形态（设计稿 §3.2 P4 / §4.5）----------
// 档案头（profile-head）+ 六字段折叠（field-box）+ 私有备注（note-box）
let currentIntelId = null; // 当前选中对手档案
const INTEL_ICO = {
  price: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>',
  channel: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 21V8l8-4 8 4v13M9 21v-6h6v6"/></svg>',
  category: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16v16H4zM4 9h16M9 4v16"/></svg>',
  launch: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/></svg>',
  review: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 20V9l8-5 8 5v11M9 20v-6h6v6" stroke-linejoin="round"/></svg>',
  blank: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 8v4M12 16h.01" stroke-linecap="round"/></svg>',
};
// 六字段折叠（与设计稿口径一致：价格 / 渠道 / 品类 / 上新节奏 / 口碑 / 空白）
function intelFieldBox(key, icon, colorVar, title, sub, body, openDefault) {
  return `<div class="field-box${openDefault ? ' open' : ''}" data-fb="${key}">
    <div class="fb-head" data-fbtoggle="${key}">
      <div class="fb-ico" style="background:var(--${colorVar}-bg);color:var(--${colorVar})">${INTEL_ICO[icon]}</div>
      <div><div class="fb-t">${title}</div><div class="fb-s">${sub}</div></div>
      <span class="fb-arr">›</span>
    </div>
    <div class="fb-body">${body}</div>
  </div>`;
}
function intelEvTag(basis) {
  if (basis === 'verified') return '<span class="ev ev-ok">已核实</span>';
  if (basis === 'inferred') return '<span class="ev ev-warn">推算</span>';
  if (basis === 'conflict') return '<span class="ev ev-crisis">冲突</span>';
  return '<span class="ev ev-unk">未探测</span>';
}
// 空白字段收集：三态（未探测 / 查过没找到）→ fb-item 证据流（≠ 确认没有）
function intelBlankItems(c) {
  const items = [];
  Object.entries(L1_EMPTY_FIELDS).forEach(([cat, list]) => {
    list.forEach(f => {
      const a = attemptState(c, f.fieldKey);
      if (a.state === 'unprobed') {
        items.push(`<div class="fb-item"><span class="ev ev-unk">未探测</span><span class="nm">${esc(f.label)}</span><span class="val" style="font-weight:500;color:var(--ink3)">≠ 确认没有，待重研</span><button class="st-empty unprobed" data-l2field="${escAttr(f.fieldKey)}" data-cid="${escAttr(c.id)}" title="点此补查">补查</button></div>`);
      } else if (a.state === 'attempted_empty') {
        const d = a.latest ? new Date(a.latest).toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' }) : '';
        items.push(`<div class="fb-item"><span class="ev ev-unk">已查未得</span><span class="nm">${esc(f.label)}</span><span class="val" style="font-weight:500;color:var(--ink3)">${d ? d + ' 查过' : '查过'}，未找到来源</span><button class="st-empty attempted" data-l2field="${escAttr(f.fieldKey)}" data-cid="${escAttr(c.id)}">重研</button></div>`);
      }
    });
  });
  if (!items.length) return '<p class="hint">六维字段已全部覆盖，暂无「未探测」项。</p>';
  return '<div class="fb-flow">' + items.join('') + '</div>';
}
function renderIntelProfile(c) {
  const prof = (state.intent && state.intent.profile) || null;
  const cid = esc(c.id);
  const rel = c.relationship || { code: 'undetermined' };
  const relClsMap = { direct: 'rrel-direct', indirect: 'rrel-ref', unrelated: 'rrel-cheap', undetermined: 'rrel-cheap' };
  const relZh = rel.label || REL_LABEL[rel.code] || '关系待定';
  const tierTxt = TIER_LABEL[c.tier] || '体量未明';
  const osLine = [c.category, tierTxt].filter(Boolean).join(' · ') || '—';
  // 档案头指标（P1-3 修复：缺数据口径统一——「未探测」≠ 确认的 0/—/未明，忠实助理姿态）
  const pr = compPriceRange(c);
  const priceTxt = pr ? curSym(pr.currency) + pr.min + '–' + pr.max : ((c.priceField && c.priceField.display) || (c.priceBand && c.priceBand.range) || '未探测');
  const lcTxt = (c.launchCadence && c.launchCadence.value) || '未探测';
  const rtTxt0 = fmtRating(c);
  const rtTxt = (rtTxt0 === '评分未明' || rtTxt0 === '—') ? '未探测' : rtTxt0;
  const chN = Object.keys(c.channels || {}).filter(k => c.channels[k] && c.channels[k].present).length;
  const ovl = priceOverlapOrAdjacent(c, prof);
  const ovlTxt = ovl == null ? '未探测' : (ovl === true ? '高' : '中');
  const ovlColor = ovl == null ? 'style="color:var(--ink3)"' : (ovl === true ? 'style="color:var(--crisis)"' : 'style="color:var(--warn)"');
  // 六字段正文（复用现有值级核验渲染，嵌入设计稿 field-box）
  const priceBody = `
    <div class="fb-value">${priceTxt} ${c.priceField && c.priceField.basis ? intelEvTag(c.priceField.basis) : ((c.priceBand && c.priceBand.basis) ? intelEvTag(c.priceBand.basis) : '')}<span class="sub">· 原币种展示，不换算</span></div>
    ${L1_ITEMS.pricing(c).join('')}
    <button class="fb-correct" data-fbcorrect="${escAttr(c.id)}" data-fcfield="price">✎ 纠正价格数据（须附证据来源）</button>`;
  const chanBlocks = L1_ITEMS.channels(c).join('');
  const chanBody = chanBlocks ? `<div class="fb-flow" style="display:block">${chanBlocks}</div>` : '<p class="hint">渠道数据暂缺来源。</p>';
  const prodBlocks = L1_ITEMS.products(c).join('');
  const catBody = prodBlocks ? `<div class="fb-flow" style="display:block">${prodBlocks}</div>` : `<p class="hint">品类 / 产品矩阵暂缺来源。</p>`;
  const lcHtml = scalarFieldHTML(c, 'launchCadence', '上新节奏');
  const launchBody = lcHtml ? `<div class="fb-value">${lcHtml}</div>` : '<p class="hint">上新节奏暂未探测到，不编造。</p>';
  const revBlocks = L1_ITEMS.reviews(c).join('');
  const revBody = revBlocks ? `<div class="fb-flow" style="display:block">${revBlocks}</div>` : '<p class="hint">口碑数据暂缺来源。</p>';
  const blankBody = intelBlankItems(c);
  // 档案头
  const head = `
    <div class="profile-head">
      <div class="pf-avatar">${esc((c.name || '?')[0].toUpperCase())}</div>
      <div class="pf-main">
        <div class="pf-nm">${esc(c.name)} <span class="r-rel ${relClsMap[rel.code] || 'rrel-cheap'}">${escAttr(relZh)}</span> <span class="ev ev-ok">档案置信 ${c.rankScore ? '高' : '中'}</span></div>
        <div class="pf-tag">${esc(osLine)}${c.estSize ? ' · ' + esc(c.estSize) : ''}</div>
        ${c.url ? `<a class="pf-url" href="${escAttr(c.url)}" target="_blank" rel="noopener">${esc(c.url)} ↗</a>` : ''}
        <div class="pf-metrics">
          <div class="pf-m"><span class="k">主力价格带</span><span class="v num">${esc(priceTxt)}</span></div>
          <div class="pf-m"><span class="k">上新节奏</span><span class="v">${esc(lcTxt)}</span></div>
          <div class="pf-m"><span class="k">口碑</span><span class="v num">${esc(rtTxt)}</span></div>
          <div class="pf-m"><span class="k">覆盖渠道</span><span class="v${chN ? ' num' : ''}">${chN ? chN + ' <small>个</small>' : '未探测'}</span></div>
          <div class="pf-m"><span class="k">与你重叠</span><span class="v" ${ovlColor}>${esc(ovlTxt)}</span></div>
        </div>
      </div>
      <div class="pf-acts">
        <button class="btn-ghost" data-openmodal="reportModal">发现数据有误？</button>
      </div>
    </div>`;
  const boxes = intelFieldBox('fb-price', 'price', 'down', '价格', 'price · 实抓 + 推算混合', priceBody, true)
    + intelFieldBox('fb-chan', 'channel', 'new', '渠道', 'channels · 集合裁决', chanBody, false)
    + intelFieldBox('fb-cat', 'category', 'warn', '品类', 'categories · 集合裁决', catBody, false)
    + intelFieldBox('fb-launch', 'launch', 'new', '上新节奏', 'launch cadence · 标量裁决', launchBody, false)
    + intelFieldBox('fb-review', 'review', 'crisis', '口碑', 'reviews · 复合裁决', revBody, false)
    + intelFieldBox('fb-blank', 'blank', 'unk', '空白 · 未探测', 'not detected ≠ 确认没有', blankBody, false);
  const note = `<div class="note-box">
    <div class="lbl">私有备注（只在本机生效，不进公共库）</div>
    <textarea class="note-ta" id="note-${cid}" placeholder="例：这家「可动关节」卖点与我们方向重合，重点盯它的新品定价…"></textarea>
    <div class="note-hint">你补充的信息只在你自己的页面生效——这是忠实助理的底线，防对手投假数据。</div>
    <div class="notes-actions" style="margin-top:8px"><button class="btn-mini" data-intelnotesave="${cid}">保存备注</button><span class="notes-saved" id="notesaved-${cid}"></span></div>
  </div>`;
  return head + boxes + note;
}
// 情报库页：档案页形态（对手 chips 切换 + 六字段折叠）
function renderIntelTab() {
  const wrap = $('#intelList');
  if (!wrap || !state) return;
  const excluded = new Set(state.excluded || []);
  const cs = (state.competitors || []).filter(c => !excluded.has(c.id)).slice().sort((a, b) => (b.rankScore || 0) - (a.rankScore || 0));
  // 对手 chips（顶部切换）
  const chipsBox = $('#intelChips');
  if (chipsBox) {
    chipsBox.innerHTML = cs.map(c => `<button class="chip${c.id === currentIntelId ? ' on' : ''}" data-intelpick="${escAttr(c.id)}">${esc(c.name)}</button>`).join('');
  }
  if (!cs.length) { wrap.innerHTML = '<div class="empty"><div class="big">暂无可展示的对手档案</div><div class="sub">完成调研后，这里会展示每家对手的六维档案。</div></div>'; return; }
  if (!currentIntelId || !cs.some(x => x.id === currentIntelId)) currentIntelId = cs[0].id;
  const c = cs.find(x => x.id === currentIntelId);
  wrap.innerHTML = renderIntelProfile(c);
  ensureUserNote(c.id);
}

// 品类扫描页：接 /api/sector（聚合不撒谎 + 空白 + 趋势）
async function renderCategoryScanTab() {
  const wrap = $('#categoryWrap');
  if (!wrap || !state) return;
  wrap.innerHTML = '<p class="hint">正在聚合赛道数据…</p>';
  try {
    const r = await api('/api/sector', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sectorName: state.track || 'sector' }) });
    wrap.innerHTML = renderSectorView(r);
    renderOpportunity(); // ▶ P1a：接通此前死代码的机会地图（旗舰空白视图），注入 #opportunityContainer
  } catch (e) {
    wrap.innerHTML = `<p class="err">品类扫描加载失败：${esc(String((e && e.message) || e))}</p>`;
  }
}

function fmtPct(v) { if (v == null) return '—'; return Math.round(v * 100) + '%'; }

// F9：痛点机会表——聚合所有对手的抱怨点，标"未解决=机会"
function renderPainOpportunityTable(cs) {
  const map = {};
  cs.forEach(c => {
    const pains = [];
    (c.painPoints || []).forEach(p => pains.push({ text: p.point, basis: p.basis || 'inferred' }));
    if (c.reviewField && c.reviewField.negThemes && c.reviewField.negThemes.items) {
      c.reviewField.negThemes.items.forEach(i => { if (i.state !== 'conflict') pains.push({ text: i.text, basis: i.basis || 'inferred' }); });
    }
    (c.reviews && c.reviews.negThemes || []).forEach(t => pains.push({ text: t, basis: 'inferred' }));
    pains.forEach(p => {
      const key = (p.text || '').trim().toLowerCase();
      if (!key) return;
      if (!map[key]) map[key] = { text: p.text, brands: new Set(), basis: p.basis };
      map[key].brands.add(c.name);
      if (p.basis === 'verified') map[key].basis = 'verified';
    });
  });
  const rows = Object.values(map)
    .map(m => ({ text: m.text, n: m.brands.size, brands: [...m.brands], basis: m.basis }))
    .sort((a, b) => b.n - a.n).slice(0, 12);
  if (!rows.length) return '';
  let h = `<div class="cat-sec"><h4>痛点机会表 · 对手留的抱怨空位</h4><table class="cat-table pain-opp-table"><thead><tr><th>痛点</th><th>提及品牌</th><th>状态</th></tr></thead><tbody>`;
  rows.forEach(r => {
    h += `<tr><td>${esc(r.text)}</td><td>${r.n} 家（${esc(r.brands.slice(0, 4).join('、') || '—')}）</td><td><span class="flag opp">未解决 = 机会</span></td></tr>`;
  });
  h += `</tbody></table></div>`;
  return h;
}

function renderBenchmarkTable(cs, prof) {
  if (!cs || cs.length < 2) return '';
  const TIER_RANK = { large: 4, mid: 3, small: 2, emerging: 1, unknown: 0 };
  const rank = c => {
    const r = (c.reviews && c.reviews.rating) || (c.ratingField && (c.ratingField.value != null ? c.ratingField.value : c.ratingField.rating)) || null;
    const rv = r ? (r.value != null ? r.value : r.rating) : 0;
    return (rv || 0) * 100 + (TIER_RANK[c.tier] || 0);
  };
  const sorted = cs.slice().sort((a, b) => rank(b) - rank(a));
  const leader = sorted[0];
  let focal = null, focalLabel = '';
  const ob = (ZB_OWN_BRANDS || []).map(s => String(s).toLowerCase());
  if (ob.length) {
    const hit = cs.find(c => ob.indexOf(String(c.name).toLowerCase()) >= 0);
    if (hit) { focal = hit; focalLabel = '你（自有品牌 ' + hit.name + '）'; }
  }
  if (!focal && prof && (prof.priceBand || (prof.sellingPoints && prof.sellingPoints.length))) {
    focal = { _profile: true, priceBand: prof.priceBand || null, sellingPoints: prof.sellingPoints || [] };
    focalLabel = '你（我的定位）';
  }
  if (!focal) { focal = sorted[1]; focalLabel = '第二（' + sorted[1].name + '）'; }
  const priceOf = c => c._profile
    ? (c.priceBand ? curSym(c.priceBand.currency) + c.priceBand.min + '–' + c.priceBand.max : '—')
    : fmtPrice(c);
  const ratingOf = c => c._profile ? '—（你未评分）' : fmtRating(c);
  const chOf = c => c._profile ? '—' : Object.keys(c.channels || {}).filter(k => c.channels[k] && c.channels[k].present).length + ' 个';
  const tierOf = c => c._profile ? '—' : (TIER_LABEL[c.tier] || c.tier || '—');
  const spOf = c => (c.sellingPoints && c.sellingPoints.length) ? c.sellingPoints.map(x => SP_ZH[x] || prettyKey(x)).join('、') : '—';
  const priceGap = () => {
    if (focal._profile && focal.priceBand && leader.priceBand && leader.priceBand.band) {
      return '你锚定 ' + priceOf(focal) + '；头部在 ' + lbl('priceBands', leader.priceBand.band) + '（' + esc(leader.priceBand.range || '') + '）';
    }
    return '—';
  };
  const spGap = () => {
    const fs = {}; (focal.sellingPoints || []).forEach(x => { fs[String(x)] = 1; });
    const ls = leader.sellingPoints || [];
    const overlap = ls.filter(x => fs[String(x)]).length;
    if (!ls.length) return '—';
    return overlap ? '卖点重合 ' + overlap + ' 项' : '卖点无重合（差异化空间）';
  };
  let h = '<div class="cat-sec"><h4>对标差距 · ' + esc(focalLabel) + ' vs 头部（' + esc(leader.name) + '）</h4>';
  h += '<table class="cat-table bench-table"><thead><tr><th>维度</th><th>' + esc(focalLabel) + '</th><th>头部 ' + esc(leader.name) + '</th><th>差距信号</th></tr></thead><tbody>';
  const rows = [
    ['价格带', priceOf(focal), priceOf(leader), priceGap()],
    ['评分', ratingOf(focal), ratingOf(leader), focal._profile ? '补全自评后可见' : '—'],
    ['渠道覆盖', chOf(focal), chOf(leader), '—'],
    ['体量', tierOf(focal), tierOf(leader), '—'],
    ['主推卖点', spOf(focal), spOf(leader), spGap()]
  ];
  rows.forEach(function(rw) {
    h += '<tr><td>' + rw[0] + '</td><td>' + esc(String(rw[1])) + '</td><td>' + esc(String(rw[2])) + '</td><td>' + esc(rw[3]) + '</td></tr>';
  });
  h += '</tbody></table></div>';
  return h;
}

function renderSectorView(r) {
  if (!r || !r.sector) return '<p class="hint">无数据。</p>';
  const sec = r.sector;
  const conc = sec.concentration || {};
  let html = `<div class="cat-head"><div><h3>品类扫描 · ${esc(r.sectorName || '')}</h3>`;
  html += `<span class="muted">共 ${r.brandCount || 0} 家 · ${esc(r.note || '聚合不撒谎：赛道结论受最弱样本约束')}</span></div></div>`;
  // 集中度指标（聚合层）
  if (conc) {
    html += `<div class="cat-metrics">
      <div class="cm"><span class="cm-k">集中度 HHI</span><span class="cm-v">${conc.HHI != null ? conc.HHI : '—'} · ${esc(conc.hhiInterpretation || '')}</span></div>
      <div class="cm"><span class="cm-k">CR3</span><span class="cm-v">${fmtPct(conc.CR3)}</span></div>
      <div class="cm"><span class="cm-k">CR5</span><span class="cm-v">${fmtPct(conc.CR5)}</span></div>
    </div>`;
    if (conc.note) html += `<p class="hint">${esc(conc.note)}</p>`;
  }
  // 关键表格：横向对比各品牌（取自 state.competitors，字段更丰富：主推/评分/体量）
  const excluded = new Set((state && state.excluded) || []);
  const cs = (state && state.competitors || []).filter(c => !excluded.has(c.id) && c.status === 'done');
  if (cs.length) {
    html += `<table class="cat-table"><thead><tr><th>品牌</th><th>价格带</th><th>主推</th><th>在售渠道</th><th>评分</th><th>体量</th></tr></thead><tbody>`;
    cs.forEach(c => {
      const ch = c.channels || {};
      const presentCh = Object.keys(ch).filter(k => ch[k] && ch[k].present);
      const tier = (c.tier) ? (TIER_LABEL[c.tier] || c.tier) : '—';
      const heroTag = (c.heroProduct && c.heroProduct.kind !== 'verified') ? ' <span class="mini-tag infer">推</span>' : '';
      html += `<tr><td>${esc(c.name || '')}</td><td>${esc(fmtPrice(c))}</td><td>${esc(fmtHero(c))}${heroTag}</td><td>${presentCh.length} 个（${esc(presentCh.slice(0, 4).map(k => lbl('channels', k)).join('、') || '—')}）</td><td>${esc(fmtRating(c))}</td><td>${esc(tier)}</td></tr>`;
    });
    html += `</tbody></table>`;
  }
  // 价格带分布（含空档★标记）
  if (Array.isArray(sec.priceBands) && sec.priceBands.length) {
    html += `<div class="cat-sec"><h4>价格带分布</h4><table class="cat-table"><thead><tr><th>价格带</th><th>品牌数</th><th>占比</th><th>代表品牌</th><th>空档</th></tr></thead><tbody>`;
    sec.priceBands.forEach(g => {
      const cnt = g.count || 0;
      const gapMark = cnt <= 1 ? `<span class="flag opp">★ 空档</span>` : '';
      html += `<tr><td>${esc(g.band || '—')}</td><td>${cnt}</td><td>${fmtPct(g.share)}</td><td>${esc((g.brands || []).slice(0, 5).join('、') || '—')}</td><td>${gapMark}</td></tr>`;
    });
    html += `</tbody></table></div>`;
  }
  // F9：痛点机会表（聚合对手抱怨，标"未解决=机会"）
  const painOpp = renderPainOpportunityTable(cs);
  if (painOpp) html += painOpp;
  // 渠道矩阵
  if (sec.channelMatrix && Array.isArray(sec.channelMatrix.rows) && sec.channelMatrix.rows.length) {
    const head = (sec.channelMatrix.rows[0].brands || []).map(b => `<th>${esc(b.name || '')}</th>`).join('');
    html += `<div class="cat-sec"><h4>渠道矩阵</h4><table class="cat-table"><thead><tr><th>渠道</th>${head}</tr></thead><tbody>`;
    sec.channelMatrix.rows.forEach(row => {
      const cells = (row.brands || []).map(b => `<td>${b.present ? '✓' : '—'}</td>`).join('');
      html += `<tr><td>${esc(row.channel || '')}</td>${cells}</tr>`;
    });
    html += `</tbody></table></div>`;
  }
  // F12：对标差距表（焦距：自有品牌 → 我的定位 → 第二）
  const bench = renderBenchmarkTable(cs, (state && state.intent && state.intent.profile) || null);
  if (bench) html += bench;
  // 赛道空白（聚合层；字段可能为 .whitespace 或 .gaps）
  const wsGaps = (r.whitespace && (r.whitespace.whitespace || r.whitespace.gaps)) || [];
  if (Array.isArray(wsGaps) && wsGaps.length) {
    html += `<div class="cat-sec"><h4>赛道空白（对手留的空位）</h4><ul class="cat-list">` +
      wsGaps.slice(0, 10).map(g => `<li>${esc(typeof g === 'string' ? g : (g.gap || g.label || ''))}</li>`).join('') +
      `</ul></div>`;
  }
  // 赛道趋势
  const trendItems = (r.trend && (r.trend.items || (Array.isArray(r.trend) ? r.trend : null))) || [];
  if (Array.isArray(trendItems) && trendItems.length) {
    html += `<div class="cat-sec"><h4>赛道趋势</h4><ul class="cat-list">` +
      trendItems.slice(0, 8).map(t => `<li>${esc(typeof t === 'string' ? t : (t.statement || t.label || ''))}</li>`).join('') +
      `</ul></div>`;
  }
  if (!cs.length && !wsGaps.length && !trendItems.length) {
    html += `<p class="hint">当前赛道暂未计算出空白或趋势信号（样本不足或采集覆盖有限）。</p>`;
  }
  // 旗舰：机会地图（产品#1 差异点 · 对手没做好的地方）——挂在独立容器，renderOpportunity 注入
  html += `<div id="opportunityContainer" class="opp-container"></div>`;
  return html;
}

// ---------- 竞争象限（S3-⑤）：强度 × 机会，调 /api/quadrant ----------
async function renderQuadrantTab() {
  const wrap = $('#quadrantWrap');
  if (!wrap || !state) return;
  wrap.innerHTML = '<p class="hint">正在计算竞争象限…</p>';
  try {
    const r = await api('/api/quadrant', { method: 'POST' });
    wrap.innerHTML = renderQuadrantView(r);
  } catch (e) {
    wrap.innerHTML = `<p class="err">象限图加载失败：${esc(String((e && e.message) || e))}</p>`;
  }
}
function renderQuadrantView(r) {
  if (!r || !r.points || !r.points.length) return '<p class="hint">暂无可展示的对手（至少需已就绪对手）。</p>';
  const hidden = r.opportunity && r.opportunity.hidden;
  let html = `<div class="quad-head"><div><h3>竞争象限 · 强度 × 机会</h3>`;
  html += `<span class="muted">${r.brandCount || 0} 家 · Y=竞争强度（体量 + 份额）· X=机会暴露（用户声音缺口，越靠右越值得下注）</span></div></div>`;
  if (r.note) html += `<p class="hint">${esc(r.note)}</p>`;
  if (hidden) {
    const reason = r.opportunity.reason === 'need_more_voice'
      ? `机会维度需要至少 3 家对手采到用户声音（当前 ${r.opportunity.brandsWithVoice || 0} / ${r.opportunity.doneBrands || 0} 家有声音，覆盖率 ${r.opportunity.coveragePct || 0}%）。此时 X 轴"机会暴露"不可比，仅按竞争强度归入"待补数据"中性区，不判避/攻。`
      : `机会维度需要至少 3 家已就绪对手。此时仅按竞争强度归入"待补数据"中性区，不判避/攻。`;
    html += `<div class="ws-empty"><h4>机会维度样本不足</h4><p>${esc(reason)}</p></div>`;
  }
  html += quadrantSvg(r);
  const byId = {};
  (r.points || []).forEach(p => { byId[p.id] = p; });
  const QZ = [
    ['priority', '优先下注', '低强度 · 高机会'],
    ['headToHead', '正面交锋', '高强度 · 高机会'],
    ['avoid', '暂避', '高强度 · 低机会'],
    ['watch', '观察', '低强度 · 低机会'],
    ['unknown', '待补数据', '机会样本不足 · 不判避/攻'],
  ];
  html += `<div class="quad-legend">` + QZ.map(([k, zh, desc]) => {
    const ids = (r.quadrants && r.quadrants[k]) || [];
    const arr = ids.map(id => byId[id]).filter(Boolean);
    const items = arr.map(p => `<li>${esc(p.name)}</li>`).join('');
    return `<div class="quad-leg-item quad-${k}"><div class="quad-leg-title"><b>${zh}</b> <span class="muted">(${desc})</span></div>${items ? `<ul class="quad-ul">${items}</ul>` : '<span class="muted"> —</span>'}</div>`;
  }).join('') + `</div>`;
  return html;
}
function quadrantSvg(r) {
  const W = 680, H = 440, padl = 54, padr = 20, padt = 26, padv = 46;
  const plotW = W - padl - padr, plotH = H - padt - padv;
  const x0 = padl, y0 = padt, x1 = padl + plotW, y1 = padt + plotH;
  const oxM = (r.opportunityMid != null) ? r.opportunityMid : 0.5;
  const eyM = (r.entrenchmentMid != null) ? r.entrenchmentMid : 0.5;
  const sx = v => x0 + Math.max(0, Math.min(1, v)) * plotW;
  const sy = v => y1 - Math.max(0, Math.min(1, v)) * plotH;
  const mx = sx(oxM), my = sy(eyM);
  const zc = { priority: '#eafaf0', headToHead: '#fff5ec', avoid: '#fdeeee', watch: '#f3f5f7', unknown: '#eef0f3' };
  const colOf = { priority: '#2e9e5b', headToHead: '#e0883a', avoid: '#d9534f', watch: '#8896a6', unknown: '#8b95a1' };
  let s = `<svg class="quad-svg" viewBox="0 0 ${W} ${H}" width="100%" preserveAspectRatio="xMidYMid meet" role="img" aria-label="竞争象限图">`;
  s += `<rect x="${x0}" y="${y0}" width="${mx - x0}" height="${my - y0}" fill="${zc.priority}"/>`;
  s += `<rect x="${mx}" y="${y0}" width="${x1 - mx}" height="${my - y0}" fill="${zc.headToHead}"/>`;
  s += `<rect x="${mx}" y="${my}" width="${x1 - mx}" height="${y1 - my}" fill="${zc.avoid}"/>`;
  s += `<rect x="${x0}" y="${my}" width="${mx - x0}" height="${y1 - my}" fill="${zc.watch}"/>`;
  s += `<text x="${(x0 + mx) / 2}" y="${y0 + 16}" fill="#3a7d52" font-size="12" font-weight="600" text-anchor="middle">优先下注</text>`;
  s += `<text x="${(mx + x1) / 2}" y="${y0 + 16}" fill="#b06a23" font-size="12" font-weight="600" text-anchor="middle">正面交锋</text>`;
  s += `<text x="${(mx + x1) / 2}" y="${y1 - 8}" fill="#b0433f" font-size="12" font-weight="600" text-anchor="middle">暂避</text>`;
  s += `<text x="${(x0 + mx) / 2}" y="${y1 - 8}" fill="#5f6b78" font-size="12" font-weight="600" text-anchor="middle">观察</text>`;
  s += `<line x1="${x0}" y1="${y0}" x2="${x0}" y2="${y1}" stroke="#ccc"/>`;
  s += `<line x1="${x0}" y1="${y1}" x2="${x1}" y2="${y1}" stroke="#ccc"/>`;
  s += `<line x1="${mx}" y1="${y0}" x2="${mx}" y2="${y1}" stroke="#aaa" stroke-dasharray="4 3"/>`;
  s += `<line x1="${x0}" y1="${my}" x2="${x1}" y2="${my}" stroke="#aaa" stroke-dasharray="4 3"/>`;
  s += `<text x="${(x0 + x1) / 2}" y="${H - 8}" fill="#888" font-size="11" text-anchor="middle">机会暴露 →</text>`;
  s += `<text x="16" y="${(y0 + y1) / 2}" fill="#888" font-size="11" text-anchor="middle" transform="rotate(-90 16 ${(y0 + y1) / 2})">竞争强度 →</text>`;
  (r.points || []).forEach(p => {
    const cx = sx(p.opportunityUnknown ? oxM : (p.opportunity || 0));
    const cy = sy(p.entrenchment || 0);
    const col = colOf[p.quadrant] || '#555';
    s += `<circle cx="${cx}" cy="${cy}" r="6" fill="${col}" fill-opacity="0.85" stroke="#fff" stroke-width="1.5"/>`;
    const label = p.name + (p.opportunityUnknown ? ' *' : '');
    s += `<text x="${cx + 9}" y="${cy + 4}" fill="#333" font-size="11" text-anchor="start">${esc(label)}</text>`;
  });
  s += `</svg>`;
  if (r.points && r.points.some(p => p.opportunityUnknown)) {
    s += `<p class="quad-foot muted">* 标星者机会维度样本不足，归入"待补数据"中性区（灰色，置于机会轴中线），不判避/攻；采到 ≥3 家对手用户声音后可解锁象限归属。</p>`;
  }
  return s;
}
// ---------- 私有备注（S3-④）：调 /api/user-notes，按用户隔离，永不全局 ----------
function renderPrivateNote(c) {
  const val = (userNotes[c.id] != null) ? userNotes[c.id] : '';
  const preview = val
    ? (val.length > 42 ? esc(val.slice(0, 42)) + '…' : esc(val))
    : '点击「编辑」记录你的观察';
  return `<div class="card-notes">
    <div class="notes-head"><span class="field-t">我的私有备注</span><span class="notes-hint">仅你自己可见 · 不进报告 · 不影响算法</span></div>
    <div class="fold" data-note-fold="${escAttr(c.id)}">
      <div class="t">我的笔记</div>
      <div class="s">${preview}</div>
      <div class="arr" data-note-edit="${escAttr(c.id)}">编辑</div>
    </div>
    <div class="note-editor" id="note-editor-${esc(c.id)}" style="display:none">
      <textarea class="notes-input" id="note-${esc(c.id)}" placeholder="记点什么：对手的软肋、你观察到的空位、下次要验证的假设…" maxlength="5000">${esc(val)}</textarea>
      <div class="notes-actions">
        <button class="btn-mini" data-savenote="${escAttr(c.id)}">保存备注</button>
        <span class="notes-saved" id="notesaved-${esc(c.id)}"></span>
      </div>
    </div>
  </div>`;
}
function toggleNoteEditor(cid) {
  const ed = document.getElementById('note-editor-' + cid);
  if (!ed) return;
  const hidden = ed.style.display === 'none';
  ed.style.display = hidden ? '' : 'none';
  const arr = document.querySelector('[data-note-edit="' + cssEscape(cid) + '"]');
  if (arr) arr.textContent = hidden ? '收起' : '编辑';
}
function ensureUserNote(cid) {
  if (Object.prototype.hasOwnProperty.call(userNotes, cid)) return; // 已知（含空串）
  userNotes[cid] = undefined; // 标记拉取中
  api('/api/user-notes?competitorId=' + encodeURIComponent(cid), { method: 'GET' })
    .then(r => {
      const t = (r.note && r.note.text) || '';
      userNotes[cid] = t;
      const ta = document.getElementById('note-' + cid);
      if (ta && !ta.value) ta.value = t;
    })
    .catch(() => { userNotes[cid] = ''; });
}
async function saveUserNote(cid, btn) {
  const ta = document.getElementById('note-' + cid);
  if (!ta) return;
  const text = ta.value;
  btn.disabled = true;
  try {
    const r = await api('/api/user-notes', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ competitorId: cid, text }) });
    userNotes[cid] = (r.note && r.note.text) || '';
    const saved = document.getElementById('notesaved-' + cid);
    if (saved) saved.textContent = r.deleted ? '已清除' : '已保存 ✓';
    setTimeout(() => { if (saved) saved.textContent = ''; }, 2000);
  } catch (e) {
    const saved = document.getElementById('notesaved-' + cid);
    if (saved) saved.textContent = '保存失败';
  } finally { btn.disabled = false; }
}

// 切换 tab（支持从雷达卡片点击跳转并展开目标卡；U3 起由左侧导航驱动）
function switchTab(tab, cid) {
  // 顶栏（设计稿 §2）：tbName 显示当前面板名，crumb 为纯分隔符，tb-track 显示赛道
  const PANEL_NAMES = { workbench: '工作台', radar: '竞品雷达', intel: '情报库', opportunity: '机会视图', sector: '赛道档案', history: '历史调研', assets: '算法资产', category: '品类扫描' };
  const tbN = $('#tbName'); if (tbN) tbN.textContent = PANEL_NAMES[tab] || tab;
  const tbC = $('#tbCrumb'); if (tbC) tbC.textContent = '/';
  // 兼容新旧导航：.tab（旧顶部）/ .nav-item（新左侧）
  $$('.tab').forEach(x => x.classList.toggle('active', x.dataset.tab === tab));
  $$('.nav-item').forEach(x => x.classList.toggle('active', x.dataset.tab === tab));
  $$('.tab-panel').forEach(p => p.classList.remove('active'));
  const panel = $('#tab-' + tab);
  if (panel) { panel.classList.remove('hidden'); panel.classList.add('active'); }
  if (cid) {
    currentIntelId = cid; // U5：情报库档案页——直接定位到该对手档案
    renderIntelTab();
    const panelEl = $('#tab-intel');
    if (panelEl) panelEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  if (tab === 'workbench') { renderRadarStatus(); renderWorkbench(); }
  if (tab === 'radar') { renderRadarTab(); renderGate(); }
  if (tab === 'intel') { renderIntelTab(); }
  if (tab === 'opportunity') { renderOpportunityTab(); }
  if (tab === 'sector') { renderSectorTab(); }
  if (tab === 'history') { renderHistoryTab(); }
  if (tab === 'assets') { renderAssetsTab(); }
  // 旧 tab 兼容
  if (tab === 'category') { renderCategoryScanTab(); renderQuadrantTab(); }
  // 同步 hash（便于深链与无头验证）
  try { history.replaceState(null, '', '#' + tab); } catch {}
}

// ---------- 闸门侧栏（零焦虑：默认全参与，移除可拉回，自动重算，不显示成本） ----------
// 移除原因分类（与后端 EXCLUDE_REASONS 对齐；noTraction 是信号缺口，非算法错误）
const EXCLUDE_REASONS = [
  { key: 'irrelevant', zh: '不相关（非竞品）' },
  { key: 'noTraction', zh: '无体量（没流量）' },
  { key: 'wrongSegment', zh: '错品类（错位）' },
  { key: 'duplicate', zh: '重复（同名异写）' },
  { key: 'defunct', zh: '已退市 / 信息陈旧' },
];
const REASON_ZH = Object.fromEntries(EXCLUDE_REASONS.map(r => [r.key, r.zh]));
// 算法自动排除的原因（非用户手动选），给友好中文标签
const AUTO_REASON_ZH = { 'own-brand': '自有品牌 · 自动排除' };
let pendingRemoveId = null; // 正在选原因的那家

function renderGate() {
  if (!state) return;
  const gateList = $('#gateList');
  if (!gateList) return;
  const excluded = new Set(state.excluded || []);
  const all = state.competitors || [];
  const participating = all.filter(c => !excluded.has(c.id));
  const removed = all.filter(c => excluded.has(c.id));
  const gateCnt = $('#gateCount');
  if (gateCnt) gateCnt.textContent = `${participating.length} 家`;
  gateList.innerHTML = '';
  participating.slice().sort((a, b) => (b.rankScore || 0) - (a.rankScore || 0)).forEach(c => {
    const rel = c.relationship || { code: 'undetermined' };
    const item = document.createElement('div');
    item.className = 'gate-item';
    item.innerHTML = `<span class="g-av">${esc((c.name || '?')[0])}</span>
      <span class="g-nm" title="${escAttr(c.name)}">${esc(c.name)}</span>
      <button class="g-x" data-gateremove="${escAttr(c.id)}" title="移出">✕</button>`;
    // 行内原因选择：选了才真移，避免误触；原因是喂算法的关键信号
    if (pendingRemoveId === c.id) {
      const box = document.createElement('div');
      box.className = 'gate-reasons';
      box.innerHTML = `<span class="gate-reasons-q">为什么不算对手？</span>` +
        EXCLUDE_REASONS.map(r => `<button class="gate-reason" data-reason="${r.key}" data-rid="${escAttr(c.id)}">${esc(r.zh)}</button>`).join('') +
        `<button class="gate-reason cancel" data-reasoncancel="1">取消</button>`;
      item.appendChild(box);
      item.classList.add('choosing');
    }
    gateList.appendChild(item);
  });
  const toggle = $('#gateRemovedToggle');
  const remList = $('#gateRemovedList');
  if (removed.length) {
    toggle.classList.remove('hidden');
    $('#gateRemovedCount').textContent = removed.length;
    remList.innerHTML = '';
    removed.forEach(c => {
      const item = document.createElement('div');
      item.className = 'gate-item off';
      const rk = (state.excludedReasons || {})[c.id];
      const rzh = rk ? (AUTO_REASON_ZH[rk] || REASON_ZH[rk] || rk) : '';
      item.innerHTML = `<span class="g-av">${esc((c.name || '?')[0])}</span>
        <span class="g-nm">${esc(c.name)}</span>
        ${rzh ? `<span class="gate-reason-tag${rk === 'noTraction' ? ' blind' : ''}" title="${rk === 'noTraction' ? '信号缺口：我们当前没有流量数据源，无法自动判断' : '算法可学的信号'}">${escAttr(rzh)}</span>` : ''}
        <button class="g-x" data-gaterestore="${escAttr(c.id)}" title="拉回">↺</button>`;
      remList.appendChild(item);
    });
  } else {
    toggle.classList.add('hidden');
    remList.classList.add('hidden');
    remList.innerHTML = '';
  }
}
// 第一步：只展开原因选择，不动数据
function gateAskReason(id) { pendingRemoveId = (pendingRemoveId === id ? null : id); renderGate(); }
// 第二步：带原因提交
async function gateRemove(id, reason) {
  const c = (state.competitors || []).find(x => x.id === id);
  pendingRemoveId = null;
  try {
    const s = await api('/api/exclude', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, action: 'remove', reason }) });
    state = s; renderAll();
    const rel = c && c.relationship ? c.relationship.code : 'undetermined';
    const evN = (c && c.evidenceList ? c.evidenceList.length : 0) + (c && c.attempts ? c.attempts.filter(a => a.hit).length : 0);
    let hint = `已移出 ${c ? c.name : ''}。下次搜同赛道会自动排除它。`;
    if (reason === 'noTraction')
      hint = `已移出 ${c ? c.name : ''}。说明：我们目前没有流量数据源，这类"没流量"判断算法暂时学不会——已记进纠错报告，供你决定是否接流量源。`;
    else if (rel === 'direct' || (c && c.confidence === 'high' && evN >= 3))
      hint = `已移出 ${c.name}。提示：它与你的定位高度重叠且有 ${evN} 条证据支撑，移出后空白视图可能漏掉直接竞品——如误删，可在下方「已移除」拉回。`;
    toast(hint);
  } catch (e) { toast('移出失败：' + (e.message || e)); }
}
// 正向信号：手工补一个真对手（雷达页「补录对手」入口；闸门内联补录区已移除）
async function gateAddCompetitor(forcedName) {
  const inp = $('#gateAddName'); // 兼容旧闸门内联输入（已移除，仅防残留引用）
  const btn = $('#gateAddBtn');
  const name = String(forcedName != null ? forcedName : (inp && inp.value || '')).trim();
  if (!name) { toast('先填品牌名'); return; }
  if (btn) { btn.disabled = true; btn.textContent = '查询中…'; }
  try {
    const s = await api('/api/lookup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, userAdded: true }) });
    state = s; renderAll();
    if (inp) inp.value = '';
    toast(`已补录 ${name}，正在补齐它的档案。这条"算法漏了谁"已记进纠错报告。`);
  } catch (e) { toast('补录失败：' + (e.message || e)); }
  finally { if (btn) { btn.disabled = false; btn.textContent = '补录'; } }
}
async function gateRestore(id) {
  try {
    const s = await api('/api/exclude', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, action: 'restore' }) });
    state = s; renderAll();
    toast('已拉回名单，空白视图已重算。');
  } catch (e) { toast('拉回失败：' + (e.message || e)); }
}

function competitorCard(c, rankNo) {
  const el = document.createElement('article');
  el.className = 'card status-' + c.status + (expandedIds.has(c.id) ? ' expanded' : '');
  el.dataset.cid = c.id; // ▶ P1-1：就地替换展开卡用，避免整列表重排导致滚动丢失
  const done = c.status === 'done';
  const researching = c.status === 'researching';
  const skeleton = c.status === 'skeleton';
  const error = c.status === 'error';
  const tierLabel = TIER_LABEL[c.tier] || '体量未明';

  let html = '';
  // 头部（点击展开/收起）
  html += `<div class="card-head" data-toggle="${escAttr(c.id)}">
    <div class="card-title">
      <span class="rank">#${rankNo}</span>
      <h3>${esc(c.name)}</h3>
      ${c.url ? `<a class="ext" href="${escAttr(c.url)}" target="_blank" rel="noopener" onclick="event.stopPropagation()">↗</a>` : ''}
    </div>
    <div class="badges">
      <span class="pill tier ${c.tier}">${tierLabel}</span>
      ${c.entityAmbiguous ? `<span class="pill ambiguous" title="${escAttr(c.ambiguousNote || '同名多实体，可能为混淆的不同对手，结论请按官网核实')}">同名多实体·存疑</span>` : ''}
      ${c.flaggedOutlier ? `<span class="pill outlier" title="${escAttr(c.outlierNote || '量级声称矛盾，请按官方披露核实')}">量级存疑</span>` : ''}
      ${competitorGateChip(c)}
      ${c.matchScore ? `<span class="pill match">匹配 ${c.matchScore}</span>` : ''}
      ${skeleton ? '<span class="pill st">待调研</span>' : ''}
      ${researching ? '<span class="pill st researching">调研中…</span>' : ''}
      ${done ? '<span class="pill st ok">已就绪</span>' : ''}
      ${error ? '<span class="pill st err">调研失败</span>' : ''}
      <span class="caret">${expandedIds.has(c.id) ? '▾' : '▸'}</span>
    </div>
  </div>`;

  if (c.why && !done) html += `<p class="why">${esc(c.why)}</p>`;

  // 收起态（L0 卡面）：筛选型 + 机会钩子——与你的关系 / 价格带 / 主力渠道 / 最突出差评（置信度在头部）
  if (done) {
    const rel = c.relationship || { code: 'undetermined' };
    const priceTxt = c.priceBand
      ? `${lbl('priceBands', c.priceBand.band)} ${esc(c.priceBand.range || '')}`
      : ((c.pricePoints && c.pricePoints.length) ? `${curSym(c.currency)}${Math.min(...c.pricePoints)}起` : '价位未明');
    const ch = c.channels || {};
    const topCh = Object.keys(ch).filter(k => ch[k].present).slice(0, 3).map(k => lbl('channels', k));
    const mainCh = topCh.length ? topCh.join('、') : '渠道未明';
    const negTop = (c.reviews && c.reviews.negThemes && c.reviews.negThemes.length)
      ? c.reviews.negThemes.slice(0, 2).join('、') : '暂无明显差评';
    const relCls = relClsOf(rel.code);
    html += `<div class="l0-row">
      <div class="l0-cell"><span class="l0-k">与你的关系</span><span class="l0-v rel-${relCls}">${esc(rel.label || REL_LABEL[rel.code] || '关系待定')}</span></div>
      <div class="l0-cell"><span class="l0-k">价格带</span><span class="l0-v">${esc(priceTxt)}</span></div>
      <div class="l0-cell"><span class="l0-k">主力渠道</span><span class="l0-v">${esc(mainCh)}</span></div>
      <div class="l0-cell"><span class="l0-k">最突出差评</span><span class="l0-v ${negTop === '暂无明显差评' ? 'muted' : ''}">${escAttr(negTop)}</span></div>
    </div>`;
    if (c.inferred && c.inferred.length) html += `<span class="pill inferred">含 ${c.inferred.length} 项推算</span>`;
    if (c.entityAmbiguous) html += `<p class="hint ambiguous-note">⚠ 同名多实体：该归一化名映射到不同域名主页，可能为混淆的不同对手，结论请谨慎参考并按官网核实。</p>`;
    if (c.flaggedOutlier) html += `<p class="hint outlier-note">⚠ 量级存疑：宣称体量与该品牌的营收口径或自述矛盾（${esc(c.outlierNote || '')}），请按官方披露核实。</p>`;
  }

  if (skeleton) html += `<p class="hint">已识别，等待 AI 逐家深研…</p>`;
  else if (researching) html += `<p class="hint">AI 正在调取来源、填全景字段…</p>`;
  else if (error) html += `<p class="hint err">${esc(c.evidence || '该对手调研失败，可重试')}</p>`;

  // 展开态：完整字段 + 时间线
  if (expandedIds.has(c.id)) {
    html += `<div class="card-detail">`;
    if (done) {
      html += renderDetails(c);
      html += `<div class="timeline-block">
        <div class="timeline-head">
          <span class="field-t">时间线 · 战略 / 战术演进</span>
          <button class="btn-mini" data-timeline="${escAttr(c.id)}">${timelineCache.has(c.id) ? '重新检索时间线' : '深度检索时间线 →'}</button>
        </div>
        <div class="timeline-body" id="tl-${esc(c.id)}">${timelineCache.has(c.id) ? renderTimeline(timelineCache.get(c.id)) : '<p class="hint">点击上方按钮，按时间线梳理该品牌在做什么、战略与战术层面的转变。</p>'}</div>
      </div>`;
      html += renderPrivateNote(c);
    }
    if (!done && !researching) html += `<div class="card-actions"><button class="btn-mini" data-enrich="${escAttr(c.id)}">优先深度调研此对手 →</button></div>`;
    html += `</div>`;
  }

  el.innerHTML = html;
  const head = el.querySelector('[data-toggle]');
  if (head) head.onclick = () => toggleCard(c.id);
  const eb = el.querySelector('[data-enrich]');
  if (eb) eb.onclick = (e) => { e.stopPropagation(); enrich(eb.dataset.enrich, eb); };
  const tl = el.querySelector('[data-timeline]');
  if (tl) tl.onclick = (e) => { e.stopPropagation(); fetchTimeline(tl.dataset.timeline, tl); };
  // ▶ S3-④：私有备注保存（按用户隔离，空串=清除；不影响算法、不进报告）
  el.querySelectorAll('[data-savenote]').forEach(b => {
    b.onclick = (e) => { e.stopPropagation(); saveUserNote(b.dataset.savenote, b); };
  });
  // ▶ F7：私有记录折叠 → 展开编辑
  const ne = el.querySelector('[data-note-edit]');
  if (ne) ne.onclick = (e) => { e.stopPropagation(); toggleNoteEditor(ne.dataset.noteEdit); };
  if (expandedIds.has(c.id) && done) ensureUserNote(c.id);
  // L1 六大类：智能折叠（本地切换，记忆于 l1Expanded）
  // 注意：每张卡有 6 个 .l1-head，必须用 querySelectorAll 遍历，否则只绑到第一个分类
  el.querySelectorAll('[data-l1toggle]').forEach(lt => {
    lt.onclick = (e) => {
      e.stopPropagation();
      const k = lt.dataset.l1toggle;
      const now = !(l1Expanded.has(k) ? l1Expanded.get(k) : null);
      l1Expanded.set(k, now);
      const sec = lt.closest('.l1-cat');
      if (sec) {
        const body = sec.querySelector('.l1-body');
        if (body) body.style.display = now ? '' : 'none';
        const caret = lt.querySelector('.caret');
        if (caret) caret.textContent = now ? '▾' : '▸';
      }
    };
  });
  // 三态"未探测"→ L2 单点深挖（#53 正式接入）；同样需遍历全部按钮
  el.querySelectorAll('[data-l2field]').forEach(l2b => {
    l2b.onclick = (e) => { e.stopPropagation(); triggerL2Field(l2b.dataset.cid, l2b.dataset.l2field); };
  });
  el.querySelectorAll('[data-l2mod]').forEach(l2m => {
    l2m.onclick = (e) => { e.stopPropagation(); triggerL2Module(l2m.dataset.cid, l2m.dataset.l2mod); };
  });
  // F5：速览卡 chips 导航 → 跳转到对应 L1 分块
  el.querySelectorAll('[data-goto]').forEach(g => {
    g.onclick = (e) => { e.stopPropagation(); gotoL1(g); };
  });
  // ▶ P1-5 北极星埋点：展开的品牌卡，停留 ≥3s 计一次「字段洞察被消费」（每卡每会话仅记一次，避免通胀）
  if (expandedIds.has(c.id) && done && !_fieldTracked.has(c.id)) {
    _fieldTracked.add(c.id);
    setTimeout(() => { if (expandedIds.has(c.id)) trackConsume('field', c.id, 'view', 3000); }, 3000);
  }
  return el;
}
const _fieldTracked = new Set();

function toggleCard(id) {
  if (expandedIds.has(id)) expandedIds.delete(id);
  else expandedIds.add(id);
  // ▶ P1-1：只就地替换这一张卡，不重画整列表（保留滚动位置与表格/象限）
  const grid = document.querySelector('.pano-cards');
  const oldEl = grid && grid.querySelector('.card[data-cid="' + cssEscape(id) + '"]');
  const c = (state.competitors || []).find(x => x.id === id);
  if (grid && oldEl && c) {
    const cs = (state.competitors || []).filter(x => !(new Set(state.excluded || [])).has(x.id)).slice().sort((a, b) => (b.rankScore || 0) - (a.rankScore || 0));
    const idx = cs.findIndex(x => x.id === id);
    const fresh = competitorCard(c, idx + 1);
    grid.replaceChild(fresh, oldEl);
  } else {
    renderCompetitors(); // 兜底：找不到旧节点时全量重画
  }
}
function cssEscape(s) { return String(s).replace(/["\\]/g, '\\$&'); }

// 字段来源标签：来自 comp.fieldSources[fieldKey]，可点开核验（每条可验证红线）
function srcTags(c, fieldKey) {
  const arr = (c.fieldSources || {})[fieldKey];
  if (!arr || !arr.length) return '';
  return arr.slice(0, 3).map(s =>
    `<a class="src-tag t${s.tier}" href="${escAttr(s.url)}" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="${escAttr(s.title || '')}">${SRC_ICON[s.kind] || '🔗来源'}</a>`
  ).join('');
}
// 价格字段三件套：值级核验结论 + 来源(含一致/冲突标记) + 置信度 + 纠错入口
function priceFieldHTML(c) {
  const pf = c.priceField || {};
  if (!pf.display) return '';
  const srcs = (pf.sources || []).map(s => {
    const ag = s.agrees === true ? ' ✓' : (s.agrees === false ? ' ✗' : '');
    const ic = s.agrees === true ? '✓' : (s.agrees === false ? '✗' : '🔗');
    return `<a class="src-tag ${s.agrees === false ? 'disagree' : ''}" href="${escAttr(s.url || '#')}" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="${escAttr((s.text || (s.kind || '')) + (ag ? '（' + ag.trim() + '）' : ''))}">${ic}${ag}</a>`;
  }).join(' ');
  let s = `<span class="pf-display ${pf.basis === 'conflict' ? 'conflict' : ''}">${escAttr(pf.display)}</span>`;
  s += gateBadge(pf);
  s += ` <span class="pf-scope" title="所有价格均按官网挂牌标价展示，不含税费与运费，跨币种不换算">官网标价·不含税运</span>`;
  if (pf.realScraped) s += ' <span class="tag">官网实抓</span>';
  s += `<div class="pf-meta">`;
  if (pf.conflictNote) s += `<span class="pf-note warn">⚠ ${esc(pf.conflictNote)}</span> `;
  if (srcs) s += `<span class="pf-src">来源：${srcs}</span>`;
  s += `</div>`;
  return s;
}
// 渠道字段三件套：逐渠道状态(在售/确认未入驻/未探测) + 来源(一致/冲突标记) + 置信度 + 纠错入口
function channelFieldHTML(c, chKey) {
  const cf = (c.channelFields && c.channelFields[chKey]) || {};
  const st = cf.state || (cf.present ? 'present' : (cf.basis === 'verified' ? 'absent' : 'undetected'));
  const stText = { present: '在售', absent: '确认未入驻', undetected: '暂未发现', conflict: '存在矛盾' }[st] || '—';
  const stCls = { present: 'present', absent: 'absent-v', undetected: 'und', conflict: 'conflict' }[st] || 'und';
  const srcs = (cf.sources || []).map(s => {
    const ag = s.agrees === true ? ' ✓' : (s.agrees === false ? ' ✗' : '');
    const ic = s.agrees === true ? '✓' : (s.agrees === false ? '✗' : '🔗');
    return `<a class="src-tag ${s.agrees === false ? 'disagree' : ''}" href="${escAttr(s.url || '#')}" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="${escAttr((s.text || (s.kind || '')) + ag)}">${ic}${ag}</a>`;
  }).join(' ');
  let s = `<span class="ch-state ${stCls}">${stText}</span>${gateBadge(cf)}`;
  if (cf.conflictNote) s += ` <span class="pf-note warn">⚠ ${esc(cf.conflictNote)}</span>`;
  if (srcs) s += ` <span class="pf-src">${srcs}</span>`;
  return s;
}
// 品类字段三件套：逐品类状态(在售/推断未经营/未探测) + 来源 + 置信度 + 纠错入口（与渠道同构）
function categoryFieldHTML(c, catKey) {
  const cf = (c.categoryFields && c.categoryFields[catKey]) || {};
  const st = cf.state || (cf.present ? 'present' : (cf.basis === 'verified' ? 'absent' : 'undetected'));
  const stText = { present: '在售', absent: '推断未经营', undetected: '暂未发现', conflict: '存在矛盾' }[st] || '—';
  const stCls = { present: 'present', absent: 'absent-v', undetected: 'und', conflict: 'conflict' }[st] || 'und';
  const srcs = (cf.sources || []).map(s => {
    const ic = s.agrees === false ? '✗' : '🔗';
    return `<a class="src-tag ${s.agrees === false ? 'disagree' : ''}" href="${escAttr(s.url || '#')}" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="${escAttr((s.text || (s.kind || '')))}">${ic}</a>`;
  }).join(' ');
  let s = `<span class="ch-state ${stCls}">${stText}</span>${gateBadge(cf)}`;
  if (cf.conflictNote) s += ` <span class="pf-note warn">⚠ ${esc(cf.conflictNote)}</span>`;
  if (srcs) s += ` <span class="pf-src">${srcs}</span>`;
  return s;
}
// 标量字段三件套：值 + 来源 + 置信度 + 纠错入口（上新节奏 / 口碑 复用）
function scalarFieldHTML(c, fieldKey, label) {
  const f = c[fieldKey] || {};
  if (!f.value && f.state !== 'conflict') return '';
  const srcs = (f.sources || []).map(s => {
    const ic = s.agrees === false ? '✗' : '🔗';
    return `<a class="src-tag ${s.agrees === false ? 'disagree' : ''}" href="${escAttr(s.url || '#')}" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="${escAttr((s.text || (s.kind || '')))}">${ic}</a>`;
  }).join(' ');
  let s = `<span class="pf-display ${f.basis === 'conflict' ? 'conflict' : ''}">${escAttr(f.value || '存在矛盾')}</span>${gateBadge(f)}`;
  if (f.conflictNote) s += ` <span class="pf-note warn">⚠ ${esc(f.conflictNote)}</span>`;
  if (srcs) s += ` <span class="pf-src">${srcs}</span>`;
  return s;
}
// ---------- 字段纠错（价格 + 渠道闭环）----------
let fcCurrentId = null;
let fcCurrentField = 'price';
const FC_PRICE_TYPES = [
  { v: 'wrong-value', t: '价格区间错了（我来给正确值）' },
  { v: 'wrong-currency', t: '币种标错了' },
  { v: 'over-confident', t: '置信度偏高，应降级' },
  { v: 'confirm-correct', t: '我确认这个价格是准的' },
  { v: 'missing-source', t: '应有价格但缺来源（待重研）' }
];
const FC_CHAN_TYPES = [
  { v: 'wrong-state', t: '渠道状态错了（我来给真实状态）' },
  { v: 'over-confident', t: '置信度偏高，应降级' },
  { v: 'confirm-correct', t: '我确认这个渠道判定准的' },
  { v: 'missing-source', t: '应有渠道证据但缺来源（待重研）' }
];
const FC_CAT_TYPES = [
  { v: 'wrong-state', t: '品类状态错了（我来给真实状态）' },
  { v: 'over-confident', t: '置信度偏高，应降级' },
  { v: 'confirm-correct', t: '我确认这个品类判定准的' },
  { v: 'missing-source', t: '应有品类证据但缺来源（待重研）' }
];
const FC_SCALAR_TYPES = [
  { v: 'wrong-value', t: '取值错了（我来给正确值）' },
  { v: 'over-confident', t: '置信度偏高，应降级' },
  { v: 'confirm-correct', t: '我确认这个取值准的' },
  { v: 'missing-source', t: '应有数据但缺来源（待重研）' }
];
const SCALAR_LABEL = { launchCadence: '上新节奏', 'reviews.rating': '口碑评分', 'reviews.trend': '口碑趋势' };
// ▶ P1-4：卡片级纠错——模态内字段选择器。列出该品牌当前有数据的可纠错项，由用户选具体哪项。
function buildFieldOptions(c) {
  const c0 = c || {};
  const opts = [];
  if (c0.priceField || c0.priceBand || (c0.pricePoints && c0.pricePoints.length)) opts.push({ v: 'price', t: '定价' });
  Object.keys(LABELS.channels).forEach(k => opts.push({ v: 'channels.' + k, t: '渠道 · ' + lbl('channels', k) }));
  if (c0.categoryFields) Object.keys(c0.categoryFields).forEach(k => opts.push({ v: 'categories.' + k, t: '品类 · ' + lbl('categories', k) }));
  if (c0.reviewField) { opts.push({ v: 'reviews.rating', t: '口碑评分' }); opts.push({ v: 'reviews.trend', t: '口碑趋势' }); }
  if (c0.launchCadence && c0.launchCadence.value) opts.push({ v: 'launchCadence', t: '上新节奏' });
  if (c0.reviewField && c0.reviewField.negThemes && c0.reviewField.negThemes.items) c0.reviewField.negThemes.items.forEach(i => opts.push({ v: 'reviews.negThemes.' + encodeURIComponent(i.text), t: '负面主题 · ' + i.text }));
  if (c0.reviewField && c0.reviewField.posThemes && c0.reviewField.posThemes.items) c0.reviewField.posThemes.items.forEach(i => opts.push({ v: 'reviews.posThemes.' + encodeURIComponent(i.text), t: '正面主题 · ' + i.text }));
  return opts.length ? opts : [{ v: 'price', t: '定价' }];
}
function applyFcField(field) {
  fcCurrentField = field;
  const isChan = fcCurrentField.indexOf('channels.') === 0;
  const isCat = fcCurrentField.indexOf('categories.') === 0;
  const isReviewSet = fcCurrentField.indexOf('reviews.negThemes.') === 0 || fcCurrentField.indexOf('reviews.posThemes.') === 0;
  const isScalar = SCALAR_LABEL[fcCurrentField] !== undefined;
  const sel = $('#fcType');
  const opts = isChan ? FC_CHAN_TYPES : (isCat ? FC_CAT_TYPES : (isReviewSet ? FC_CHAN_TYPES : (isScalar ? FC_SCALAR_TYPES : FC_PRICE_TYPES)));
  sel.innerHTML = opts.map(o => `<option value="${escAttr(o.v)}">${esc(o.t)}</option>`).join('');
  sel.value = opts[0].v;
  toggleFcWraps();
}
function openFieldCorrect(id, field) {
  fcCurrentId = id;
  const c = (state.competitors || []).find(x => x.id === id);
  const name = c ? c.name : id;
  const fsel = $('#fcField');
  const fopts = buildFieldOptions(c);
  fsel.innerHTML = fopts.map(o => `<option value="${escAttr(o.v)}">${esc(o.t)}</option>`).join('');
  const fv = field || fopts[0].v;
  fsel.value = fv;
  $('#fcTitle').textContent = '纠正「' + name + '」的数据';
  applyFcField(fv);
  $('#fcMin').value = ''; $('#fcMax').value = ''; $('#fcCur').value = ''; $('#fcValText').value = ''; $('#fcText').value = '';
  $('#fcStatus').textContent = '';
  $('#fieldCorrectModal').classList.remove('hidden');
}
function toggleFcWraps() {
  const type = $('#fcType').value;
  const isChan = fcCurrentField.indexOf('channels.') === 0;
  const isCat = fcCurrentField.indexOf('categories.') === 0;
  const isReviewSet = fcCurrentField.indexOf('reviews.negThemes.') === 0 || fcCurrentField.indexOf('reviews.posThemes.') === 0;
  const isSetField = isChan || isCat || isReviewSet;
  const isScalar = SCALAR_LABEL[fcCurrentField] !== undefined;
  $('#fcValueWrap').classList.toggle('hidden', !(!isSetField && !isScalar && type === 'wrong-value'));
  $('#fcCurWrap').classList.toggle('hidden', !(!isSetField && !isScalar && type === 'wrong-currency'));
  $('#fcStateWrap').classList.toggle('hidden', !(isSetField && type === 'wrong-state'));
  $('#fcValTextWrap').classList.toggle('hidden', !(isScalar && type === 'wrong-value'));
}
async function submitFieldCorrect() {
  if (!fcCurrentId) return;
  const type = $('#fcType').value;
  const isChan = fcCurrentField.indexOf('channels.') === 0;
  const isCat = fcCurrentField.indexOf('categories.') === 0;
  const isReviewSet = fcCurrentField.indexOf('reviews.negThemes.') === 0 || fcCurrentField.indexOf('reviews.posThemes.') === 0;
  const isSetField = isChan || isCat || isReviewSet;
  const isScalar = SCALAR_LABEL[fcCurrentField] !== undefined;
  const body = { id: fcCurrentId, field: fcCurrentField, type, text: $('#fcText').value.trim(), source: $('#fcSource').value.trim() };
  if (isScalar) {
    if (type === 'wrong-value') {
      const v = $('#fcValText').value.trim();
      if (!v) { $('#fcStatus').textContent = '请填写正确取值（如：月更及以上 / 高频）。'; return; }
      body.valueText = v;
    }
  } else if (!isSetField) {
    if (type === 'wrong-value') {
      const mn = parseFloat($('#fcMin').value), mx = parseFloat($('#fcMax').value);
      if (isNaN(mn) || isNaN(mx) || mn <= 0 || mx < mn) { $('#fcStatus').textContent = '请填正确的价格区间（最低≤最高，且为正）。'; return; }
      body.value = [mn, mx];
    }
    if (type === 'wrong-currency') {
      const cur = $('#fcCur').value.trim().toUpperCase();
      if (!/^[A-Z]{3}$/.test(cur)) { $('#fcStatus').textContent = '请填 3 位币种代码，如 USD / CNY / EUR。'; return; }
      body.currency = cur;
    }
  } else {
    if (type === 'wrong-state') {
      const v = $('#fcState').value;
      if (!['present', 'absent', 'undetected'].includes(v)) { $('#fcStatus').textContent = '请选择真实状态。'; return; }
      body.value = v;
    }
  }
  if (type !== 'confirm-correct' && !body.source) { $('#fcStatus').textContent = '请附上证据来源（必填，否则无法受理）。'; return; }
  const btn = $('#btnFcSend'); btn.disabled = true;
  try {
    const s = await api('/api/field-correct', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    state = s.state; applyPrivateOverride(s); renderAll();
    $('#fieldCorrectModal').classList.add('hidden');
    // 待复核：不直接改写可信结论，仅记录（T2-1 私有覆盖：仅该用户可见）
    if (s.status === 'pending') { toast(s.private ? '已收到你的私有纠错，待复核后触发系统重采（仅你可见，不影响系统结论）' : '已收到纠错，待复核后生效（不直接改写可信结论）'); return; }
    let msg = '已记录';
    if (isChan && s.channelField) {
      const stMap = { present: '在售', absent: '确认未入驻', undetected: '暂未发现', conflict: '存在矛盾' };
      msg = '已更新渠道判定：' + (stMap[s.channelField.state] || s.channelField.state) + (s.correction.type === 'confirm-correct' ? '（已确认）' : '（已生效）');
    } else if (isCat && s.categoryField) {
      const stMap = { present: '在售', absent: '推断未经营', undetected: '暂未发现', conflict: '存在矛盾' };
      msg = '已更新品类判定：' + (stMap[s.categoryField.state] || s.categoryField.state) + (s.correction.type === 'confirm-correct' ? '（已确认）' : '（已生效）');
    } else if (isScalar && s.launchCadence) {
      msg = '已更新「' + (SCALAR_LABEL[fcCurrentField] || '取值') + '」：' + (s.launchCadence.value || '—') + (s.correction.type === 'confirm-correct' ? '（已确认）' : '（已生效）');
    } else if (fcCurrentField.indexOf('reviews.') === 0 && s.reviewField) {
      msg = '已更新口碑（' + (SCALAR_LABEL[fcCurrentField] || '主题') + '）' + (s.correction.type === 'confirm-correct' ? '（已确认）' : '（已生效）');
    } else if (s.priceField) {
      msg = '已更新「' + (s.priceField.display) + '」' + (s.correction.type === 'confirm-correct' ? '（已确认）' : '（已生效）');
    }
    if (s.private) toast('你的私有覆盖已记录 · ' + msg + '（仅你可见，不影响系统结论）');
    else toast(msg);
  } catch (e) {
    $('#fcStatus').textContent = '提交失败：' + (e.message || e);
  } finally { btn.disabled = false; }
}

// T2-1 私有覆盖：把 /api/field-correct 返回的「该用户私有值」叠加到本地卡片（会话内可见；系统结论不变）。
// 说明：后端纠错不再写全局 state，故前端需在用户自己提交后，把他/她的私有值应用到这张卡上，
// 让"仅我可见的覆盖"立刻可见。系统态未被改动（decorateState 仍只反映全局/系统值）。
function applyPrivateOverride(s) {
  if (!s || !s.correction) return;
  const fc = s.correction, f = fc.field;
  const c = (state && state.competitors || []).find(x => x.id === fc.competitorId);
  if (!c) return;
  if (f.indexOf('channels.') === 0) { c.channelFields = c.channelFields || {}; c.channelFields[f.split('.')[1]] = s.channelField; }
  else if (f.indexOf('categories.') === 0) { c.categoryFields = c.categoryFields || {}; c.categoryFields[f.split('.')[1]] = s.categoryField; }
  else if (f.indexOf('price') === 0) { c.priceField = s.priceField; }
  else if (f === 'launchCadence') { c.launchCadence = s.launchCadence; }
  else if (f.indexOf('reviews.') === 0) { c.reviewField = s.reviewField; }
}

// F5：情报库详情速览卡（指标 + 分块导航 chips）
function renderOverviewCard(c) {
  const price = c.priceBand
    ? `${lbl('priceBands', c.priceBand.band)} ${esc(c.priceBand.range || '')}`
    : (fmtPrice(c) || '—');
  const rating = fmtRating(c);
  const ch = c.channels || {};
  const chN = Object.keys(ch).filter(k => ch[k] && ch[k].present).length;
  let negN = 0;
  if (c.reviewField && c.reviewField.negThemes && c.reviewField.negThemes.items) negN = c.reviewField.negThemes.items.length;
  else if (c.reviews && c.reviews.negThemes) negN = c.reviews.negThemes.length;
  const cats = (typeof L1_ORDER !== 'undefined' ? L1_ORDER : []).map(k => ({ key: k, title: (L1_META[k] && L1_META[k].title) || k }));
  const chips = cats.map(cat => `<span class="chip" data-goto="${escAttr(cat.key)}">${esc(cat.title)}</span>`).join('');
  return `<div class="overview-card">
    <div class="metrics">
      <div class="metric"><div class="k">价格区间</div><div class="v">${esc(price)}</div></div>
      <div class="metric"><div class="k">评分</div><div class="v">${esc(rating)}</div></div>
      <div class="metric"><div class="k">渠道</div><div class="v">${chN} 个</div></div>
      <div class="metric"><div class="k">差评主题</div><div class="v">${negN} 类</div></div>
    </div>
    <div class="chips">${chips}</div>
  </div>`;
}

// 速览卡 chips → 跳转到对应 L1 分块并展开（不重渲染，就地操作保留滚动）
function gotoL1(chipEl) {
  const catKey = chipEl.dataset.goto;
  if (!catKey) return;
  const card = chipEl.closest('.card');
  const sec = (card ? card.querySelector('.l1-cat[data-cat="' + cssEscape(catKey) + '"]') : null)
    || document.querySelector('.l1-cat[data-cat="' + cssEscape(catKey) + '"]');
  if (!sec) return;
  const body = sec.querySelector('.l1-body');
  if (body) body.style.display = '';
  const caret = sec.querySelector('.caret');
  if (caret) caret.textContent = '▾';
  sec.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function renderDetails(c) {
  const prof = (state.intent && state.intent.profile) || null;
  let h = renderOverviewCard(c);
  h += renderL1(c, prof);
  // 证据 / 来源（忠实助理：每条可溯，全部可点开核验）——始终可见，不折叠
  let foot = '';
  const evList = c.evidenceList || [];
  if (evList.length) {
    foot += `<span class="src">本轮证据 ${evList.length} 条：</span> `;
    foot += evList.slice(0, 8).map(e => `<a class="src-tag t${e.tier}" href="${escAttr(e.url)}" target="_blank" rel="noopener" title="${escAttr(e.title || '')}">${e.id}·${SRC_ICON[e.kind] || '🔗'}</a>`).join(' ');
  } else if (c.evidenceCount) foot += `<span class="src">交叉验证来源 ${c.evidenceCount} 处</span>`;
  if (c.evidence) foot += ` <span class="muted">${esc(c.evidence)}</span>`;
  if (foot) h += `<div class="evidence">${foot}</div>`;
  // ▶ P1-4：纠错回退卡片级——每张卡仅一个入口（不再每字段挂按钮，避免暗示"数据可议"+竞品探测入口）。
  // 点开后由模态内字段选择器选具体哪项，审核纪律不变（待复核队列、须附证据）。
  h += `<div class="card-foot"><button class="btn-mini fc-card" data-fieldcorrect="${escAttr(c.id)}">纠错这张卡的数据 →</button></div>`;
  return h;
}
// ---- 口碑复合字段渲染辅助（reviews.rating/trend 标量 + neg/pos 主题列表）----
// ▶ 呈现层反转：置信评分永不显示为标签。仅保留"两信号"：verified(准)→零标注；inferred(推)/conflict→推算/冲突 标记（非置信度）。
function confBadge(k) {
  if (!k) return '';
  if (k.basis === 'inferred') return ' <span class="tag inferred">推算</span>';
  if (k.basis === 'conflict') return ' <span class="tag">冲突</span>';
  return '';
}
function srcTagsFromSources(sources) {
  if (!sources || !sources.length) return '';
  return ' ' + sources.map(s => `<a class="src-tag" href="${escAttr(s.url || '#')}" target="_blank" rel="noopener" title="${escAttr(s.text || '')}">${s.url ? '🔗' : '·'}</a>`).join('');
}
function themeChip(c, item, kind) {
  const enc = encodeURIComponent(item.text);
  const field = 'reviews.' + kind + '.' + enc;
  const stMap = { present: '在列', absent: '确认无', undetected: '暂未发现', conflict: '矛盾' };
  const st = stMap[item.state] || (item.present ? '在列' : '确认无');
  return `<span class="theme-chip ${item.state || 'present'}">${escAttr(item.text)} <span class="theme-state ${item.state || 'present'}">${st}</span></span>`;
}

// 各六大类的数据块（有数据才产出；逻辑沿用原逐字段渲染，仅做归类）
const L1_ITEMS = {
  pricing(c) {
    const items = [];
    if (c.priceField && c.priceField.display) {
      items.push(block('定价（值级核验）', priceFieldHTML(c), 'price'));
    } else if (c.priceBand || (c.pricePoints && c.pricePoints.length)) {
      let s = '';
      if (c.priceBand) s += `<span class="tag">${lbl('priceBands', c.priceBand.band)}</span> ${esc(c.priceBand.range || '')}${c.priceBand.basis === 'inferred' ? ' <span class="tag inferred">推算</span>' : ''}${srcTags(c, 'priceBand')}`;
      if (c.pricePoints && c.pricePoints.length) {
        const sym = curSym(c.currency);
        s += ` <span class="muted">价位点：${sym}${c.pricePoints.slice(0, 12).join(' / ' + sym)}${c.pricePoints.length > 12 ? ' …' : ''}${c.priceVerified ? '（官网实抓）' : ''}</span>`;
      }
      s += curNote(c) + ' <span class="tag inferred">旧版·重研后启用值级核验</span>';
      items.push(block('定价', s, 'price'));
    }
    return items;
  },
  positioning(c) {
    const items = [];
    // ▶ P2 #8 定位战略：结构化渲染 + 两级视觉（品牌自称 / 官网实测）
    const pos = (typeof c.positioning === 'object' && c.positioning) ? c.positioning : (c.positioning ? { valueProposition: c.positioning } : null);
    if (pos && (pos.valueProposition || pos.targetAudience || pos.pricePosition || pos.differentiation)) {
      const basisTag = c.positioningBasis === 'verified'
        ? '<span class="tag basis-verified">官网实测</span>'
        : '<span class="tag basis-claimed">品牌自称</span>';
      const rows = [];
      if (pos.valueProposition) rows.push(`<div class="pos-row"><span class="pos-k">价值主张</span><span class="pos-v">${esc(pos.valueProposition)}</span></div>`);
      if (pos.targetAudience) rows.push(`<div class="pos-row"><span class="pos-k">目标人群</span><span class="pos-v">${esc(pos.targetAudience)}</span></div>`);
      if (pos.pricePosition) rows.push(`<div class="pos-row"><span class="pos-k">价格定位</span><span class="pos-v">${esc(pos.pricePosition)}</span></div>`);
      if (pos.differentiation) rows.push(`<div class="pos-row"><span class="pos-k">差异化卖点</span><span class="pos-v">${esc(pos.differentiation)}</span></div>`);
      items.push(block('定位战略 ' + basisTag, rows.join(''), 'positioning'));
    }
    if ((c.sellingPoints || []).length) items.push(block('主打卖点', c.sellingPoints.map(x => `<span class="tag">${SP_ZH[x] || prettyKey(x)}</span>`).join(''), 'sellingPoints'));
    if (c.customization && typeof c.customization.score === 'number') {
      let s = `<b>${c.customization.score}</b>/100${c.customization.basis === 'inferred' ? ' <span class="tag inferred">推算</span>' : ''}${c.customization.note ? ' <span class="muted">' + esc(c.customization.note) + '</span>' : ''}${srcTags(c, 'customization')}`;
      items.push(block('定制化程度（象限图 Y 轴）', s, 'customization'));
    }
    return items;
  },
  products(c) {
    const items = [];
    // ▶ P2 #4 产品矩阵（纵向深度）：优先结构化 productMatrix；缺失回退 legacy products 扁平词
    const pm = c.productMatrix;
    if (pm && (pm.skuCount || pm.priceBandDist || (pm.heroSku || []).length || (pm.productLines || []).length)) {
      const parts = [];
      if (pm.skuCount) parts.push(`<div class="pm-stat"><b>${pm.skuCount}</b><span>SKU 数(估)</span></div>`);
      if (pm.priceBandDist) parts.push(`<div class="pm-stat wide"><b>${esc(pm.priceBandDist)}</b><span>价格带分布</span></div>`);
      let inner = parts.length ? `<div class="pm-stats">${parts.join('')}</div>` : '';
      if ((pm.heroSku || []).length) inner += `<div class="pm-sub"><span class="pm-sub-k">爆款/主打</span>${pm.heroSku.map(x => `<span class="tag">${esc(x)}</span>`).join('')}</div>`;
      if ((pm.productLines || []).length) inner += `<div class="pm-sub"><span class="pm-sub-k">产品线</span>${pm.productLines.map(x => `<span class="tag soft">${esc(x)}</span>`).join('')}</div>`;
      items.push(block('产品矩阵（纵向深度）', inner, 'products'));
    } else if ((c.products || []).length) {
      items.push(block('产品矩阵', c.products.map(p => `<span class="tag soft">${esc(p)}</span>`).join(''), 'products'));
    }
    // ▶ P2 #5 品类布局（横向广度）：优先结构化 categoryCoverage（与矩阵数据源严格分离）；缺失回退 legacy categories
    if ((c.categoryCoverage || []).length) {
      const inner = c.categoryCoverage.map(x => `<div class="cov-row"><span class="cov-cat">${esc(x.category)}</span>${x.subCategory ? `<span class="cov-sub">› ${esc(x.subCategory)}</span>` : ''}${x.count != null ? `<span class="cov-n">≈${x.count} SKU</span>` : ''}</div>`).join('');
      items.push(block('品类布局（横向广度）', inner, 'categories'));
    } else if ((c.categories || []).length && String(c.categories.map(String).sort()) !== String((c.products || []).map(String).sort())) {
      // #311：legacy 兜底 c.categories 若与产品矩阵(c.products)同源相同，跳过——避免重复渲染
      items.push(block('品类布局', c.categories.map(k => `<span class="tag soft">${esc(prettyKey(k))}</span>`).join(''), 'categories'));
    }
    if ((c.audiences || []).length) items.push(block('目标人群', c.audiences.map(a => `<span class="tag">${esc(prettyKey(a))}</span>`).join(''), 'audiences'));
    return items;
  },
  channels(c) {
    const items = [];
    const keys = Object.keys(LABELS.channels);
    const rows = keys.map(k => `<div class="ch-row"><span class="ch-name">${lbl('channels', k)}</span><span class="ch-det">${channelFieldHTML(c, k)}</span></div>`).join('');
    if (rows) items.push(block('渠道版图（逐渠道核验）', `<div class="ch-grid">${rows}</div>`, 'channels'));
    if ((c.regions || []).length) items.push(block('覆盖地域', c.regions.map(r => `<span class="tag">${lbl('regions', r)}</span>`).join(''), 'regions'));
    return items;
  },
  reviews(c) {
    const items = [];
    const rf = c.reviewField;
    if (rf) {
      // 评分（标量）
      const r = rf.rating;
      let rs = `<span class="scalar-val">${r.value != null ? esc(String(r.value)) : '—'}</span>` + confBadge(r);
      rs += srcTagsFromSources(r.sources);
      items.push(block('口碑评分（值级核验）', rs, 'reviews'));
      // 趋势（标量）
      const t = rf.trend;
      const tlabel = t.value === 'up' ? '↑上升' : t.value === 'down' ? '↓下滑' : t.value === 'stable' ? '→平稳' : '—';
      let ts = `<span class="scalar-val">${tlabel}</span>` + confBadge(t);
      ts += srcTagsFromSources(t.sources);
      items.push(block('口碑趋势（值级核验）', ts, 'reviews'));
      // 负面主题（逐条核验）
      if (rf.negThemes && rf.negThemes.items && rf.negThemes.items.length) {
        const ns = rf.negThemes.items.map(i => themeChip(c, i, 'negThemes')).join('');
        items.push(block('负面主题（逐条核验）', `<div class="theme-grid">${ns}</div>`, 'reviews'));
      }
      // 正面主题（逐条核验）
      if (rf.posThemes && rf.posThemes.items && rf.posThemes.items.length) {
        const ps = rf.posThemes.items.map(i => themeChip(c, i, 'posThemes')).join('');
        items.push(block('正面主题（逐条核验）', `<div class="theme-grid">${ps}</div>`, 'reviews'));
      }
    } else if (c.reviews) {
      // 兼容未装饰 reviewField 的旧数据
      const rv = c.reviews; let s = '';
      if (rv.rating != null) s += `评分 <b>${rv.rating}</b>`;
      if (rv.trend) s += ` <span class="trend ${rv.trend}">${rv.trend === 'up' ? '↑上升' : rv.trend === 'down' ? '↓下滑' : '→平稳'}</span>`;
      if ((rv.posThemes || []).length) s += ` <span class="muted">好评：${rv.posThemes.join('、')}</span>`;
      if ((rv.negThemes || []).length) s += ` <span class="warn">差评：${rv.negThemes.join('、')}</span>`;
      s += rv.basis === 'inferred' ? ' <span class="tag inferred">推算</span>' : '';
      s += srcTags(c, 'reviews');
      items.push(block('口碑走势', s, 'reviews'));
    }
    // ▶ F6：横向痛点卡（未解决=机会 / 自述与口碑矛盾）
    {
      const painCards = [];
      (c.painPoints || []).forEach((p, i) => {
        const basis = p.basis || 'inferred';
        painCards.push(`<div class="pain">
          <div class="n">${esc(p.point)}</div>
          <div class="c">${basis === 'verified' ? '已核实' : '推测'}</div>
          <span class="flag opp">未解决 = 机会</span>
          ${srcTags(c, 'painPoints.' + i) ? `<div class="pain-src">${srcTags(c, 'painPoints.' + i)}</div>` : ''}
        </div>`);
      });
      const nts = (c.reviewField && c.reviewField.negThemes && c.reviewField.negThemes.items) || [];
      nts.forEach(i => {
        if (i.state === 'conflict') {
          painCards.push(`<div class="pain">
            <div class="n">${esc(i.text)}</div>
            <div class="c">矛盾</div>
            <span class="flag warn">自述与口碑矛盾</span>
          </div>`);
        }
      });
      if (painCards.length) items.push(block('用户抱怨点（横向痛点卡）', `<div class="pain-cards">${painCards.join('')}</div>`, 'painPoints'));
    }
    // ▶ P1 #7：用户原声 snippets（每条带 url，可点开原始链接；评分带样本量；无 url 已在后端剔除）
    if (c.reviewSnippets && c.reviewSnippets.length) {
      const sn = c.reviewSnippets.map(s => {
        const sentCls = s.sentiment === 'pos' ? 'pos' : s.sentiment === 'neg' ? 'neg' : 'neu';
        const sentIco = s.sentiment === 'pos' ? '👍' : s.sentiment === 'neg' ? '👎' : '➖';
        const rate = s.rating != null ? `<span class="snip-rate">${esc(String(s.rating))}★</span>` : '';
        const sz = s.sampleSize != null ? `<span class="snip-size">样本 ${s.sampleSize}</span>` : '';
        return `<li class="snip ${sentCls}">${sentIco} <span class="snip-text">${esc(s.text)}</span> ${rate}${sz} <a class="snip-link" href="${escAttr(s.url)}" target="_blank" rel="noopener">${esc(s.platform || '来源')} ↗</a></li>`;
      }).join('');
      items.push(block('用户原声（可溯源）', `<ul class="snip-list">${sn}</ul>`, 'reviews'));
    }
    return items;
  },
  marketing(c) {
    const items = [];
    if (c.launchCadence && c.launchCadence.value) {
      items.push(block('上新节奏（值级核验）', scalarFieldHTML(c, 'launchCadence', '上新节奏'), 'launchCadence'));
    }
    if ((c.tactics || []).length) items.push(block('销售打法', c.tactics.map(x => `<span class="tag soft">${TC_ZH[x] || x}</span>`).join(''), 'tactics'));
    if ((c.contentForms || []).length) items.push(block('内容形态', c.contentForms.map(x => `<span class="tag soft">${lbl('contentForms', x)}</span>`).join(''), 'contentForms'));
    if ((c.collabTypes || []).length) items.push(block('联名方式', c.collabTypes.map(x => `<span class="tag soft">${lbl('collabTypes', x)}</span>`).join(''), 'collabTypes'));
    if ((c.fulfillment || []).length) items.push(block('履约方式', c.fulfillment.map(x => `<span class="tag soft">${lbl('fulfillment', x)}</span>`).join(''), 'fulfillment'));
    if (c.estSize) items.push(block('估算规模', esc(c.estSize) + (c.estSizeBasis === 'inferred' ? ' <span class="tag inferred">推算</span>' : ''), 'estSize'));
    if (c.techStack) items.push(block('技术栈', esc(c.techStack), 'techStack'));
    if ((c.recentMoves || []).length) {
      const m = c.recentMoves.map(x => `<li><span class="mv-type">${esc(x.type)}</span> ${esc(x.desc)} ${x.when ? `<span class="muted">· ${esc(x.when)}</span>` : ''}${x.basis === 'inferred' ? ' <span class="tag inferred">推算</span>' : ''}</li>`).join('');
      items.push(block('近期动作', `<ul class="moves">${m}</ul>`));
    }
    if ((c.inferred || []).length) items.push(block('推算项（无直接来源·基于信号推断）', c.inferred.map(x => `<span class="tag inferred">${esc(x)}</span>`).join('')));
    return items;
  },
};
// 组装六大类分区（固定顺序 + 智能折叠 + 三态空字段）
function l1Conclusion(catKey, c) {
  // 仅从已采集字段派生一句话结论；无实质数据时返回 ''（忠实助理：绝不编造）
  switch (catKey) {
    case 'pricing':
      if (c.priceBand && c.priceBand.range) return '价格带 ' + c.priceBand.range;
      if (c.priceField && c.priceField.display) return '标价 ' + c.priceField.display;
      if (c.pricePoints && c.pricePoints.length) return c.pricePoints.length + ' 个价位点（' + curSym(c.currency) + Math.min.apply(null, c.pricePoints) + ' 起）';
      return '';
    case 'positioning': {
      const pos = (typeof c.positioning === 'object' && c.positioning) ? c.positioning : null;
      const parts = [];
      if (pos && pos.valueProposition) parts.push(pos.valueProposition);
      if (c.sellingPoints && c.sellingPoints.length) parts.push('主打 ' + c.sellingPoints.length + ' 个卖点');
      if (c.customization && typeof c.customization.score === 'number') parts.push('定制化 ' + c.customization.score + '/100');
      return parts.slice(0, 2).join(' · ');
    }
    case 'products': {
      const pm = c.productMatrix; const parts = [];
      if (pm && pm.skuCount) parts.push('约 ' + pm.skuCount + ' SKU');
      if (c.categoryCoverage && c.categoryCoverage.length) parts.push('覆盖 ' + c.categoryCoverage.length + ' 品类');
      if (c.audiences && c.audiences.length) parts.push('面向 ' + c.audiences.length + ' 类人群');
      else if (c.products && c.products.length) parts.push(c.products.length + ' 项产品');
      return parts.slice(0, 2).join(' · ');
    }
    case 'channels': {
      const ch = c.channels || {};
      const present = Object.keys(ch).filter(k => ch[k] && ch[k].present);
      const parts = [];
      if (present.length) parts.push('布局 ' + present.length + ' 渠道（' + present.slice(0, 3).map(k => lbl('channels', k)).join('、') + '）');
      if (c.regions && c.regions.length) parts.push('覆盖 ' + c.regions.length + ' 地区');
      return parts.slice(0, 2).join(' · ');
    }
    case 'reviews': {
      const rf = c.reviewField;
      const r = (rf && rf.rating) || (c.reviews && c.reviews.rating) || null;
      const rv = r ? (r.value != null ? r.value : r.rating) : null;
      const trend = rf && rf.trend ? rf.trend.value : null;
      const neg = ((rf && rf.negThemes && rf.negThemes.items) ? rf.negThemes.items.length : 0) + ((c.painPoints || []).length);
      const parts = [];
      if (rv != null) parts.push('评分 ' + rv);
      if (trend === 'up') parts.push('口碑上升');
      else if (trend === 'down') parts.push('口碑下滑');
      else if (trend === 'stable') parts.push('口碑平稳');
      if (neg) parts.push(neg + ' 个抱怨点');
      return parts.slice(0, 3).join(' · ');
    }
    case 'marketing': {
      const n = a => Array.isArray(a) ? a.length : 0; const parts = [];
      if (n(c.tactics)) parts.push(n(c.tactics) + ' 种打法');
      if (n(c.contentForms)) parts.push(n(c.contentForms) + ' 类内容');
      if (n(c.collabTypes)) parts.push(n(c.collabTypes) + ' 种联名');
      if (n(c.recentMoves)) parts.push(n(c.recentMoves) + ' 个近期动作');
      return parts.slice(0, 3).join(' · ');
    }
    default: return '';
  }
}

function renderL1(c, prof) {
  let h = '';
  L1_ORDER.forEach(catKey => {
    const meta = L1_META[catKey];
    const items = L1_ITEMS[catKey](c);
    const empties = (L1_EMPTY_FIELDS[catKey] || []).filter(f => attemptState(c, f.fieldKey).state !== 'has').map(f => f);
    if (!items.length && !empties.length) return; // 该大类无任何内容（含三态）→ 不渲染
    const key = c.id + ':' + catKey;
    const open = l1Expanded.has(key) ? l1Expanded.get(key) : l1ShouldExpand(catKey, c, prof);
    const n = items.length + empties.length;
    const concl = l1Conclusion(catKey, c);
    h += `<section class="l1-cat" data-cat="${catKey}">
      <div class="l1-head" data-l1toggle="${escAttr(key)}">
        <span class="l1-title">${meta.title}</span>
        ${concl ? `<span class="l1-concl">${esc(concl)}</span>` : ''}
        <span class="l1-count">内含 ${n} 项</span>
        ${empties.length ? `<button class="l1-deep" data-l2mod="${escAttr(catKey)}" data-cid="${escAttr(c.id)}">补这块数据</button>` : ''}
        <span class="caret">${open ? '▾' : '▸'}</span>
      </div>
      <div class="l1-body" ${open ? '' : 'style="display:none"'}>
        ${items.join('')}
        ${empties.map(f => renderEmptyField(c, f.fieldKey, f.label)).join('')}
      </div>
    </section>`;
  });
  return h;
}
// 字段 key → 中文标签（用于深挖 toast）
function l1FieldLabel(fk) {
  for (const cat of Object.keys(L1_EMPTY_FIELDS)) {
    const e = L1_EMPTY_FIELDS[cat].find(x => x.fieldKey === fk);
    if (e) return e.label;
  }
  return fk;
}
// L2 深挖：单字段或单模块（field 可为字段 key 或模块 key）
async function triggerL2Field(cid, fieldKey) {
  const btn = document.querySelector(`[data-l2field="${cssEsc(fieldKey)}"][data-cid="${cssEsc(cid)}"]`);
  const label = l1FieldLabel(fieldKey);
  if (btn) { btn.disabled = true; btn.textContent = '深挖中…'; }
  try {
    const r = await api('/api/deepdive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ competitorId: cid, field: fieldKey, level: 'field' }) });
    if (r && r.state) {
      state = r.state;
      renderAll();
      const okN = (r.results || []).filter(x => x.ok).length;
      toast(`「${label}」已补查（命中 ${okN} 项，来源可点开核验）。`);
    } else {
      toast(`「${label}」暂未挖到有效信息。`);
      if (btn) { btn.disabled = false; btn.textContent = '还没查 · 点此补查'; }
    }
  } catch (e) {
    toast('深挖失败：' + (e.message || e));
    if (btn) { btn.disabled = false; btn.textContent = '还没查 · 点此补查'; }
  }
}
async function triggerL2Module(cid, catKey) {
  const btn = document.querySelector(`[data-l2mod="${cssEsc(catKey)}"][data-cid="${cssEsc(cid)}"]`);
  const label = (L1_META[catKey] && L1_META[catKey].title) || catKey;
  if (btn) { btn.disabled = true; btn.textContent = '补查中…'; }
  try {
    const r = await api('/api/deepdive', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ competitorId: cid, field: catKey, level: 'module' }) });
    if (r && r.state) {
      state = r.state;
      renderAll();
      const okN = (r.results || []).filter(x => x.ok).length;
      toast(`「${label}」这块数据补查完成（命中 ${okN} 项，来源可点开核验）。`);
    } else {
      toast(`「${label}」暂未挖到有效信息。`);
      if (btn) { btn.disabled = false; btn.textContent = '补这块数据'; }
    }
  } catch (e) {
    toast('补查失败：' + (e.message || e));
    if (btn) { btn.disabled = false; btn.textContent = '补这块数据'; }
  }
}
function cssEsc(s) { return String(s).replace(/"/g, '\\"'); }

// ---------- 横向对比（#54）：点字段名 → 全品牌对比表 ----------
function openCompare(fieldKey) {
  const modal = $('#compareModal');
  modal.classList.remove('hidden');
  $('#compareTitle').textContent = '横向对比 · 加载中…';
  $('#compareBody').innerHTML = '<p class="hint">正在汇总全品牌数据…</p>';
  api('/api/compare', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ field: fieldKey }) })
    .then(r => {
      if (!r || r.error) { $('#compareBody').innerHTML = `<p class="hint">无法对比：${esc(r ? r.error : '无响应')}</p>`; return; }
      $('#compareTitle').textContent = '横向对比 · ' + (r.label || fieldKey);
      $('#compareBody').innerHTML = renderCompare(r);
    })
    .catch(e => { $('#compareBody').innerHTML = `<p class="hint">对比失败：${esc(e.message || e)}</p>`; });
}
// 受控词 key → 中文标签（与全局 LABELS / SP_ZH / TC_ZH 一致）
function mapCmpTag(field, t) {
  switch (field) {
    case 'sellingPoints': return SP_ZH[t] || prettyKey(t);
    case 'tactics': return TC_ZH[t] || t;
    case 'audiences': return lbl('audiences', t);
    case 'regions': return lbl('regions', t);
    case 'contentForms': return lbl('contentForms', t);
    case 'collabTypes': return lbl('collabTypes', t);
    case 'fulfillment': return lbl('fulfillment', t);
    default: return t;
  }
}
function renderCompare(r) {
  let h = '';
  if (r.note) h += `<p class="cmp-note">${esc(r.note)}</p>`;
  const exN = (state.excluded || []).length;
  if (exN) h += `<p class="cmp-note muted">已从对比中移除 ${exN} 家（在闸门侧栏可拉回）。</p>`;
  if (!r.rows || !r.rows.length) { h += '<p class="hint">暂无可对比的对手（需至少 1 家已完成识别）。</p>'; return h; }
  if (r.kind === 'matrix') {
    h += '<div class="cmp-scroll"><table class="cmp-table"><thead><tr><th class="cmp-rowhead">品牌</th>';
    r.columns.forEach(col => h += `<th>${esc(lbl('channels', col.key))}</th>`);
    h += '</tr></thead><tbody>';
    r.rows.forEach(row => {
      h += `<tr><td class="cmp-rowhead">${esc(row.name)}<span class="cmp-tier">${TIER_LABEL[row.tier] || ''}</span></td>`;
      r.columns.forEach(col => {
        const cell = row.cells[col.key] || {};
        let mark = '—', cls = 'unprobed', sub = '';
        if (cell.state === 'present') { mark = '✓' + (cell.note ? ' ' + esc(cell.note) : ''); cls = 'present'; }
        else if (cell.state === 'absent-verified') { mark = '✗ 确认未入驻'; cls = 'absent-v'; }
        else if (cell.state === 'absent') { mark = '✗ 暂未发现'; cls = 'absent-u'; }
        if (cell.basis === 'inferred') sub = `<span class="cmp-basis inferred">推算</span>`;
        h += `<td class="cmp-cell ${cls}">${mark}${sub}</td>`;
      });
      h += '</tr>';
    });
    h += '</tbody></table></div>';
  } else {
    h += '<div class="cmp-scroll"><table class="cmp-table"><thead><tr><th class="cmp-rowhead">品牌</th><th>内容</th><th>来源</th></tr></thead><tbody>';
    r.rows.forEach(row => {
      let val;
      if (r.field === 'reviews') {
        val = `评分 <b>${esc(String(row.rating))}</b>` + (row.trend ? ` <span class="trend ${row.trend}">${row.trend === 'up' ? '↑' : row.trend === 'down' ? '↓' : '→'}</span>` : '');
        if ((row.neg || []).length) val += ` <span class="warn">差评：${row.neg.join('、')}</span>`;
        if ((row.pos || []).length) val += ` <span class="muted">好评：${row.pos.join('、')}</span>`;
      } else if (r.field === 'price') {
        val = esc(row.display) + (row.currency ? ` <span class="tag">${esc(row.currency)}</span>` : '');
        if (row.conflictNote) val += ` <span class="warn">⚠ ${esc(row.conflictNote)}</span>`;
        if (row.realScraped) val += ` <span class="tag">官网实抓</span>`;
      } else if (row.tags && row.tags.length) {
        val = row.tags.map(t => esc(mapCmpTag(r.field, t))).join('、');
      } else {
        val = esc(row.display || '—');
      }
      const conf = row.basis === 'inferred' ? '<span class="tag inferred">推算</span>' : (row.basis === 'conflict' ? '<span class="tag">冲突</span>' : '');
      const src = (row.sources || []).map(s => {
        const ic = s.agrees === true ? '✓' : (s.agrees === false ? '✗' : '🔗');
        return `<a class="src-tag ${s.agrees === false ? 'disagree' : ''}" href="${escAttr(s.url || '#')}" target="_blank" rel="noopener" title="${escAttr(s.text || s.title || '')}">${ic}</a>`;
      }).join(' ');
      h += `<tr><td class="cmp-rowhead">${esc(row.name)}<span class="cmp-tier">${TIER_LABEL[row.tier] || ''}</span></td><td class="cmp-val">${val}</td><td>${src || '—'}</td></tr>`;
    });
    h += '</tbody></table></div>';
  }
  return h;
}
// 全局委托：字段名 / ⇄ 图标 → 打开横向对比；✕ / 遮罩 → 关闭
document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-compare]');
  if (t) { e.stopPropagation(); openCompare(t.dataset.compare); return; }
  if (e.target.closest('[data-close-compare]')) { $('#compareModal').classList.add('hidden'); return; }
  if (e.target === $('#compareModal')) $('#compareModal').classList.add('hidden');
  const fc = e.target.closest('[data-fieldcorrect]');
  if (fc) { e.stopPropagation(); openFieldCorrect(fc.dataset.fieldcorrect, fc.dataset.fcfield); return; }
  if (e.target.closest('[data-close-fc]')) { $('#fieldCorrectModal').classList.add('hidden'); return; }
  if (e.target === $('#fieldCorrectModal')) $('#fieldCorrectModal').classList.add('hidden');
  // 情报库档案页（设计稿 P4）：chips 切换对手 / field-box 折叠 / 备注保存 / 空白补查
  const ipk = e.target.closest('[data-intelpick]');
  if (ipk) { currentIntelId = ipk.dataset.intelpick; renderIntelTab(); return; }
  const fbt = e.target.closest('[data-fbtoggle]');
  if (fbt) { const box = fbt.closest('.field-box'); if (box) box.classList.toggle('open'); return; }
  const ins = e.target.closest('[data-intelnotesave]');
  if (ins) { e.stopPropagation(); saveUserNote(ins.dataset.intelnotesave, ins); return; }
  const l2f = e.target.closest('[data-l2field]');
  if (l2f) { e.stopPropagation(); triggerL2Field(l2f.dataset.cid, l2f.dataset.l2field); return; }
  // P0：工作台材料卡（data-* 委托，替代内联 onclick 传参——esc 不转义引号，属性上下文必须走 data 属性）
  const wbd = e.target.closest('[data-wbdrawer]');
  if (wbd) { e.stopPropagation(); const m = wbMatById(wbd.dataset.wbdrawer); if (m) openWbDrawer(m.id); return; }
  const wbs = e.target.closest('[data-wbset]');
  if (wbs) { e.stopPropagation(); wbSet(wbs.dataset.wbset, wbs.dataset.act || ''); return; }
  const fcr = e.target.closest('[data-fbcorrect]');
  if (fcr) { e.stopPropagation(); openFieldCorrect(fcr.dataset.fbcorrect, fcr.dataset.fcfield || 'price'); return; }
  const om = e.target.closest('[data-openmodal]');
  if (om) { e.stopPropagation(); const m0 = document.getElementById(om.dataset.openmodal); if (m0) m0.classList.remove('hidden'); return; }
  // P2-2：雷达页「补录对手」引导/页头按钮 → 弹输入框补录（闸门内联输入已移除）
  const raf = e.target.closest('[data-radaraddfocus]');
  if (raf) {
    const nm = window.prompt('输入要补录的对手品牌名（可附官网 URL）：');
    if (nm && nm.trim()) gateAddCompetitor(nm.trim());
    return;
  }
});

function block(title, inner, cmp) {
  const t = cmp
    ? `<div class="field-t"><span class="field-name" data-compare="${escAttr(cmp)}" title="点此看全品牌横向对比">${title}</span><span class="cmp-ico" data-compare="${escAttr(cmp)}" title="全品牌横向对比">⇄</span></div>`
    : `<div class="field-t">${title}</div>`;
  return `<div class="field">${t}<div class="field-v">${inner}</div></div>`;
}

// ---------- 时间线深度检索 ----------
async function fetchTimeline(id, btn) {
  const old = btn.textContent;
  btn.disabled = true; btn.textContent = '检索中…';
  try {
    const s = await api('/api/timeline', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ competitorId: id }) });
    timelineCache.set(id, s);
    const node = document.getElementById('tl-' + id);
    if (node) node.innerHTML = renderTimeline(s);
    btn.textContent = '重新检索时间线';
  } catch (e) {
    toast('时间线检索失败：' + (e.message || e));
    btn.textContent = old;
  } finally { btn.disabled = false; }
}

function renderTimeline(tl) {
  if (!tl || !tl.events || !tl.events.length) return '<p class="hint">暂无时间线信息。</p>';
  let h = '';
  if (tl.summary) h += `<p class="tl-summary">${esc(tl.summary)}</p>`;
  h += '<div class="timeline">';
  tl.events.forEach(ev => {
    const lvl = ev.level === 'strategy' ? 'strategy' : 'tactic';
    h += `<div class="tl-item level-${lvl}">
      <div class="tl-dot"></div>
      <div class="tl-content">
        <div class="tl-meta"><span class="tl-period">${esc(ev.period || '')}</span><span class="tl-level ${lvl}">${lvl === 'strategy' ? '战略' : '战术'}</span></div>
        <div class="tl-title">${esc(ev.title || '')}</div>
        <div class="tl-desc">${esc(ev.desc || '')}</div>
        ${ev.evidence ? `<div class="tl-ev muted">依据：${esc(ev.evidence)}</div>` : ''}
      </div>
    </div>`;
  });
  h += '</div>';
  if (tl.shifts) h += `<p class="tl-shifts"><b>关键转折：</b>${esc(tl.shifts)}</p>`;
  return h;
}

// ---------- 空白视图：来源溯源 + 方法论标注辅助 ----------
function gapMethodLabel(g) {
  // 旧缓存兼容：无 method 字段时按 (type+evidence) 回退（与 server GAP_METHOD 同义）
  const M = {
    'executionWeak': '执行弱探测（在售但被评执行弱）',
    'absence:verified-neg': '已验证缺失（多家确证未入驻）',
    'absence:partial-verified': '部分验证缺失（部分确证、部分暂未发现）',
    'absence:undetected': '暂未发现（仅未查到，非确认不做）',
    'absence:neg': '地域缺席（无对手覆盖该市场）',
    'priceGap:scraped-prices': '价位阶梯空档（≥2家实抓价佐证）',
    'priceGap:stated-prices': '价位阶梯空档（陈述价佐证）',
    'priceGap:undetected': '价格数据不足（<3家同币种）',
    'claimGap:matrix': '卖点矩阵空缺（品牌×卖点无人认领）',
    'tacticGap:matrix': '策略矩阵空缺（品牌×打法无人使用）',
    'demandGap:reviews': '口碑痛点推测（被抱怨但无人解决）',
    'adjacency:struct': '邻接结构推理（相邻品类通用打法，无对手采用）'
  };
  return M[(g.type || '') + ':' + (g.evidence || '')] || M[g.type] || '结构推理';
}
function gapSourceTags(sources) {
  if (!sources || !sources.length) return '';
  const shown = sources.slice(0, 4);
  const extra = sources.length - shown.length;
  const chips = shown.map(s => {
    const nm = s.name ? esc(s.name) : '—';
    const dt = s.detail ? esc(s.detail) : '';
    const bcls = s.basis === 'verified' ? 'verified' : s.basis === 'inferred' ? 'inferred' : 'unverified';
    return `<span class="src-chip ${bcls}">${nm}${dt ? ' · ' + dt : ''}</span>`;
  }).join('');
  const more = extra > 0 ? `<span class="src-more">等${sources.length}家</span>` : '';
  return `<div class="ws-sources"><span class="muted">溯源：</span>${chips}${more}</div>`;
}

// ▶ 跨币种提示：后端 state.crossCurrency 已不再在前端渲染 banner——忠实助理不靠"我们提醒了你"来换取信任；
// 价格按原币种展示、跨币种不换算的纪律仍由采集层（detectCurrency + $0 过滤）保证，结论里每条带来源。

// ---------- 空白视图 ----------
function renderWhiteSpace() {
  const wrap = $('#whitespaceContainer');
  const ws = state.whiteSpace;
  if (!ws || ws.hidden) {
    const total = (ws && ws.total) || 0;
    wrap.innerHTML = `<div class="ws-empty">
      <h3>空白视图需要更多对手</h3>
      <p>当前已识别 <b>${total}</b> / 3 家。空白分析要求至少 3 家真实对手才能计算群体空缺，请先补充赛道或等待 AI 补全。</p>
    </div>`;
    return;
  }
  // ▶ #10 冷启动单家空白：单家观察模式（样本<3）单独渲染，明确非群体共识
  if (ws.singleMode) { renderWhiteSpaceSingle(ws); return; }
  // ▶ 空白视图整改 · 规范 C·双保险：低覆盖（coverageInsufficient）且群体（isGroup）的 gap 即便后端漏标，
  // 前端也绝不计入「可行动空白」计数与渲染，并并入 und 区（不依赖后端正确性）。
  const opp = ws.gaps.filter(g => g.level === 'opportunity' && !(g.coverageInsufficient && g.isGroup));
  const und = ws.gaps.filter(g => g.level === 'undetected' || (g.coverageInsufficient && g.isGroup));
  // 维度值的中文映射（渠道等英文 key 转标签）
  const DIM_GROUP = { '渠道': 'channels', '联名': 'collabTypes', '内容': 'contentForms', '地域': 'regions', '履约': 'fulfillment' };
  const valLbl = g => DIM_GROUP[g.dim] ? lbl(DIM_GROUP[g.dim], g.value) : g.value;
  const pendingCount = (state.competitors || []).reduce((n, c) => n + ((c.pendingCorrections || []).length), 0);
  let html = `<div class="ws-head"><h3>空白视图 · 对手没占的地方</h3><p>共识别 <b>${opp.length}</b> 个可行动空白；另有 ${und.length} 个尚未查实（仅作提示）。覆盖率 ${ws.coverage}%。</p>${pendingCount ? `<p class="ws-pending">⏳ 你有 <b>${pendingCount}</b> 条纠错待复核，复核通过后才会改写数据（不直接标"已核实"）。</p>` : ''}</div>`;
  html += `<div class="ws-feedback"><a class="muted-link" id="wsFeedbackLink" href="javascript:void(0)">空白判断有偏差？反馈给我们校准 →</a></div>`;

  // #55 定位校准面板：以用户填写的价格段/卖点为原点，呈现"你选的方向 vs 对手已占/空白"
  html += renderPositioningBlock(ws.positioning);
  // P4 空白地图：象限高亮无对手占据的格子（视觉提示结构性空位）
  html += renderWhiteSpaceMapSection(ws, state.competitors || []);
  // ③ 蓝海要素曲线：一维，表达全行业趋同处 vs 无人区
  html += renderBlueOceanSection(state.blueOcean, state.competitors || []);
  // PRD 四类空缺优先展示，其余维度归入"其他结构空位"
  const PRD_ORDER = ['价位空缺', '市场机会', '卖点空缺', '策略空缺'];
  const PRD_DESC = {
    '价位空缺': '全赛道定价聚类后的无人价格带（证据=各家实际标价）',
    '市场机会': '被用户抱怨但无人宣称解决的点（推测）',
    '卖点空缺': '卖点×品牌矩阵中无人认领的列',
    '策略空缺': '销售打法矩阵中无人使用的打法'
  };
  const grouped = {};
  opp.forEach(g => { (grouped[g.dim] = grouped[g.dim] || []).push(g); });
  const renderItems = list => list.map(g => `<div class="ws-item ${g.coverageInsufficient ? 'cov-insuf' : ''}" data-gid="${escAttr(g.gid || '')}" data-itemtype="gap">
      <div class="ws-body">
        <div class="ws-title"><span class="gid">${esc(g.gid || '')}</span> ${esc(valLbl(g))} <span class="ws-type">· ${lbl('gapType', g.type)}</span>${g.speculative ? ' <span class="tag inferred">推测</span>' : ''}${g.coverageInsufficient ? ' <span class="tag warn">覆盖率不足</span>' : ''}</div>
        <div class="ws-note">${esc(g.note || '')}</div>
        <div class="ws-method"><span class="muted">推理：</span>${esc(g.method || gapMethodLabel(g))}</div>
        ${gapSourceTags(g.sources)}
        ${g.disclaimer ? `<div class="ws-disclaimer">⚠️ ${esc(g.disclaimer)}</div>` : ''}
      </div>
    </div>`).join('');
  PRD_ORDER.forEach(dim => {
    const list = grouped[dim];
    html += `<div class="ws-section"><h4>${dim}</h4><p class="ws-desc">${PRD_DESC[dim]}</p>`;
    if (list && list.length) html += `<div class="ws-list">${renderItems(list)}</div>`;
    else html += `<p class="hint">本轮未发现该类空缺${dim === '价位空缺' ? '（或价格数据不足）' : ''}——各家均有布局，或数据尚在采集。</p>`;
    html += `</div>`;
    delete grouped[dim];
  });
  const rest = Object.keys(grouped).flatMap(k => grouped[k]);
  if (rest.length) {
    html += `<div class="ws-section"><h4>其他结构空位（渠道/联名/内容/地域/履约）</h4><div class="ws-list">${renderItems(rest)}</div></div>`;
  }
  if (und.length) {
    html += `<div class="ws-und"><h4>尚未查实区域（仅供参考，非行动建议）</h4>`;
    und.forEach(g => { html += `<div class="ws-item und ${g.coverageInsufficient ? 'cov-insuf' : ''}" data-gid="${escAttr(g.gid || '')}" data-itemtype="gap"><div class="ws-body"><div class="ws-title">${esc(valLbl(g))}${g.coverageInsufficient ? ' <span class="tag warn">覆盖率不足</span>' : ''}</div><div class="ws-note">${esc(g.note || '')}</div>${gapSourceTags(g.sources)}${g.disclaimer ? `<div class="ws-disclaimer">⚠️ ${esc(g.disclaimer)}</div>` : ''}</div></div>`; });
    html += `</div>`;
  }
  wrap.innerHTML = html;
  const fl = document.getElementById('wsFeedbackLink');
  if (fl) fl.onclick = () => openReportWithGap('whitespace-overall', '空白视图整体');
  $$('.bo-chip').forEach(ch => { ch.onclick = () => { blueOceanDim = ch.dataset.dim; renderWhiteSpace(); }; });
  initConsumeTracking();
}

// ▶ #10：定位校准面板抽成复用函数（群体模式与单家观察模式共用），避免两份漂移
function renderPositioningBlock(pos) {
  if (pos && pos.hasProfile) {
    let cp = `<div class="ws-calib"><h4>定位校准 · 以你填的价格段 / 卖点为锚点</h4>`;
    if (pos.price) {
      const p = pos.price;
      cp += `<div class="ws-calib-row"><b>价格段</b> ${esc(p.band.currency)} ${p.band.min}–${p.band.max} · 被 <b>${p.contestedBy}</b> 家同币种对手占据${p.contestedNames.length ? `（${p.contestedNames.map(esc).join('、')}）` : ''}</div>`;
    }
    if (pos.sellingPoints) {
      cp += '<div class="ws-calib-row"><b>卖点</b> ' + pos.sellingPoints.map(r => {
        const cls = r.claimedBy === 0 ? 'open' : r.claimedBy >= 3 ? 'crowded' : 'mid';
        const txt = r.claimedBy === 0 ? '空白可占' : `${r.claimedBy}家在做`;
        return `<span class="sp-chip ${cls}">${esc(r.label)} · ${txt}</span>`;
      }).join('') + '</div>';
    }
    if (pos.challenges && pos.challenges.length) {
      cp += '<div class="ws-challenge"><b>值得正视的信号</b>' + pos.challenges.map(c => `<div class="ws-ch">${esc(c.text)}</div>`).join('') + '</div>';
    }
    cp += '</div>';
    return cp;
  }
  return `<div class="ws-calib muted"><span class="hint">未填写你的定位（价格段/卖点）。当前空白视图以全赛道为参照；在左侧填写后可切换为「以你为锚点」的空白与红海分析。</span></div>`;
}

// ▶ #10：单家观察模式渲染（样本<3）——结构推理"应做而未做"的留白，明确非群体共识、低置信
function renderWhiteSpaceSingle(ws) {
  const wrap = $('#whitespaceContainer');
  const gaps = ws.gaps || [];
  const pendingCount = (state.competitors || []).reduce((n, c) => n + ((c.pendingCorrections || []).length), 0);
  let html = `<div class="ws-head"><h3>空白视图 · 单家观察（冷启动）</h3>
    <p>当前已研究 <b>${ws.total}</b> 家对手（&lt;3）。空白分析要求 ≥3 家才能给出<strong>群体共识</strong>级空白；现按结构推理给出<strong>单家观察</strong>——这些是该对手"应做而未做"的留白，属低置信推测、<strong>非群体共识</strong>。补充对手至 ≥3 家即可解锁赛道级群体空白。</p>
    ${pendingCount ? `<p class="ws-pending">⏳ 你有 <b>${pendingCount}</b> 条纠错待复核，复核通过后才会改写数据。</p>` : ''}</div>`;
  html += renderPositioningBlock(ws.positioning);
  if (gaps.length) {
    html += `<div class="ws-section"><h4>单家观察留白（结构推理 · 推测 · 非群体共识）</h4><div class="ws-list">`;
    html += gaps.map(g => `<div class="ws-item single" data-gid="${escAttr(g.gid || '')}" data-itemtype="gap">
      <div class="ws-body">
        <div class="ws-title"><span class="gid">${esc(g.gid || '')}</span> ${esc(g.value)} <span class="ws-type">· ${esc(g.dim)}</span> <span class="tag inferred">单家观察·推测</span></div>
        <div class="ws-note">${esc(g.note || '')}</div>
        <div class="ws-method"><span class="muted">推理：</span>${esc(g.method || '')}</div>
        ${gapSourceTags(g.sources)}
        ${g.disclaimer ? `<div class="ws-disclaimer">⚠️ ${esc(g.disclaimer)}</div>` : ''}
      </div></div>`).join('');
    html += `</div></div>`;
  } else {
    html += `<div class="ws-empty"><p>当前单家对手数据有限，暂未从结构推理识别出明显单家留白。建议补充更多对手（≥3）以解锁赛道级群体空白共识。</p></div>`;
  }
  wrap.innerHTML = html;
  initConsumeTracking();
}

// P0-2 北极星埋点：每张空白卡片「被阅读/展开」≥5s 记为一次强信号消费（展开/收藏/分享/导出/标记同属强信号）。
// 委托监听只绑一次；重复点击重置 5s 计时器，避免误触即记。
let _consumeReady = false;
function trackConsume(itemType, itemId, action, dwellMs) {
  try {
    const headers = { 'Content-Type': 'application/json' };
    const t = getToken();
    if (t) headers['Authorization'] = 'Bearer ' + t;
    fetch('/api/consume', {
      method: 'POST',
      headers,
      body: JSON.stringify({ itemType, itemId, action, dwellMs })
    }).catch(() => {});
  } catch (e) {}
}
function initConsumeTracking() {
  if (_consumeReady) return;
  _consumeReady = true;
  const timers = {};
  document.addEventListener('click', e => {
    const el = e.target.closest && e.target.closest('.ws-item[data-gid]');
    if (!el) return;
    const gid = el.getAttribute('data-gid');
    if (!gid) return;
    if (timers[gid]) clearTimeout(timers[gid]);
    timers[gid] = setTimeout(() => { trackConsume('gap', gid, 'expand', 5000); delete timers[gid]; }, 5000);
  });
}

// ---------- 行业调研报告 ----------
async function genBrief() {
  const btn = $('#btnBriefS2');
  if (!btn) return;
  btn.disabled = true; btn.textContent = '生成中…';
  try {
    const b = await api('/api/brief', { method: 'POST' });
    state.brief = b;
    $('#briefWrap').innerHTML = renderReportDoc(b);
    $('#briefWrap').classList.remove('hidden');
  } catch (e) {
    $('#briefWrap').innerHTML = `<p class="err">调研报告生成失败：${esc(String(e.message || e))}</p>`;
    $('#briefWrap').classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = '生成行业调研报告';
  }
}
// 11 点质检门：内部质量纪律仍在后端计算（buildReport 返回 qc），但不在前端渲染"已通过"徽章——
// 忠实助理不靠"我们通过了质检"来换取信任，信任来自每条可验、敢标不确定、时间证明。
// 文档壳：标题 + as-of + markdown 正文
function renderReportDoc(b) {
  const track = (state && state.track) || '赛道';
  const asOf = b.asOf || (b.generatedAt ? b.generatedAt.slice(0, 10) : '');
  const body = `<div class="brief-md" id="briefMd">${renderMarkdown(b.markdown || '')}</div>`;
  const html = `<div class="report-doc">
    <div class="report-doc-head">
      <div class="doc-kicker">知彼 Vantage · 行业调研报告</div>
      <h2 class="doc-title">${esc(track)}</h2>
      ${asOf ? `<div class="doc-asof">数据截至 ${esc(asOf)} · 每条结论带来源，决策权归你</div>` : ''}
    </div>
    ${body}
  </div>`;
  // 渲染后绑定编号点击溯源
  setTimeout(() => bindCiteClicks(b), 0);
  return html;
}
// ▶ 报告-数据同源：从 markdown 附录解析 F#/G# → 证据 URL，点击编号跳转核验
function bindCiteClicks(b) {
  const map = {};
  const md = b.markdown || '';
  md.split('\n').forEach(line => {
    const m = line.match(/\*\*(F\d+|G\d+)\*\*\s*[^]*?\[来源\]\(([^)]+)\)/);
    if (m) map[m[1]] = m[2];
  });
  document.querySelectorAll('#briefMd .cite[data-cite]').forEach(el => {
    const id = el.getAttribute('data-cite');
    const url = map[id];
    el.classList.add('cite-link');
    el.onclick = () => {
      if (url && /^https?:\/\//.test(url)) window.open(url, '_blank', 'noopener');
      else if (id[0] === 'G') {
        const node = document.querySelector('#report .ws-sec, #oppsWrap, [data-tab="opps"]');
        if (node) node.scrollIntoView({ behavior: 'smooth' });
      }
    };
    if (url) el.title = '点击溯源：' + url;
  });
}
function renderMarkdown(md) {
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const lines = md.split('\n');
  let html = '', inTable = false, tableBuf = [], inQuote = false, quoteBuf = [];
  const flushTable = () => { if (tableBuf.length) { html += '<table>' + tableBuf.join('') + '</table>'; tableBuf = []; } inTable = false; };
  const flushQuote = () => { if (quoteBuf.length) { html += '<blockquote class="rc-card">' + quoteBuf.map(q => inline(esc(q))).join('<br>') + '</blockquote>'; quoteBuf = []; } inQuote = false; };
  for (let raw of lines) {
    const line = raw.replace(/\s+$/, '');
    if (/^\|/.test(line)) {
      inQuote && flushQuote();
      inTable = true;
      const cells = line.split('|').slice(1, -1).map(c => c.trim());
      if (cells.every(c => /^:?-+:?$/.test(c))) continue;
      const tag = tableBuf.length === 0 ? 'th' : 'td';
      tableBuf.push('<tr>' + cells.map(c => `<${tag}>${inline(esc(c))}</${tag}>`).join('') + '</tr>');
      continue;
    } else if (inTable) flushTable();
    if (/^>\s?/.test(line)) {
      inQuote = true;
      quoteBuf.push(line.replace(/^>\s?/, ''));
      continue;
    } else if (inQuote) flushQuote();
    if (/^### /.test(line)) html += `<h4>${inline(esc(line.slice(4)))}</h4>`;
    else if (/^## /.test(line)) html += `<h3>${inline(esc(line.slice(3)))}</h3>`;
    else if (/^# /.test(line)) html += `<h2>${inline(esc(line.slice(2)))}</h2>`;
    else if (/^[-*] /.test(line)) html += `<li>${inline(esc(line.slice(2)))}</li>`;
    else if (line.trim() === '') html += '';
    else html += `<p>${inline(esc(line))}</p>`;
  }
  if (inTable) flushTable();
  if (inQuote) flushQuote();
  return html;
}
function inline(s) {
  return s.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/\[([^\]]+)\]\((https?:[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
    // ▶ 报告-数据同源：编号可点击 → 溯源（点击跳证据 URL / 空白视图），见 bindCiteClicks
    .replace(/\[([FG]\d+)\]/g, '<span class="cite" data-cite="$1" title="点击溯源">[$1]</span>')
    .replace(/`(.+?)`/g, '<code>$1</code>');
}

// ---------- 交互绑定 ----------
function bindOnboarding() {
  $$('#goalChips .chip').forEach(ch => ch.onclick = () => {
    ch.classList.toggle('on');
    const g = ch.dataset.goal;
    if (ch.classList.contains('on')) { if (!intent.goals.includes(g)) intent.goals.push(g); }
    else intent.goals = intent.goals.filter(x => x !== g);
  });
  $$('#regionChips .chip').forEach(ch => ch.onclick = () => {
    ch.classList.toggle('on');
    const r = ch.dataset.region;
    if (ch.classList.contains('on')) { if (!intent.regions.includes(r)) intent.regions.push(r); }
    else intent.regions = intent.regions.filter(x => x !== r);
    refreshPbCur(); // 地域变化 → 价位输入币种联动
    if (!platformsTouched) syncPlatformDefaults(); // 用户没手动改平台 → 按地域重算勾选
  });
  // 调研平台多选：勾选态即平台集；手动改过就不再随地域自动变
  $$('#platformGroups .chip').forEach(ch => ch.onclick = () => {
    ch.classList.toggle('on');
    platformsTouched = true;
  });
  initSPChips();
  $('#btnAddSp').onclick = addCustomSP;
  $('#spCustom').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); addCustomSP(); } });
  refreshPbCur();
  $('#btnDiscover').onclick = discover;
  $('#btnLookup').onclick = lookup;
  $('#btnAddBrand').onclick = () => $('#addBrandRow').classList.toggle('hidden');
  $('#btnAddBrandGo').onclick = addBrand;
  $('#btnChangeTrack').onclick = resetToOnboarding;
  $('#btnSwitchTrack').onclick = resetToOnboarding;
  $$('.tab').forEach(t => t.onclick = () => switchTab(t.dataset.tab));
  // U3：左侧导航绑定（含 data-scroll 跳转）
  $$('.nav-item').forEach(n => n.onclick = () => switchTab(n.dataset.tab));
  const btnBriefS2 = $('#btnBriefS2'); if (btnBriefS2) btnBriefS2.onclick = genBrief;
  const btnAbout = $('#btnAbout'); if (btnAbout) btnAbout.onclick = () => $('#aboutModal').classList.remove('hidden');
  const btnAboutClose = $('#btnAboutClose'); if (btnAboutClose) btnAboutClose.onclick = () => $('#aboutModal').classList.add('hidden');
  // U5：新 UI 按钮绑定（设计稿布局）
  const btnWbSettings = $('#btnWbSettings'); if (btnWbSettings) btnWbSettings.onclick = () => $('#settingsModal').classList.remove('hidden');
  const btnRadarAdd = $('#btnRadarAdd'); if (btnRadarAdd) btnRadarAdd.onclick = () => {
    // 「补录对手」：直接弹输入框（闸门内联补录区已移除，入口统一到页头）
    const nm = window.prompt('输入要补录的对手品牌名（可附官网 URL）：');
    if (nm && nm.trim()) gateAddCompetitor(nm.trim());
  };
  const btnOppAbout = $('#btnOppAbout'); if (btnOppAbout) btnOppAbout.onclick = () => $('#aboutModal').classList.remove('hidden');
  const btnLogoutSide = $('#btnLogoutSide'); if (btnLogoutSide) btnLogoutSide.onclick = doLogout;
  // 闸门侧栏：移除 / 拉回 / 展开已移除（事件委托，单次绑定）
  const gate = $('#gateSidebar');
  if (gate) {
    gate.addEventListener('click', e => {
      const rm = e.target.closest('[data-gateremove]');
      if (rm) { gateAskReason(rm.dataset.gateremove); return; }
      const rsn = e.target.closest('[data-reason]');
      if (rsn) { gateRemove(rsn.dataset.rid, rsn.dataset.reason); return; }
      if (e.target.closest('[data-reasoncancel]')) { pendingRemoveId = null; renderGate(); return; }
      const rs = e.target.closest('[data-gaterestore]');
      if (rs) { gateRestore(rs.dataset.gaterestore); return; }
      const tg = e.target.closest('#gateRemovedToggle');
      if (tg) {
        const l = $('#gateRemovedList');
        const hidden = l.classList.toggle('hidden');
        tg.textContent = '已移除 (' + $('#gateRemovedCount').textContent + ') ' + (hidden ? '▾' : '▴');
      }
    });
  }
}

// ---------- 我的定位（价位 + 卖点） ----------
function initSPChips() {
  const box = $('#spChips');
  box.innerHTML = '';
  Object.keys(SP_ZH).forEach(k => {
    const b = document.createElement('button');
    b.className = 'chip';
    b.type = 'button';
    b.dataset.sp = k;
    b.textContent = SP_ZH[k];
    b.onclick = () => toggleSP(k, b);
    box.appendChild(b);
  });
}
function totalSP() { return selectedSP.size + customSP.length; }
function toggleSP(k, btn) {
  if (selectedSP.has(k)) { selectedSP.delete(k); btn.classList.remove('on'); }
  else {
    if (totalSP() >= SP_MAX) { toast(`核心卖点最多 ${SP_MAX} 条`); return; }
    selectedSP.add(k); btn.classList.remove('on'); btn.classList.add('on');
  }
  syncSPDisabled();
  updateSPSummary();
}
function addCustomSP() {
  const inp = $('#spCustom');
  const v = inp.value.trim();
  if (!v) return;
  if (customSP.length >= SP_CUSTOM_MAX) { toast(`自定义卖点最多 ${SP_CUSTOM_MAX} 条`); return; }
  if (totalSP() >= SP_MAX) { toast(`核心卖点最多 ${SP_MAX} 条`); return; }
  if (selectedSP.has(v) || customSP.includes(v)) { toast('该卖点已选'); inp.value = ''; return; }
  customSP.push(v);
  inp.value = '';
  syncSPDisabled();
  updateSPSummary();
}
function syncSPDisabled() {
  const full = totalSP() >= SP_MAX;
  $$('#spChips .chip').forEach(b => { if (!b.classList.contains('on')) b.disabled = full; });
  $('#btnAddSp').disabled = full || customSP.length >= SP_CUSTOM_MAX;
}
function updateSPSummary() {
  const all = Array.from(selectedSP).map(k => SP_ZH[k]).concat(customSP);
  $('#spSummary').textContent = all.length
    ? `已选 ${all.length} 条：${all.join('、')}（自定义 ${customSP.length} 条）`
    : '未指定卖点——稍后空白视图仍会分析，但无法以你的卖点为锚点。';
}
function refreshPbCur() {
  profileCur = marketCurrency(intent.regions);
  $('#pbCurLabel').textContent = curSym(profileCur);
}
// 按当前地域推导默认平台集并刷新平台 chip 勾选态（用户未手动改平台时调用）
function syncPlatformDefaults() {
  const def = platformsFromRegions(intent.regions);
  $$('#platformGroups .chip').forEach(ch => {
    ch.classList.toggle('on', def.includes(ch.dataset.platform));
  });
}
function collectProfile() {
  const min = parseFloat($('#pbMin').value);
  const max = parseFloat($('#pbMax').value);
  const pb = (isNaN(min) && isNaN(max)) ? null
    : { min: isNaN(min) ? null : min, max: isNaN(max) ? null : max, currency: profileCur };
  const sellingPoints = Array.from(selectedSP).concat(customSP);
  if (!sellingPoints.length && !pb) return null;
  return { sellingPoints, priceBand: pb };
}

async function discover() {
  const track = $('#trackInput').value.trim();
  if (!track) { $('#obStatus').textContent = '请先填写你要做的赛道'; return; }
  expandedIds.clear(); timelineCache.clear();
  const platforms = collectPlatforms();
  // P2-2026-08-12：点击「帮我找对手」立即进入工作台并显示调研进度，避免卡在入口页像"啥也没干"
  if (!state || typeof state !== 'object') state = { competitors: [], excluded: [], intent: {} };
  if (!state.intent) state.intent = {};
  state.track = track; // 顶栏赛道 pill 显示新赛道
  // 重置增量渲染上下文：发现阶段由 SSE 增量事件驱动
  discovering = true; discoverProjectId = null; discoverErrored = false;
  const grid0 = document.querySelector('.pano-cards'); if (grid0) grid0.innerHTML = '';
  enterReport();
  // 工作台进度条占位（搜索进行中）
  const pw = $('#progressWrap'); if (pw) pw.classList.remove('hidden');
  const pb = $('#progressBar'); if (pb) pb.style.width = '5%';
  const pt = $('#progressText'); if (pt) pt.textContent = '正在理解你的赛道…';
  $('#btnDiscover').disabled = true;
  startPolling(); // 提前建 SSE，接收发现进度事件（typed）
  try {
    const r = await api('/api/discover', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ track, intent: { goals: intent.goals.slice(), regions: intent.regions.slice(), platforms: platforms.slice(), profile: collectProfile() } })
    });
    // 期望 202 {projectId, status:'accepted'}：发现进度由 SSE 推送，不在此 await 结果
    discoverProjectId = r.projectId || null;
    // ▶ 加固（发现链路 F1）：后端发现启动即落空状态（B1），这里立即拉取并渲染，
    // 即使 SSE 连接稍晚，用户也已看到「赛道 + 研究中」而非空白。
    try {
      const s = await api('/api/state');
      if (s && s.projectId) {
        state = s;
        if (s.track) state.track = s.track;   // 顶栏赛道 pill 立即显示
        renderAll();
      }
    } catch {}
    if (r.status !== 'accepted' && !discoverProjectId) throw new Error('UNEXPECTED_RESPONSE');
  } catch (e) {
    const m = (e && e.message) || '未知错误';
    if (/NO_KEYS/.test(m)) toast('未配置 API 密钥，请在设置中填入搜索源与 DeepSeek 密钥。');
    else if (/TOO_BUSY|RATE_LIMIT|quota/.test(m)) toast('研究服务正忙或请求过于频繁，请稍后再试。');
    else toast('识别失败：' + m);
    discovering = false;
    stopPolling();
    showOnboarding();
  } finally {
    $('#btnDiscover').disabled = false;
  }
}

// 入口：直接检索一个具体品牌
async function lookup() {
  const name = $('#lookupInput').value.trim();
  if (!name) { $('#obStatus').textContent = '请填写要检索的品牌名'; return; }
  const platforms = collectPlatforms();
  // P2-2026-08-12：与 discover 同款处理——换赛道后检索，顶栏必须显示新赛道（后端 lookup 不更新 track）
  const track = ($('#trackInput') && $('#trackInput').value.trim()) || (state && state.track) || '品牌检索';
  if (!state || typeof state !== 'object') state = { competitors: [], excluded: [], intent: {} };
  if (!state.intent) state.intent = {};
  if (track) state.track = track;
  enterReport(); // 立即进入工作台显示进度，不卡在入口页
  const pw = $('#progressWrap'); if (pw) pw.classList.remove('hidden');
  const pb = $('#progressBar'); if (pb) pb.style.width = '12%';
  const pt = $('#progressText'); if (pt) pt.textContent = '正在检索「' + name + '」并深度调研，请稍候…';
  $('#btnLookup').disabled = true; $('#btnDiscover').disabled = true;
  try {
    const s = await api('/api/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, intent: { goals: intent.goals.slice(), regions: intent.regions.slice(), platforms: platforms.slice(), profile: collectProfile() } })
    });
    state = s;
    if (track) state.track = track; // 强制新赛道（后端 lookup 沿用旧档案 track）
    enterReport();
    startPolling();
  } catch (e) {
    toast('检索失败：' + (e.message || e));
    showOnboarding();
  } finally {
    $('#btnLookup').disabled = false; $('#btnDiscover').disabled = false;
  }
}

// 结果页：追加一个指定品牌
async function addBrand() {
  const raw = $('#addBrandInput').value.trim();
  if (!raw) return;
  const parts = raw.split(/\s+/);
  const name = parts[0];
  const url = parts.slice(1).find(p => /^https?:\/\//.test(p)) || '';
  $('#btnAddBrandGo').disabled = true;
  try {
    const s = await api('/api/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, url })
    });
    state = s;
    renderAll();
    startPolling();
    $('#addBrandInput').value = '';
    $('#addBrandRow').classList.add('hidden');
  } catch (e) {
    toast('添加失败：' + (e.message || e));
  } finally {
    $('#btnAddBrandGo').disabled = false;
  }
}

async function enrich(id, btn) {
  btn.disabled = true; btn.textContent = '已加入优先队列…';
  try { await api('/api/enrich', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ competitorId: id }) }); }
  catch (e) { toast('优先调研触发失败：' + (e.message || e)); }
}

// ---------- 历史调研（档案切换/删除） ----------
function bindHistory() {
  $('#btnHistory').onclick = openHistory;
  $('#btnHistoryClose').onclick = () => $('#historyModal').classList.add('hidden');
}
async function openHistory() {
  $('#historyModal').classList.remove('hidden');
  $('#historyStatus').textContent = '';
  const box = $('#historyList');
  box.innerHTML = '<p class="muted">加载中…</p>';
  try {
    const r = await api('/api/projects');
    renderHistory(r.projects || []);
  } catch (e) { box.innerHTML = '<p class="muted">加载失败：' + esc(e.message || String(e)) + '</p>'; }
}
function renderHistory(list) {
  const box = $('#historyList');
  if (!list.length) { box.innerHTML = '<p class="muted">还没有任何调研档案。搜索一个赛道即可创建第一份。</p>'; return; }
  box.innerHTML = list.map(p => `
    <div class="history-item ${p.current ? 'cur' : ''}">
      <div class="hi-main">
        <div class="hi-track">${esc(p.track)}${p.current ? ' <span class="hi-cur">当前</span>' : ''}</div>
        <div class="hi-meta">${p.discoveredAt ? new Date(p.discoveredAt).toLocaleString('zh-CN') : '时间未知'} · ${p.total != null ? p.total : '—'} 个品牌（${p.done != null ? p.done : '—'} 家已深研）${p.hasBrief ? ' · 已生成调研报告' : ''}</div>
      </div>
      <div class="hi-actions">
        ${p.current ? '' : `<button class="btn-ghost hi-open" data-id="${escAttr(p.id)}">打开</button>`}
        <button class="btn-ghost hi-del" data-id="${escAttr(p.id)}" data-track="${escAttr(p.track)}">删除</button>
      </div>
    </div>`).join('');
  box.querySelectorAll('.hi-open').forEach(b => { b.onclick = () => switchProject(b.dataset.id); });
  box.querySelectorAll('.hi-del').forEach(b => { b.onclick = () => deleteProject(b.dataset.id, b.dataset.track); });
}
async function switchProject(id) {
  try {
    stopPolling();
    expandedIds.clear(); timelineCache.clear();
    const s = await api('/api/projects/switch', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    state = s;
    $('#historyModal').classList.add('hidden');
    if (s && s.track) {
      enterReport();
      const comps = s.competitors || [];
      if (comps.some(c => c.status !== 'done' && c.status !== 'error')) startPolling();
    } else showOnboarding();
  } catch (e) { $('#historyStatus').textContent = '切换失败：' + (e.message || e); }
}
async function deleteProject(id, track) {
  if (!confirm('确定删除调研「' + track + '」？档案将被移除，不可恢复。')) return;
  try {
    const r = await api('/api/projects/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
    renderHistory(r.projects || []);
    renderHistoryTab();
    if (state && state.projectId === id) { state = null; stopPolling(); showOnboarding(); }
  } catch (e) { $('#historyStatus').textContent = '删除失败：' + (e.message || e); }
}

// U3：左侧导航「历史调研」面板（与弹窗共用 /api/projects 数据）
async function renderHistoryTab() {
  const wrap = $('#historyWrap');
  if (!wrap) return;
  if (DEMO_MODE) {
    const p = (state && state.track) ? state.track : '定制手办 · 潮流玩具';
    wrap.innerHTML = `<div class="hist-list"><div class="hist-item" style="cursor:default">
      <div class="h-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/></svg></div>
      <div class="h-main"><div class="h-nm">${esc(p)}</div><div class="h-meta">6 家对手 · 已收 12 份材料 · 最近扫描今天 09:00（演示）</div></div>
      <span class="h-cur">当前</span></div></div>`;
    return;
  }
  wrap.innerHTML = '<p class="muted">加载中…</p>';
  try {
    const r = await api('/api/projects');
    const list = r.projects || [];
    if (!list.length) { wrap.innerHTML = '<p class="muted">还没有任何调研档案。搜索一个赛道即可创建第一份。</p>'; return; }
    wrap.innerHTML = list.map(p => `
      <div class="history-item ${p.current ? 'cur' : ''}">
        <div class="hi-main">
          <div class="hi-track">${esc(p.track)}${p.current ? ' <span class="hi-cur">当前</span>' : ''}</div>
          <div class="hi-meta">${p.discoveredAt ? new Date(p.discoveredAt).toLocaleString('zh-CN') : '时间未知'} · ${p.total != null ? p.total : '—'} 个品牌（${p.done != null ? p.done : '—'} 家已深研）${p.hasBrief ? ' · 已生成调研报告' : ''}</div>
        </div>
        <div class="hi-actions">
          ${p.current ? '' : `<button class="btn-ghost hi-open" data-id="${escAttr(p.id)}">打开</button>`}
          <button class="btn-ghost hi-del" data-id="${escAttr(p.id)}" data-track="${escAttr(p.track)}">删除</button>
        </div>
      </div>`).join('');
    wrap.querySelectorAll('.hi-open').forEach(b => { b.onclick = () => switchProject(b.dataset.id); });
    wrap.querySelectorAll('.hi-del').forEach(b => { b.onclick = () => deleteProject(b.dataset.id, b.dataset.track); });
  } catch (e) { wrap.innerHTML = '<p class="muted">加载失败：' + esc(e.message || String(e)) + '</p>'; }
}

// ---------- 设置 / 报错 / 工具 ----------
const PROVIDER_META = {
  serper: { hint: '#serperHint', has: 'hasSerper', label: 'Serper' },
  brave: { hint: '#braveHint', has: 'hasBrave', label: 'Brave' },
  bocha: { hint: '#bochaHint', has: 'hasBocha', label: '博查' }
};
let cfgHas = { hasSerper: false, hasBrave: false, hasBocha: false };
function refreshKeyHints(provider) {
  Object.keys(PROVIDER_META).forEach(pv => {
    const m = PROVIDER_META[pv];
    const el = $(m.hint);
    if (!el) return;
    if (cfgHas[m.has]) el.textContent = '（已配置，留空则保持）';
    else el.textContent = provider === pv ? `（当前选中 ${m.label}，需填 Key）` : '（可留空）';
  });
}
function bindSettings() {
  $('#btnSettings').onclick = async () => {
    $('#settingsModal').classList.remove('hidden');
    $('#settingsStatus').textContent = '';
    try {
      const cfg = await api('/api/config');
      cfgHas = { hasSerper: !!cfg.hasSerper, hasBrave: !!cfg.hasBrave, hasBocha: !!cfg.hasBocha };
      ZB_OWN_BRANDS = (cfg && cfg.ownBrands) || [];
      if (cfg.provider) $('#setProvider').value = cfg.provider;
      refreshKeyHints($('#setProvider').value);
      if (cfg.hasSerper && cfg.serperKeyCount) $('#serperHint').textContent = `（已配置 ${cfg.serperKeyCount} 个 key，可用 ${Math.max(cfg.serperKeyCount - (cfg.serperKeysDisabled || 0), 0)} 个）`;
      if (cfg.ownBrands && Array.isArray(cfg.ownBrands)) $('#setOwnBrands').value = cfg.ownBrands.join('\n');
    } catch (e) { /* 忽略，用默认 tavily */ }
  };
  $('#setProvider').onchange = () => refreshKeyHints($('#setProvider').value);
  $('#btnSettingsCancel').onclick = () => $('#settingsModal').classList.add('hidden');
  $('#btnSettingsSave').onclick = async () => {
    const ds = $('#setDeepseek').value.trim();
    const tv = $('#setTavily').value.trim();
    const serper = $('#setSerper').value.trim();
    const serperPoolRaw = $('#setSerperPool').value.trim();
    const brave = $('#setBrave').value.trim();
    const bocha = $('#setBocha').value.trim();
    const ownBrandsRaw = $('#setOwnBrands').value.trim();
    const ownBrands = ownBrandsRaw.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean);
    const provider = $('#setProvider').value;
    // 主 key + 备用池合并成一个数组传给后端（后端再做归一化）
    let serperKeys = serperPoolRaw.split(/[\n,;]+/).map(s => s.trim()).filter(Boolean);
    if (serper && !serperKeys.includes(serper)) serperKeys.unshift(serper);
    const need = { serper: [serper || serperPoolRaw, 'hasSerper', 'Serper'], brave: [brave, 'hasBrave', 'Brave'], bocha: [bocha, 'hasBocha', '博查'] };
    if (need[provider] && !need[provider][0] && !cfgHas[need[provider][1]]) {
      $('#settingsStatus').textContent = `请先填 ${need[provider][2]} API Key，否则无法搜索`;
      return;
    }
    try {
      const r = await api('/api/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ llm: { apiKey: ds }, search: { provider, apiKey: tv, serperKey: serper, serperKeys, braveKey: brave, bochaKey: bocha }, ownBrands }) });
      ZB_OWN_BRANDS = ownBrands;
      $('#settingsStatus').textContent = r.hasKeys ? `已保存 ✓（Serper ${r.serperKeyCount || 0} 个 key）` : '已保存（搜索源密钥仍缺失）';
      setTimeout(() => $('#settingsModal').classList.add('hidden'), 800);
    } catch (e) { $('#settingsStatus').textContent = '保存失败：' + (e.message || e); }
  };
  // 搜索源对比测试
  const btnST = $('#btnSearchTest');
  if (btnST) btnST.onclick = async () => {
    const q = $('#stQuery').value.trim();
    const box = $('#stResult');
    if (!q) { box.innerHTML = '<p class="muted">请填写测试查询词</p>'; return; }
    box.innerHTML = '<p class="muted">各源并行查询中…</p>';
    try {
      const r = await api('/api/searchtest', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query: q }) });
      let html = '';
      Object.keys(r.providers).forEach(name => {
        const p = r.providers[name];
        if (!p.ok) { html += `<div class="st-block"><b>${name}</b> <span class="tag warn-tag">失败 ${esc(p.error)}</span></div>`; return; }
        html += `<div class="st-block"><b>${name}</b> <span class="muted">${p.count} 条</span><ul>` +
          p.results.map(x => `<li><a href="${escAttr(x.url)}" target="_blank" rel="noopener">${esc(x.title || x.url)}</a><br><span class="muted">${esc(x.snippet)}</span></li>`).join('') +
          `</ul></div>`;
      });
      box.innerHTML = html || '<p class="muted">无结果</p>';
    } catch (e) { box.innerHTML = `<p class="muted">测试失败：${esc(e.message || String(e))}</p>`; }
  };
}
// 空白视图（聚合产物）轻量纠错通道：单一低调入口，不挂每张卡上（忠实助理：不暗示"数据可议"）。
let reportGapCtx = null;
function openReportWithGap(id, label) {
  reportGapCtx = { id, label };
  const m = $('#reportModal'); if (m) m.classList.remove('hidden');
  const d = $('#repDesc'); if (d && !d.value.trim()) d.value = '【空白视图反馈】';
  const st = $('#reportStatus'); if (st) st.textContent = '你正在反馈：' + label + '（请说明哪里不准，并附证据来源）';
}
function bindReportModal() {
  $('#btnReport').onclick = () => { reportGapCtx = null; $('#reportModal').classList.remove('hidden'); };
  $('#btnReportCancel').onclick = () => { reportGapCtx = null; $('#reportModal').classList.add('hidden'); };
  $('#btnReportSend').onclick = async () => {
    const desc = $('#repDesc').value.trim();
    const source = $('#repSource').value.trim();
    if (!desc) { $('#reportStatus').textContent = '请填写问题描述'; return; }
    if (!source) { $('#reportStatus').textContent = '请附上证据来源（必填，否则不予受理）'; return; }
    try {
      await api('/api/report', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        competitorId: $('#repCompetitor').value.trim() || null,
        gapId: reportGapCtx ? reportGapCtx.id : null,
        gapLabel: reportGapCtx ? reportGapCtx.label : null,
        description: desc, source
      }) });
      $('#reportStatus').textContent = '已收到，我们会核实后留痕更新 ✓';
      reportGapCtx = null;
      setTimeout(() => $('#reportModal').classList.add('hidden'), 1000);
    } catch (e) { $('#reportStatus').textContent = '提交失败：' + (e.message || e); }
  };
}
function bindFieldCorrect() {
  const type = $('#fcType');
  if (type) type.addEventListener('change', toggleFcWraps);
  const fsel = $('#fcField');
  if (fsel) fsel.addEventListener('change', () => applyFcField(fsel.value));
  const cancel = $('#btnFcCancel');
  if (cancel) cancel.onclick = () => $('#fieldCorrectModal').classList.add('hidden');
  const send = $('#btnFcSend');
  if (send) send.onclick = submitFieldCorrect;
}

// ---------- 纠错报告面板：你的反馈如何改进搜索（规则逐条先审） ----------
const CONF_ZH = { high: '高', medium: '中', low: '低' };
function bindFeedbackReport() {
  const btn = $('#btnFeedbackReport');
  const modal = $('#fbModal');
  if (!btn || !modal) return;
  btn.onclick = () => { modal.classList.remove('hidden'); loadFeedbackReport(); };
  modal.addEventListener('click', e => {
    if (e.target === modal || e.target.closest('[data-close-fb]')) { modal.classList.add('hidden'); return; }
    const b = e.target.closest('[data-ruleid]');
    if (b) reviewRule(b.dataset.ruleid, b.dataset.decision);
  });
}
async function loadFeedbackReport() {
  const box = $('#fbBody');
  box.innerHTML = '<p class="muted">读取中…</p>';
  try { renderFeedbackReport(await api('/api/feedback-report')); }
  catch (e) { box.innerHTML = `<p class="muted">读取失败：${esc(e.message || String(e))}</p>`; }
}
async function reviewRule(id, decision) {
  try {
    const rep = await api('/api/rule-review', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, decision }) });
    renderFeedbackReport(rep);
    toast(decision === 'approved' ? '已采纳：下次搜索起生效。' : '已否决：这条不会生效，也不再问你。');
  } catch (e) { toast('提交失败：' + (e.message || e)); }
}
function renderFeedbackReport(rep) {
  const box = $('#fbBody');
  if (!rep) { box.innerHTML = '<p class="muted">暂无数据</p>'; return; }
  const removed = rep.removed || [], added = rep.added || [], rules = rep.rules || [];
  if (!removed.length && !added.length) {
    box.innerHTML = '<p class="muted">还没有反馈记录。在右侧闸门里移掉不算对手的品牌、或补一个我们漏掉的真对手，这里就会出现它对搜索算法的影响。</p>';
    return;
  }
  let h = '';
  // 1. 你做了什么
  h += '<div class="fb-sec"><h4 class="fb-h">你给过的信号</h4>';
  if (removed.length) {
    h += `<p class="fb-line"><b>移掉 ${removed.length} 家</b>：` + removed.map(r =>
      `<span class="fb-chip${r.isTractionBlind ? ' blind' : ''}">${escAttr(r.name)} · ${esc(r.reasonZh)}</span>`).join('') + '</p>';
  }
  if (added.length) {
    h += `<p class="fb-line"><b>补录 ${added.length} 家</b>：` + added.map(a =>
      `<span class="fb-chip add">${esc(a.name)}</span>`).join('') + '</p>';
  }
  h += '<p class="fb-note">名字级排除已经在生效——这些品牌不会在本赛道再出现。下面是我们想从中「学到的规律」，需要你逐条裁决。</p></div>';
  // 2. 候选规则：逐条先审
  h += '<div class="fb-sec"><h4 class="fb-h">候选规则 · 每条需你点头</h4>';
  if (!rules.length) h += '<p class="muted">样本还不够，暂时提炼不出规律。我们不会为了显得聪明而编一条。</p>';
  rules.forEach(r => {
    const st = r.decision === 'approved' ? '<span class="fb-state on">已采纳 · 生效中</span>'
      : r.decision === 'rejected' ? '<span class="fb-state off">已否决</span>'
      : r.enforceable ? '<span class="fb-state wait">待你裁决</span>'
      : '<span class="fb-state na">暂不可执行</span>';
    h += `<div class="fb-rule${r.enforceable ? '' : ' na'}">
      <div class="fb-rule-top">${st}<span class="fb-conf">依据 ${esc((r.evidence && r.evidence.length) || 0)} 条</span></div>
      <p class="fb-rule-text">${esc(r.text)}</p>
      ${r.effect ? `<p class="fb-rule-effect">${esc(r.effect)}</p>` : ''}
      ${r.evidence && r.evidence.length ? `<p class="fb-rule-ev">依据：${r.evidence.map(e => esc(e)).join('、')}</p>` : ''}
      ${r.enforceable && r.decision !== 'approved' && r.decision !== 'rejected'
        ? `<div class="fb-acts"><button class="fb-btn ok" data-ruleid="${escAttr(r.id)}" data-decision="approved">采纳，下次起生效</button>
           <button class="fb-btn no" data-ruleid="${escAttr(r.id)}" data-decision="rejected">不采纳</button></div>`
        : r.enforceable ? `<div class="fb-acts"><button class="fb-btn undo" data-ruleid="${escAttr(r.id)}" data-decision="${r.decision === 'approved' ? 'rejected' : 'approved'}">${r.decision === 'approved' ? '撤回采纳' : '改为采纳'}</button></div>` : ''}
    </div>`;
  });
  h += '</div>';
  if (rep.activeKeywords && rep.activeKeywords.length) {
    h += `<p class="fb-active">当前真正生效的过滤词：${rep.activeKeywords.map(k => `<code>${esc(k)}</code>`).join(' ')}</p>`;
  }
  box.innerHTML = h;
}

let toastTimer = null;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.remove('hidden');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.add('hidden'), 2600);
}
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
// P0 修复：esc() 只转义 & < >，用于 HTML 属性上下文（href/title/data-* 等）会漏掉引号 → 属性注入。
// escAttr = 文本转义 + 引号转义，凡属性值一律用它；文本节点继续用 esc()。
function escAttr(s) { return esc(s).replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }

boot();
